import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import vm from 'node:vm';
import {parseEnvelope,safeHttps,sendMessage,unwrapResponse} from '../force-app/main/default/lwc/hollyUi/hollyUi.js';
const root=new URL('../force-app/main/default/lwc/',import.meta.url);
function component(name, extra={}){
 let code=fs.readFileSync(new URL(`${name}/${name}.js`,root),'utf8').replace(/^import .*?;\s*$/gm,'').replace(/@api\s*/g,'').replace(/export default class (\w+)/,'globalThis.Component = class $1');
 const ctx={LightningElement:class{},parseEnvelope,safeHttps,sendMessage,unwrapResponse,URL,...extra};vm.createContext(ctx);vm.runInContext(code,ctx);return new ctx.Component();
}
test('typed envelopes and strict outbound URLs',()=>{
 assert.equal(parseEnvelope({renderedResponse:{responsePayload:'{"view":"orderDetail"}'}}).view,'orderDetail');
 assert.throws(()=>parseEnvelope({responsePayload:'[]'}));assert.throws(()=>parseEnvelope({responsePayload:'null'}));
 for(const bad of ['javascript:alert(1)','http://hallmark.com','https://hallmark.com.evil.test','https://u:p@hallmark.com'])assert.equal(safeHttps(bad,['hallmark.com']),'');
 assert.equal(safeHttps('https://www.hallmark.com/x',['hallmark.com']),'https://www.hallmark.com/x');
});
test('product selection remains selected after failed delivery and clears after success',async()=>{
 const c=component('productCarouselWidget');c.value={responsePayload:JSON.stringify({view:'productCarousel',maxCompare:99,products:[{sku:'A',name:'One'},{sku:'B',name:'Two'}]})};c.parsePayload();assert.equal(c.maxCompare,3);
 c.selectedSkus=['A','B'];c.selectionMode=true;c.configuration={util:{sendTextMessage:async()=>{throw Error('fail')}}};await c.handleCompare();assert.equal(c.selectedSkus.length,2);assert.equal(c.selectionMode,true);assert.ok(c.sendError);
 let messages=0;c.configuration={util:{sendTextMessage:async text=>{messages++;assert.ok(text.includes('items A,B'));}}};await c.handleCompare();assert.equal(messages,1);assert.equal(c.selectedSkus.length,0);
});
test('malformed product response and duplicate SKU',()=>{
 const c=component('productCarouselWidget');c.value={responsePayload:'{"products":{}}'};c.parsePayload();assert.equal(c.hasError,true);
 c.value={responsePayload:{view:'productCarousel',products:[{sku:'A',imageUrl:'javascript:x'},{sku:'A'},null]}};c.parsePayload();assert.equal(c.rawProducts.length,1);assert.equal(c.rawProducts[0].imageUrl,'');
});
test('order malformed payload has fallback and external card does not expose case form',()=>{
 const c=component('orderSearchWidget');c.value={responsePayload:'{bad'};c.parsePayload();assert.equal(c.isErrorView,true);assert.equal(c.showOrderCaseForm,false);
});
test('rewards accepts object and JSON payloads and routes mutations through conversation',async()=>{
 const c=component('rewardsSupportWidget');c.value={responsePayload:{view:'memberOverview',membershipTier:'Platinum',pointsBalance:1200}};assert.equal(c.pointsBalance,1200);assert.equal(c.showOverview,true);
 c.value={responsePayload:JSON.stringify({view:'missingPointsInteractive'})};assert.equal(c.needsConversation,true);assert.equal(c.isMissingPointsInteractive,false);
 let count=0;c.configuration={util:{sendTextMessage:async()=>count++}};await c.handleSubmitInStoreCase();assert.equal(count,1);
});
test('welcome choice fails visibly and dismisses only after successful send',async()=>{
 const c=component('hollyCareHeader');c.conversationStatus='OPEN';
 const event={currentTarget:{dataset:{choice:'Check my Crown Rewards points'}}};
 c.configuration={util:{sendTextMessage:async()=>{throw Error('offline')}}};await c.selectChoice(event);assert.equal(c.dismissed,false);assert.ok(c.errorMessage);
 let sent='';c.configuration={util:{sendTextMessage:async text=>{sent=text}}};await c.selectChoice(event);assert.equal(sent,event.currentTarget.dataset.choice);assert.equal(c.dismissed,true);
});

test('body welcome sends choices without header configuration or dismissing the image', async()=>{
 const c=component('hollyWelcome');let sent='';
 c.configuration={util:{sendTextMessage:async text=>{sent=text}}};
 await c.selectChoice({currentTarget:{dataset:{choice:'Where is my order?'}}});
 assert.equal(sent,'Where is my order?');assert.equal(c.showBanner,true);
 c.configuration={util:{sendTextMessage:async()=>{throw Error('offline')}}};
 await c.selectChoice({currentTarget:{dataset:{choice:'Where is my order?'}}});
 assert.ok(c.errorMessage);assert.equal(c.showBanner,true);
});

test('header delegates transcript and end chat to Salesforce and handles failures',async()=>{
 const calls=[];const c=component('hollyCareHeader',{dispatchMessagingEvent:(name)=>calls.push(name),MESSAGING_EVENT:{REQUEST_TRANSCRIPT:'transcript',CLOSE_CONVERSATION:'end',MINIMIZE_BUTTON_CLICK:'minimize'}});
 c.requestTranscript();c.minimize();assert.deepEqual(calls,['transcript','minimize']);
 c.configuration={embeddedServiceMessagingChannel:{authMode:'UnAuth'}};await c.endConversation();assert.equal(calls.at(-1),'end');
 let ends=0;c.configuration={embeddedServiceMessagingChannel:{authMode:'Auth'},util:{endSession:async()=>ends++}};await c.endConversation();assert.equal(ends,1);
 c.configuration={};await c.endConversation();assert.ok(c.errorMessage);assert.equal(c.ending,false);
});

function headerWithStorage(storage) {
 return component('hollyCareHeader',{window:{location:{pathname:'/deployment-a/'},sessionStorage:storage}});
}
test('welcome survives untouched refresh, stays dismissed after a choice and resets for new chat',async()=>{
 const values=new Map();const storage={getItem:k=>values.get(k),setItem:(k,v)=>values.set(k,v),removeItem:k=>values.delete(k)};
 const first=headerWithStorage(storage);first.conversationStatus='OPEN';assert.equal(first.showBanner,true);const untouched=headerWithStorage(storage);untouched.conversationStatus='OPEN';assert.equal(untouched.showBanner,true);
 first.configuration={util:{sendTextMessage:async()=>{}}};await first.selectChoice({currentTarget:{dataset:{choice:'Where is my order?'}}});
 const refreshed=headerWithStorage(storage);refreshed.conversationStatus='NOT_STARTED';refreshed.conversationStatus='OPEN';assert.equal(refreshed.showBanner,false);
 refreshed.dismissed=true;refreshed.conversationStatus='CLOSED';assert.equal(refreshed.showBanner,false);
 refreshed.conversationStatus='OPEN';assert.equal(refreshed.showBanner,true);
 refreshed.conversationStatus='CLOSED';
 const recreated=headerWithStorage(storage);recreated.conversationStatus='OPEN';assert.equal(recreated.showBanner,true);
});
test('blocked browser storage does not break header lifecycle',()=>{
 const fail=()=>{throw Error('Blocked')};const c=headerWithStorage({getItem:fail,setItem:fail,removeItem:fail});
 c.conversationStatus='OPEN';c.dismissed=true;c.conversationStatus='CLOSED';c.conversationStatus='OPEN';assert.equal(c.showBanner,true);
});

test('Rewards and H+ accept typed objects, wrapped results and JSON envelopes',()=>{
 for(const wrap of [v=>v,v=>[v],v=>({renderedResponse:v}),v=>JSON.stringify(v)]) {
  const r=component('rewardsSupportWidget');r.value=wrap({memberFound:true,crownRewardsNumber:'DEMO',membershipTier:'Member',pointsBalance:0});assert.equal(r.showOverview,true);assert.equal(r.pointsBalance,0);
  const h=component('hallmarkPlusWidget');h.value=wrap({membershipFound:true,autoRenewEnabled:false});assert.equal(h.found,true);assert.equal(h.renewal,'Off');
 }
});

test('Rewards normalizes overview names and H+ text responses still render membership',()=>{
 for(const name of ['memberOverview','membersOverview']) {
  const c=component('rewardsSupportWidget');c.value={responseType:name,responsePayload:JSON.stringify({view:name,crownRewardsNumber:'DEMO',pointsBalance:0})};assert.equal(c.showOverview,true);
 }
 const h=component('hallmarkPlusWidget');h.value={renderedResponse:{responseType:'text',membershipFound:true,nextPaymentDate:'2027-03-19'}};assert.equal(h.found,true);assert.equal(h.nextPayment,'2027-03-19');
 h.value={responseType:'text',membershipFound:false,summaryMessage:'No membership found'};assert.equal(h.found,false);assert.equal(h.message,'No membership found');
 const product=component('productCarouselWidget');product.value={summaryMessage:'Thoughtful picks for someone special.',followUpQuestion:'What is the occasion?'};assert.equal(product.introMessage,'Thoughtful picks for someone special.');assert.equal(product.followUpMessage,'What is the occasion?');
});

test('Rewards conversion card is no longer suppressed',()=>{
 const c=component('rewardsSupportWidget');c.value={responsePayload:{view:'rewardConversion',membershipTier:'Member',pointsBalance:2500,rewardChoices:[5,10]}};
 assert.equal(c.hasPayload,true);assert.equal(c.showOverview,true);assert.equal(c.hasRewardChoices,true);
});

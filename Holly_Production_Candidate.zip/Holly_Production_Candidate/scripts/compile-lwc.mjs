import {transformSync} from '@lwc/compiler';
import fs from 'node:fs';
import path from 'node:path';
const root=new URL('../force-app/main/default/lwc/',import.meta.url);let count=0;const errors=[];
for(const name of fs.readdirSync(root)){if(!fs.statSync(new URL(name,root)).isDirectory())continue;const dir=new URL(name+'/',root);
for(const file of fs.readdirSync(dir)){if(!/\.(js|html|css)$/.test(file))continue;
try{transformSync(fs.readFileSync(new URL(file,dir),'utf8'),file,{name,namespace:'c',apiVersion:67});count++;}catch(e){errors.push(`${name}/${file}: ${e.message}`);}}}
if(errors.length){console.error(errors.join('\n'));process.exit(1);}console.log(`PASS: compiled ${count} LWC JavaScript, HTML and CSS files`);

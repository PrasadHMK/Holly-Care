import {build} from 'esbuild';
import {transformSync} from '@lwc/compiler';
import fs from 'node:fs';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
const project=fileURLToPath(new URL('../',import.meta.url));
const root=path.join(project,'force-app/main/default/lwc');
const agent=fs.readFileSync(path.join(project,'agent-script/Hallmark_Holly_Care_v4.yaml'),'utf8');
const welcome=agent.match(/^        welcome: "(.*)"$/m)?.[1] ?? '';
fs.writeFileSync(path.join(project,'component-preview/welcome-text.json'),JSON.stringify(welcome));
await build({entryPoints:{components:path.join(project,'component-preview/main.js'),welcome:path.join(project,'component-preview/welcome-entry.js')},outdir:path.join(project,'component-preview'),bundle:true,format:'iife',define:{'process.env.NODE_ENV':'"production"'},plugins:[{name:'lwc',setup(b){
 b.onResolve({filter:/\.scoped\.css\?scoped=true$/},()=>({path:'empty',namespace:'empty-style'}));
 b.onLoad({filter:/.*/,namespace:'empty-style'},()=>({contents:'export default undefined;'}));
 b.onResolve({filter:/^lwc$/},()=>({path:path.join(project,'node_modules/@lwc/engine-dom/dist/index.js')}));
 b.onResolve({filter:/^c\//},args=>{const name=args.path.slice(2);return {path:path.join(root,name,name+'.js')}});
 b.onResolve({filter:/^(lightning\/|lightningsnapin\/|@salesforce\/)/},args=>({path:args.path,namespace:'runtime-stub'}));
 b.onLoad({filter:/.*/,namespace:'runtime-stub'},args=>{
 if(args.path==='lightningsnapin/eventStore')return {contents:"export const MESSAGING_EVENT={MINIMIZE_BUTTON_CLICK:'minimize',CLOSE_CONVERSATION:'end',REQUEST_TRANSCRIPT:'transcript'};export function dispatchMessagingEvent(name){document.dispatchEvent(new CustomEvent('previewheader',{detail:name}));}"};
 if(args.path.startsWith('@salesforce/'))return {contents:"export default async function(){throw new Error('Salesforce service calls are unavailable in the local component preview')};"};
 return {contents:"import {LightningElement} from 'lwc';export default class UnavailableBaseComponent extends LightningElement {}"};
 });
 b.onLoad({filter:/\.(js|html|css)$/},args=>{
 if(!args.path.startsWith(root+path.sep))return;
 const name=path.basename(path.dirname(args.path));const out=transformSync(fs.readFileSync(args.path,'utf8'),path.basename(args.path),{name,namespace:'c',apiVersion:67});return {contents:out.code,loader:'js'};
 });
}}]});
console.log('Built actual LWC component review bundle');

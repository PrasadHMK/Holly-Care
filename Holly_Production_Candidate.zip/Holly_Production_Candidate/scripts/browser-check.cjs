const { chromium }=require('playwright');const path=require('path');
(async()=>{const browser=await chromium.launch({channel:'chrome',headless:true});try{
const page=await browser.newPage({viewport:{width:1400,height:1000}});const errors=[];page.on('pageerror',e=>errors.push(e.message));
await page.goto('file://'+path.resolve(__dirname,'../component-preview/index.html'));
if(await page.locator('c-product-carousel-widget .carousel__next').count())throw Error('Product arrows must be absent');
if(await page.locator('c-product-carousel-widget .product-intro').count()>1)throw Error('Product introduction must be absent');
await page.getByRole('button',{name:'Compare products',exact:true}).click();
const checks=page.locator('c-product-carousel-widget input[type=checkbox]');await checks.nth(0).check();await checks.nth(1).check();
await page.getByRole('button',{name:'Compare',exact:true}).click();await page.waitForTimeout(300);
if(!await page.locator('#events').innerText().then(t=>t.includes('items 499LOV1465,599LOV1420')))throw Error('Compare did not send actual component request');
if(await page.locator('c-product-carousel-widget table').count()!==1)throw Error('Comparison renderer missing');
await page.screenshot({path:path.resolve(__dirname,'../docs/actual-lwc-desktop.png'),fullPage:true});
await page.setViewportSize({width:390,height:844});await page.screenshot({path:path.resolve(__dirname,'../docs/actual-lwc-mobile.png'),fullPage:true});
if(!await page.locator('c-rewards-support-widget h3').innerText().then(t=>t==='Crown Rewards'))throw Error('Crown Rewards card heading missing');
await page.goto('file://'+path.resolve(__dirname,'../component-preview/welcome.html'));
await page.evaluate(()=>{for(let i=sessionStorage.length-1;i>=0;i--){const k=sessionStorage.key(i);if(k.startsWith('holly.welcome.dismissed.v2:'))sessionStorage.removeItem(k);}});await page.reload();
await page.setViewportSize({width:1200,height:1050});
await page.waitForTimeout(400);
if(!await page.locator('c-holly-care-header .welcome-choices').innerText().then(t=>t.includes('How can I help you today')))throw Error('Header welcome text missing');
if((await page.locator('#welcome').innerText()).trim())throw Error('Duplicate agent welcome must be empty');
if(await page.getByRole('button',{name:'Dismiss welcome banner'}).count())throw Error('Dismiss button must not exist');
if(await page.locator('c-holly-care-header .welcome-choice').count()!==7)throw Error('Seven welcome choices required');
await page.getByRole('button',{name:'Conversation options',exact:true}).click();
await page.getByRole('button',{name:'Request Chat Transcript',exact:true}).click();
if(!await page.locator('#status').innerText().then(t=>t.includes('transcript')))throw Error('Transcript event missing');
await page.getByRole('button',{name:'Conversation options',exact:true}).click();
await page.getByRole('button',{name:'End chat',exact:true}).click();
if(!await page.locator('#status').innerText().then(t=>t.includes('end')))throw Error('End event missing');
await page.getByRole('button',{name:'Minimize chat',exact:true}).click();
if(!await page.locator('#status').innerText().then(t=>t.includes('minimize')))throw Error('Minimize event missing');
await page.getByRole('button',{name:'Conversation options',exact:true}).click();
await page.screenshot({path:path.resolve(__dirname,'../docs/welcome-experience.png'),fullPage:true});
await page.reload();
if(await page.locator('c-holly-care-header .welcome-choice').count()!==7)throw Error('Untouched refresh hid welcome');
await page.evaluate(()=>{const h=document.querySelector('c-holly-care-header');h.conversationStatus='CLOSED';h.conversationStatus='OPEN';});
await page.getByRole('button',{name:'Check my Crown Rewards points',exact:true}).waitFor({state:'visible'});
await page.getByRole('button',{name:'Check my Crown Rewards points',exact:true}).click();
if(!await page.locator('#status').innerText().then(t=>t.includes('Selected: Check my Crown Rewards points')))throw Error('Welcome selection was not delivered');
for(const [label,expected] of [['Help me find a birthday gift','Birthday Balloons Mug'],['Where is my order?','Order Number, Email Address or Phone Number'],['Check my Crown Rewards points','Crown Rewards Number, Email Address, or Phone Number'],['Hallmark+ membership help','email address or phone number']]){
 await page.evaluate(()=>{for(let i=sessionStorage.length-1;i>=0;i--){const k=sessionStorage.key(i);if(k.startsWith('holly.welcome.dismissed.v2:'))sessionStorage.removeItem(k);}});await page.reload();await page.getByRole('button',{name:label,exact:true}).click();
 if(label.includes('birthday')){await page.locator('c-product-carousel-widget').getByRole('link',{name:'Birthday Balloons Mug, 16 oz.',exact:true}).first().waitFor({state:'visible'});}
 else if(!await page.locator('#welcome').innerText().then(t=>t.includes(expected)))throw Error('Missing lookup prompt: '+label);
}
await page.evaluate(()=>document.fonts.ready);
if(errors.length)throw Error(errors.join('\n')); console.log('PASS: actual LWC mounting, product checkbox selection, message delivery, comparison rendering, desktop/mobile screenshots; no browser errors');
}finally{await browser.close();}})().catch(e=>{console.error(e);process.exit(1)});

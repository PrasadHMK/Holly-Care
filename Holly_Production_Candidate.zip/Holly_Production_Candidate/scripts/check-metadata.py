from pathlib import Path
import json,re,xml.etree.ElementTree as ET
p=Path(__file__).resolve().parents[1];b=p/'force-app/main/default'
for f in b.rglob('*.xml'):ET.parse(f)
for f in b.rglob('*.json'):json.loads(f.read_text())
s=(p/'agent-script/Hallmark_Holly_Care_v4.yaml').read_text()
for typ,widget in [('OrderAgentResponse','orderSearchWidget'),('RewardsAgentResponse','rewardsSupportWidget'),('HallmarkPlusAgentResponse','hallmarkPlusWidget'),('ProductAgentResponse','productCarouselWidget')]:
 pattern=r'complex_data_type_name: "c__'+typ+r'"\n\s+is_displayable: (True|False)'
 flags=re.findall(pattern,s);assert flags and all(x=='True' for x in flags),(typ,flags)
 for channel in ['enhancedWebChat','lightningDesktopGenAi','lightningMobileGenAi']:
  data=json.loads((b/'lightningTypes'/typ/channel/'renderer.json').read_text());assert data['renderer']['componentOverrides']['$']['definition']=='c/'+widget
 schema=json.loads((b/'lightningTypes'/typ/'schema.json').read_text());assert schema['lightning:type']=='@apexClassType/c__'+typ
 wrapper=(b/'classes'/(typ.replace('Response','ActionResult')+'.cls')).read_text();assert re.search(r'\b'+typ+r'\s+renderedResponse\b',wrapper),typ
 assert f'c__{typ}' in (b/'lwc'/widget/(widget+'.js-meta.xml')).read_text()
for f in (b/'classes').glob('*.cls'):assert f.with_name(f.name+'-meta.xml').exists()
print('PASS: XML/JSON, 4 typed renderer contracts on 3 channels, visible action outputs, Apex companion metadata')
print('RELEASE GATE: target agent username and Salesforce compilation still required')

# Check every renderedResponse output regardless of property order or quoted name.
blocks=re.findall(r'^                "?renderedResponse"?: object\n((?:^                    .*\n|^\s*\n)*)',s,re.M)
assert blocks, 'No renderedResponse definitions'
for block in blocks:
 assert 'is_displayable: True' in block, block
 assert re.search(r'complex_data_type_name: "c__(?:Order|Rewards|HallmarkPlus|Product)AgentResponse"',block),block
print(f'PASS: all {len(blocks)} renderedResponse definitions use visible Custom Lightning Types')

import {createElement} from 'lwc';
import Product from 'c/productCarouselWidget';
import Order from 'c/orderSearchWidget';
import Rewards from 'c/rewardsSupportWidget';
import Plus from 'c/hallmarkPlusWidget';
import Header from 'c/hollyCareHeader';
const log=document.querySelector('#events');
const configuration={embeddedServiceMessagingChannel:{authMode:'UnAuth'},util:{sendTextMessage:async text=>{log.textContent=text;document.dispatchEvent(new CustomEvent('previewmessage',{detail:text}));}}};
function mount(id,name,ctor,value){const el=createElement(name,{is:ctor});el.value=value;el.configuration=configuration;document.querySelector('#'+id).appendChild(el);return el;}
const header=mount('header','c-holly-care-header',Header);header.conversationStatus='OPEN';
const products=[
{sku:'499LOV1465',name:'My Partner, My Love, My Friend Romantic Love Card',price:4.99,priceDisplay:'$4.99',category:'Cards',imageUrl:'https://www.hallmark.com/dw/image/v2/AALB_PRD/on/demandware.static/-/Sites-hallmark-master/default/dw25cc2ffc/images/finished-goods/products/499LOV1465/Copper-Heart-on-Blue-Romantic-Love-Card_499499LOV1465_01.jpg?sw=300&sh=300&sm=fit',productUrl:'https://www.hallmark.com/cards/greeting-cards/my-partner-my-love-my-friend-romantic-love-card-499LOV1465.html'},
{sku:'599LOV1420',name:'Your Are the Best Thing Romantic Love Card',price:5.99,priceDisplay:'$5.99',category:'Cards',imageUrl:'https://www.hallmark.com/dw/image/v2/AALB_PRD/on/demandware.static/-/Sites-hallmark-master/default/dw56c3c4d1/images/finished-goods/products/599LOV1420/Gold-Heart-on-Red-Romantic-Love-Card_599LOV1420_01.jpg?sw=300&sh=300&sm=fit',productUrl:'https://www.hallmark.com/cards/greeting-cards/your-are-the-best-thing-romantic-love-card-599LOV1420.html'}];
const product=mount('products','c-product-carousel-widget',Product,{summaryMessage:'Finding a card for someone special is a thoughtful way to show you care. Here are a few heartfelt ideas.',followUpQuestion:'What is the occasion? I would love to help you find the perfect match.',responsePayload:JSON.stringify({view:'productCarousel',products,maxCompare:3,suggestedReplies:[{label:'Compare products',action:'compareMode'},{label:'Birthday ideas',text:'Show me birthday gifts'}]})});
mount('orders','c-order-search-widget',Order,{requestType:'search',responsePayload:JSON.stringify({view:'orderDetail',order:{orderNumber:'DEMO-1029384',orderStatus:'Shipped',status:'Shipped',orderDate:'2026-09-18',totalAmount:24.98,shipments:[{shipmentLabel:'Shipment 1',carrier:'UPS',shippedDate:'2026-09-19',arrivalDateRange:'2026-09-23 – 2026-09-25',status:'Shipped',trackingUrl:'https://www.ups.com/track',trackingNumber:'DEMO-TRACKING',items:[{name:'Greeting card',productName:'Greeting card',description:'Greeting card',productDescription:'Greeting card',quantity:2}]}]}})});
mount('rewards','c-rewards-support-widget',Rewards,{responsePayload:JSON.stringify({view:'memberOverview',crownRewardsNumber:'99888989',membershipTier:'Platinum',pointsBalance:1250,pointsToPlatinum:0}),summaryMessage:'Your Crown Rewards membership'});
mount('plus','c-hallmark-plus-widget',Plus,{membershipFound:true,membershipSource:'Hallmark.com',autoRenewEnabled:true,nextPaymentDate:'2026-12-05'});
document.addEventListener('previewheader',e=>{log.textContent='Header event: '+e.detail;});
document.addEventListener('previewmessage',e=>{if(e.detail.startsWith('Compare ')){product.value={responsePayload:JSON.stringify({view:'productCompare',products,rows:[{label:'Price',values:['$4.99','$5.99']},{label:'Type',values:['Greeting card','Greeting card']}],suggestedReplies:[]})};}});

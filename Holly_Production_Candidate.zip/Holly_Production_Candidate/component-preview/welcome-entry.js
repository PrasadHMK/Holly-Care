import {createElement} from 'lwc';
import Header from 'c/hollyCareHeader';
import Product from 'c/productCarouselWidget';
import welcome from './welcome-text.json';
const transcript=document.querySelector('#welcome');
const status=document.querySelector('#status');
let awaiting='';
const mug={sku:'1MUG3543',name:'Birthday Balloons Mug, 16 oz.',category:'Gifts',price:16.99,priceDisplay:'$16.99',imageUrl:'https://www.hallmark.com/dw/image/v2/AALB_PRD/on/demandware.static/-/Sites-hallmark-master/default/dwcbee3d77/images/finished-goods/products/1MUG3543/Birthday-Balloons-Mug_1MUG3543_01.jpg?sw=400&sh=400&sm=fit',productUrl:'https://www.hallmark.com/house-and-home/kitchen/mugs/birthday-balloons-mug-16-oz.-1MUG3543.html'};
const card={sku:'499LOV1465',name:'My Partner, My Love, My Friend Romantic Love Card',category:'Cards',price:4.99,priceDisplay:'$4.99',imageUrl:'https://www.hallmark.com/dw/image/v2/AALB_PRD/on/demandware.static/-/Sites-hallmark-master/default/dw25cc2ffc/images/finished-goods/products/499LOV1465/Copper-Heart-on-Blue-Romantic-Love-Card_499499LOV1465_01.jpg?sw=400&sh=400&sm=fit',productUrl:'https://www.hallmark.com/cards/greeting-cards/my-partner-my-love-my-friend-romantic-love-card-499LOV1465.html'};
const witch={sku:'1HGN5340',name:'Brew a Potion With Me Witch Plush',category:'Gifts',price:39.99,priceDisplay:'$39.99',imageUrl:'https://www.hallmark.com/dw/image/v2/AALB_PRD/on/demandware.static/-/Sites-hallmark-master/default/dw885bf056/images/finished-goods/products/1HGN5340/Plush-Friendly-Witch-with-Sound-and-Motion_1HGN5340_01.jpg?sw=400&sh=400&sm=fit',productUrl:'https://www.hallmark.com/stuffed-animals/interactive-stuffed-animals/brew-a-potion-with-me-witch-plush-with-sound-and-motion-12.5-1HGN5340.html'};
function say(text,user=false){const p=document.createElement('p');p.className=user?'user-message':'agent-message';p.textContent=text;transcript.appendChild(p);}
const configuration={embeddedServiceMessagingChannel:{authMode:'UnAuth'},util:{sendTextMessage:async text=>respond(text)}};
function products(items){const c=createElement('c-product-carousel-widget',{is:Product});c.configuration=configuration;c.value={summaryMessage:'Here are a few thoughtful ideas to help you celebrate someone special.',followUpQuestion:'Who are we celebrating, and is there a style or hobby they love?',responsePayload:JSON.stringify({view:'productCarousel',products:items,catalogSource:'DEMO',suggestedReplies:[]})};transcript.appendChild(c);}
async function respond(text){
 el.dismissed=true;
 status.textContent='Selected: '+text+' — local sample response; no Salesforce lookup is performed.';
 say(text,true);const t=text.toLowerCase();
 if(/order/.test(t)){awaiting='order';say('To help you look up your order or check the status, You can share one of the following: Order Number, Email Address or Phone Number.');}
 else if(/crown|rewards/.test(t)){awaiting='rewards';say('To help you look up your Crown Rewards points, I’ll need a bit more information. You can share one of the following: Crown Rewards Number, Email Address, or Phone Number.');}
 else if(/hallmark\+|hallmark plus/.test(t)){awaiting='plus';say('To look up your Hallmark+ membership, could you share your email address or phone number?');}
 else if(/birthday|gift|card|halloween|similar/.test(t)){awaiting='';products(/halloween/.test(t)?[witch]:/birthday|gift/.test(t)?[mug]:[card]);}
 else if(/return|shipping|question/.test(t)){awaiting='faq';say('What would you like to know about returns or shipping?');}
 else if(awaiting){say('This local preview does not access customer records or Knowledge. In the deployed agent, your request continues through the '+({order:'order lookup',rewards:'Crown Rewards lookup',plus:'Hallmark+ lookup',faq:'Knowledge FAQ'}[awaiting])+' action. Please use sample information only.');}
 else say('I can help with cards and gifts, order status, Crown Rewards, or Hallmark+. What would you like to do?');

}
const el=createElement('c-holly-care-header',{is:Header});el.configuration=configuration;el.conversationStatus='OPEN';document.querySelector('#header').appendChild(el);
transcript.textContent=welcome.replace(/<[^>]+>/g,'');
const form=document.querySelector('.composer');const input=form.querySelector('input');input.disabled=false;input.setAttribute('aria-label','Message Holly in local preview');
form.addEventListener('submit',async e=>{e.preventDefault();const text=input.value.trim();if(!text)return;input.value='';await respond(text);});
document.addEventListener('previewheader',e=>{status.textContent='Preview: '+e.detail+' requested. Salesforce handles this in the deployed chat.';});

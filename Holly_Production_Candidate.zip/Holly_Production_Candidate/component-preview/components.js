(() => {
  // Holly_Production_Candidate/node_modules/@lwc/engine-dom/dist/index.js
  function invariant(value, msg) {
    if (!value) {
      throw new Error(`Invariant Violation: ${msg}`);
    }
  }
  function isTrue$1(value, msg) {
    if (!value) {
      throw new Error(`Assert Violation: ${msg}`);
    }
  }
  function isFalse$1(value, msg) {
    if (value) {
      throw new Error(`Assert Violation: ${msg}`);
    }
  }
  function fail(msg) {
    throw new Error(msg);
  }
  var assert = /* @__PURE__ */ Object.freeze({
    __proto__: null,
    fail,
    invariant,
    isFalse: isFalse$1,
    isTrue: isTrue$1
  });
  var {
    /** Detached {@linkcode Object.assign}; see {@link https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Object/assign MDN Reference}. */
    assign,
    /** Detached {@linkcode Object.create}; see {@link https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Object/create MDN Reference}. */
    create,
    /** Detached {@linkcode Object.defineProperties}; see {@link https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Object/defineProperties MDN Reference}. */
    defineProperties,
    /** Detached {@linkcode Object.defineProperty}; see {@link https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Object/defineProperty MDN Reference}. */
    defineProperty,
    /** Detached {@linkcode Object.entries}; see {@link https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Object/entries MDN Reference}. */
    entries,
    /** Detached {@linkcode Object.freeze}; see {@link https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Object/freeze MDN Reference}. */
    freeze,
    /** Detached {@linkcode Object.getOwnPropertyDescriptor}; see {@link https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Object/getOwnPropertyDescriptor MDN Reference}. */
    getOwnPropertyDescriptor: getOwnPropertyDescriptor$1,
    /** Detached {@linkcode Object.getOwnPropertyDescriptors}; see {@link https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Object/getOwnPropertyDescriptors MDN Reference}. */
    getOwnPropertyDescriptors,
    /** Detached {@linkcode Object.getOwnPropertyNames}; see {@link https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Object/getOwnPropertyNames MDN Reference}. */
    getOwnPropertyNames: getOwnPropertyNames$1,
    /** Detached {@linkcode Object.getOwnPropertySymbols}; see {@link https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Object/getOwnPropertySymbols MDN Reference}. */
    getOwnPropertySymbols: getOwnPropertySymbols$1,
    /** Detached {@linkcode Object.getPrototypeOf}; see {@link https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Object/getPrototypeOf MDN Reference}. */
    getPrototypeOf: getPrototypeOf$1,
    /** Detached {@linkcode Object.hasOwnProperty}; see {@link https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Object/hasOwnProperty MDN Reference}. */
    hasOwnProperty: hasOwnProperty$1,
    /** Detached {@linkcode Object.isFrozen}; see {@link https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Object/isFrozen MDN Reference}. */
    isFrozen,
    /** Detached {@linkcode Object.keys}; see {@link https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Object/keys MDN Reference}. */
    keys,
    /** Detached {@linkcode Object.seal}; see {@link https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Object/seal MDN Reference}. */
    seal,
    /** Detached {@linkcode Object.setPrototypeOf}; see {@link https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Object/setPrototypeOf MDN Reference}. */
    setPrototypeOf
  } = Object;
  var {
    /** Detached {@linkcode Array.isArray}; see {@link https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Array/isArray MDN Reference}. */
    isArray: isArray$1,
    /** Detached {@linkcode Array.from}; see {@link https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Array/from MDN Reference}. */
    from: ArrayFrom
  } = Array;
  var {
    copyWithin: ArrayCopyWithin,
    every: ArrayEvery,
    fill: ArrayFill,
    filter: ArrayFilter,
    indexOf: ArrayIndexOf,
    join: ArrayJoin,
    map: ArrayMap,
    pop: ArrayPop,
    push: ArrayPush$1,
    reverse: ArrayReverse,
    shift: ArrayShift,
    slice: ArraySlice,
    some: ArraySome,
    sort: ArraySort,
    splice: ArraySplice,
    unshift: ArrayUnshift,
    forEach
    // Weird anomaly!
  } = Array.prototype;
  var { fromCharCode: StringFromCharCode } = String;
  var { charAt: StringCharAt, charCodeAt: StringCharCodeAt, replace: StringReplace, split: StringSplit, slice: StringSlice, toLowerCase: StringToLowerCase, trim: StringTrim } = String.prototype;
  function isUndefined$1(obj) {
    return obj === void 0;
  }
  function isNull(obj) {
    return obj === null;
  }
  function isTrue(obj) {
    return obj === true;
  }
  function isFalse(obj) {
    return obj === false;
  }
  function isFunction$1(obj) {
    return typeof obj === "function";
  }
  function isObject(obj) {
    return typeof obj === "object";
  }
  function isString(obj) {
    return typeof obj === "string";
  }
  function noop() {
  }
  var OtS = {}.toString;
  function toString(obj) {
    if (obj?.toString) {
      if (isArray$1(obj)) {
        return ArrayJoin.call(ArrayMap.call(obj, toString), ",");
      }
      return obj.toString();
    } else if (typeof obj === "object") {
      return OtS.call(obj);
    } else {
      return String(obj);
    }
  }
  function getPropertyDescriptor(o, p) {
    do {
      const d2 = getOwnPropertyDescriptor$1(o, p);
      if (!isUndefined$1(d2)) {
        return d2;
      }
      o = getPrototypeOf$1(o);
    } while (o !== null);
  }
  var allVersions = [
    58,
    59,
    60,
    61,
    62,
    63,
    64,
    65,
    66
  ];
  var LOWEST_API_VERSION = allVersions[0];
  function minApiVersion(apiVersionFeature) {
    switch (apiVersionFeature) {
      case 0:
      case 1:
        return 59;
      case 3:
      case 4:
      case 5:
      case 2:
        return 60;
      case 7:
      case 6:
        return 61;
      case 8:
      case 9:
      case 10:
        return 62;
      case 11:
        return 66;
    }
  }
  function isAPIFeatureEnabled(apiVersionFeature, apiVersion) {
    return apiVersion >= minApiVersion(apiVersionFeature);
  }
  var AriaPropertyNames = [
    "ariaActiveDescendant",
    "ariaAtomic",
    "ariaAutoComplete",
    "ariaBusy",
    "ariaChecked",
    "ariaColCount",
    "ariaColIndex",
    "ariaColIndexText",
    "ariaColSpan",
    "ariaControls",
    "ariaCurrent",
    "ariaDescribedBy",
    "ariaDescription",
    "ariaDetails",
    "ariaDisabled",
    "ariaErrorMessage",
    "ariaExpanded",
    "ariaFlowTo",
    "ariaHasPopup",
    "ariaHidden",
    "ariaInvalid",
    "ariaKeyShortcuts",
    "ariaLabel",
    "ariaLabelledBy",
    "ariaLevel",
    "ariaLive",
    "ariaModal",
    "ariaMultiLine",
    "ariaMultiSelectable",
    "ariaOrientation",
    "ariaOwns",
    "ariaPlaceholder",
    "ariaPosInSet",
    "ariaPressed",
    "ariaReadOnly",
    "ariaRelevant",
    "ariaRequired",
    "ariaRoleDescription",
    "ariaRowCount",
    "ariaRowIndex",
    "ariaRowIndexText",
    "ariaRowSpan",
    "ariaSelected",
    "ariaSetSize",
    "ariaSort",
    "ariaValueMax",
    "ariaValueMin",
    "ariaValueNow",
    "ariaValueText",
    "ariaBrailleLabel",
    "ariaBrailleRoleDescription",
    "role"
  ];
  var { AriaAttrNameToPropNameMap, AriaPropNameToAttrNameMap } = /* @__PURE__ */ (() => {
    const AriaAttrNameToPropNameMap2 = create(null);
    const AriaPropNameToAttrNameMap2 = create(null);
    forEach.call(AriaPropertyNames, (propName) => {
      const attrName = StringToLowerCase.call(StringReplace.call(propName, /^aria/, () => "aria-"));
      AriaAttrNameToPropNameMap2[attrName] = propName;
      AriaPropNameToAttrNameMap2[propName] = attrName;
    });
    return { AriaAttrNameToPropNameMap: AriaAttrNameToPropNameMap2, AriaPropNameToAttrNameMap: AriaPropNameToAttrNameMap2 };
  })();
  var ID_REFERENCING_ATTRIBUTES_SET = /* @__PURE__ */ new Set([
    "aria-activedescendant",
    "aria-controls",
    "aria-describedby",
    "aria-details",
    "aria-errormessage",
    "aria-flowto",
    "aria-labelledby",
    "aria-owns",
    "for",
    "popovertarget"
  ]);
  var ContextEventName = "lightning:context-request";
  var trustedContext;
  var contextKeys;
  function getContextKeys() {
    return contextKeys;
  }
  function isTrustedContext(target) {
    if (!trustedContext) {
      return true;
    }
    return trustedContext.has(target);
  }
  var KEY__SHADOW_RESOLVER = "$shadowResolver$";
  var KEY__SHADOW_STATIC = "$shadowStaticNode$";
  var KEY__SHADOW_TOKEN = "$shadowToken$";
  var KEY__SYNTHETIC_MODE = "$$lwc-synthetic-mode";
  var KEY__SCOPED_CSS = "$scoped$";
  var KEY__NATIVE_ONLY_CSS = "$nativeOnly$";
  var KEY__NATIVE_GET_ELEMENT_BY_ID = "$nativeGetElementById$";
  var KEY__NATIVE_QUERY_SELECTOR_ALL = "$nativeQuerySelectorAll$";
  var XML_NAMESPACE = "http://www.w3.org/XML/1998/namespace";
  var SVG_NAMESPACE = "http://www.w3.org/2000/svg";
  var XLINK_NAMESPACE = "http://www.w3.org/1999/xlink";
  var CAMEL_REGEX = /-([a-z])/g;
  var SPECIAL_PROPERTY_ATTRIBUTE_MAPPING = /* @__PURE__ */ new Map([
    ["accessKey", "accesskey"],
    ["readOnly", "readonly"],
    ["tabIndex", "tabindex"],
    ["bgColor", "bgcolor"],
    ["colSpan", "colspan"],
    ["rowSpan", "rowspan"],
    ["contentEditable", "contenteditable"],
    ["crossOrigin", "crossorigin"],
    ["dateTime", "datetime"],
    ["formAction", "formaction"],
    ["isMap", "ismap"],
    ["maxLength", "maxlength"],
    ["minLength", "minlength"],
    ["noValidate", "novalidate"],
    ["useMap", "usemap"],
    ["htmlFor", "for"]
  ]);
  var REFLECTIVE_GLOBAL_PROPERTY_SET = /* @__PURE__ */ new Set([
    "accessKey",
    "dir",
    "draggable",
    "hidden",
    "id",
    "lang",
    "spellcheck",
    "tabIndex",
    "title"
  ]);
  var CACHED_PROPERTY_ATTRIBUTE_MAPPING = /* @__PURE__ */ new Map();
  function htmlPropertyToAttribute(propName) {
    const ariaAttributeName = AriaPropNameToAttrNameMap[propName];
    if (!isUndefined$1(ariaAttributeName)) {
      return ariaAttributeName;
    }
    const specialAttributeName = SPECIAL_PROPERTY_ATTRIBUTE_MAPPING.get(propName);
    if (!isUndefined$1(specialAttributeName)) {
      return specialAttributeName;
    }
    const cachedAttributeName = CACHED_PROPERTY_ATTRIBUTE_MAPPING.get(propName);
    if (!isUndefined$1(cachedAttributeName)) {
      return cachedAttributeName;
    }
    let attributeName = "";
    for (let i2 = 0, len = propName.length; i2 < len; i2++) {
      const code = StringCharCodeAt.call(propName, i2);
      if (code >= 65 && // "A"
      code <= 90) {
        attributeName += "-" + StringFromCharCode(code + 32);
      } else {
        attributeName += StringFromCharCode(code);
      }
    }
    CACHED_PROPERTY_ATTRIBUTE_MAPPING.set(propName, attributeName);
    return attributeName;
  }
  var CACHED_KEBAB_CAMEL_MAPPING = /* @__PURE__ */ new Map();
  function kebabCaseToCamelCase(attrName) {
    let result = CACHED_KEBAB_CAMEL_MAPPING.get(attrName);
    if (isUndefined$1(result)) {
      result = StringReplace.call(attrName, CAMEL_REGEX, (g) => g[1].toUpperCase());
      CACHED_KEBAB_CAMEL_MAPPING.set(attrName, result);
    }
    return result;
  }
  function normalizeClass(value) {
    if (isUndefined$1(value) || isNull(value)) {
      return void 0;
    }
    let res = "";
    if (isString(value)) {
      res = value;
    } else if (isArray$1(value)) {
      for (let i2 = 0; i2 < value.length; i2++) {
        const normalized = normalizeClass(value[i2]);
        if (normalized) {
          res += normalized + " ";
        }
      }
    } else if (isObject(value) && !isNull(value)) {
      const _keys = keys(value);
      for (let i2 = 0; i2 < _keys.length; i2 += 1) {
        const key = _keys[i2];
        if (value[key]) {
          res += key + " ";
        }
      }
    }
    return StringTrim.call(res);
  }
  var sanitizeHtmlContentImpl = () => {
    throw new Error("sanitizeHtmlContent hook must be implemented.");
  };
  var sanitizeHtmlContent = (value) => {
    return sanitizeHtmlContentImpl(value);
  };
  function flattenStylesheets(stylesheets) {
    const list = [];
    for (const stylesheet6 of stylesheets) {
      if (!isArray$1(stylesheet6)) {
        list.push(stylesheet6);
      } else {
        list.push(...flattenStylesheets(stylesheet6));
      }
    }
    return list;
  }
  var trustedSignals;
  function legacyIsTrustedSignal(target) {
    if (!trustedSignals) {
      return true;
    }
    return trustedSignals.has(target);
  }
  function isTrustedSignal(target) {
    if (!trustedSignals) {
      return false;
    }
    return trustedSignals.has(target);
  }
  if (!globalThis.lwcRuntimeFlags) {
    Object.defineProperty(globalThis, "lwcRuntimeFlags", { value: create(null) });
  }
  var flags = globalThis.lwcRuntimeFlags;
  var onReportingEnabledCallbacks = [];
  var currentDispatcher$1 = noop;
  var enabled$1 = false;
  function onReportingEnabled(callback) {
    if (enabled$1) {
      callback();
    } else {
      onReportingEnabledCallbacks.push(callback);
    }
  }
  function report(reportingEventId, payload) {
    if (enabled$1) {
      currentDispatcher$1(reportingEventId, payload);
    }
  }
  function isReportingEnabled() {
    return enabled$1;
  }
  function getComponentTag(vm) {
    return `<${StringToLowerCase.call(vm.tagName)}>`;
  }
  function getComponentStack(vm) {
    const stack = [];
    let prefix = "";
    while (!isNull(vm.owner)) {
      ArrayPush$1.call(stack, prefix + getComponentTag(vm));
      vm = vm.owner;
      prefix += "	";
    }
    return ArrayJoin.call(stack, "\n");
  }
  function getErrorComponentStack(vm) {
    const wcStack = [];
    let currentVm = vm;
    while (!isNull(currentVm)) {
      ArrayPush$1.call(wcStack, getComponentTag(currentVm));
      currentVm = currentVm.owner;
    }
    return wcStack.reverse().join("\n	");
  }
  function addErrorComponentStack(vm, error) {
    if (!isFrozen(error) && isUndefined$1(error.wcStack)) {
      const wcStack = getErrorComponentStack(vm);
      defineProperty(error, "wcStack", {
        get() {
          return wcStack;
        }
      });
    }
  }
  var alreadyLoggedMessages = /* @__PURE__ */ new Set();
  if (false) {
    window.__lwcResetAlreadyLoggedMessages = () => {
      alreadyLoggedMessages.clear();
    };
  }
  function log(method, message, vm, once) {
    let msg = `[LWC ${method}]: ${message}`;
    if (!isUndefined$1(vm)) {
      msg = `${msg}
${getComponentStack(vm)}`;
    }
    if (once) {
      if (alreadyLoggedMessages.has(msg)) {
        return;
      }
      alreadyLoggedMessages.add(msg);
    }
    if (false) {
      console[method](msg);
      return;
    }
    try {
      throw new Error(msg);
    } catch (e) {
      console[method](e);
    }
  }
  function logError(message, vm) {
    log("error", message, vm, false);
  }
  function logWarnOnce(message, vm) {
    log("warn", message, vm, true);
  }
  var nextTickCallbackQueue = [];
  var SPACE_CHAR = 32;
  var EmptyObject = seal(create(null));
  var EmptyArray = seal([]);
  function flushCallbackQueue() {
    if (false) {
      if (nextTickCallbackQueue.length === 0) {
        throw new Error(`Internal Error: If callbackQueue is scheduled, it is because there must be at least one callback on this pending queue.`);
      }
    }
    const callbacks = nextTickCallbackQueue;
    nextTickCallbackQueue = [];
    for (let i2 = 0, len = callbacks.length; i2 < len; i2 += 1) {
      callbacks[i2]();
    }
  }
  function addCallbackToNextTick(callback) {
    if (false) {
      if (!isFunction$1(callback)) {
        throw new Error(`Internal Error: addCallbackToNextTick() can only accept a function callback`);
      }
    }
    if (nextTickCallbackQueue.length === 0) {
      Promise.resolve().then(flushCallbackQueue);
    }
    ArrayPush$1.call(nextTickCallbackQueue, callback);
  }
  function shouldBeFormAssociated(Ctor) {
    const ctorFormAssociated = Boolean(Ctor.formAssociated);
    const apiVersion = getComponentAPIVersion(Ctor);
    const apiFeatureEnabled = isAPIFeatureEnabled(7, apiVersion);
    if (false) {
      const tagName = getComponentRegisteredName(Ctor);
      logWarnOnce(`Component <${tagName}> set static formAssociated to true, but form association is not enabled because the API version is ${apiVersion}. To enable form association, update the LWC component API version to 61 or above. https://lwc.dev/guide/versioning`);
    }
    return ctorFormAssociated && apiFeatureEnabled;
  }
  var TargetToReactiveRecordMap = /* @__PURE__ */ new WeakMap();
  function getReactiveRecord(target) {
    let reactiveRecord = TargetToReactiveRecordMap.get(target);
    if (isUndefined$1(reactiveRecord)) {
      const newRecord = create(null);
      reactiveRecord = newRecord;
      TargetToReactiveRecordMap.set(target, newRecord);
    }
    return reactiveRecord;
  }
  var currentReactiveObserver = null;
  function valueMutated(target, key) {
    const reactiveRecord = TargetToReactiveRecordMap.get(target);
    if (!isUndefined$1(reactiveRecord)) {
      const reactiveObservers = reactiveRecord[key];
      if (!isUndefined$1(reactiveObservers)) {
        for (let i2 = 0, len = reactiveObservers.length; i2 < len; i2 += 1) {
          const ro = reactiveObservers[i2];
          if (false) {
            logMutation(ro, target, key);
          }
          ro.notify();
        }
      }
    }
  }
  function valueObserved(target, key) {
    if (currentReactiveObserver === null) {
      return;
    }
    const ro = currentReactiveObserver;
    const reactiveRecord = getReactiveRecord(target);
    let reactiveObservers = reactiveRecord[key];
    if (isUndefined$1(reactiveObservers)) {
      reactiveObservers = [];
      reactiveRecord[key] = reactiveObservers;
    } else if (reactiveObservers[0] === ro) {
      return;
    }
    if (ArrayIndexOf.call(reactiveObservers, ro) === -1) {
      ro.link(reactiveObservers);
    }
  }
  var ReactiveObserver = class {
    constructor(callback) {
      this.listeners = [];
      this.callback = callback;
    }
    observe(job) {
      const inceptionReactiveRecord = currentReactiveObserver;
      currentReactiveObserver = this;
      let error;
      try {
        job();
      } catch (e) {
        error = Object(e);
      } finally {
        currentReactiveObserver = inceptionReactiveRecord;
        if (error !== void 0) {
          throw error;
        }
      }
    }
    /**
     * This method is responsible for disconnecting the Reactive Observer
     * from any Reactive Record that has a reference to it, to prevent future
     * notifications about previously recorded access.
     */
    reset() {
      const { listeners } = this;
      const len = listeners.length;
      if (len > 0) {
        for (let i2 = 0; i2 < len; i2++) {
          const set = listeners[i2];
          const setLength = set.length;
          if (setLength > 1) {
            const index = ArrayIndexOf.call(set, this);
            set[index] = set[setLength - 1];
          }
          ArrayPop.call(set);
        }
        listeners.length = 0;
      }
    }
    // friend methods
    notify() {
      this.callback.call(void 0, this);
    }
    link(reactiveObservers) {
      ArrayPush$1.call(reactiveObservers, this);
      ArrayPush$1.call(this.listeners, reactiveObservers);
    }
    isObserving() {
      return currentReactiveObserver === this;
    }
  };
  var TargetToSignalTrackerMap = /* @__PURE__ */ new WeakMap();
  function getSignalTracker(target) {
    let signalTracker = TargetToSignalTrackerMap.get(target);
    if (isUndefined$1(signalTracker)) {
      signalTracker = new SignalTracker();
      TargetToSignalTrackerMap.set(target, signalTracker);
    }
    return signalTracker;
  }
  function subscribeToSignal(target, signal, update) {
    const signalTracker = getSignalTracker(target);
    if (isFalse(signalTracker.seen(signal))) {
      signalTracker.subscribeToSignal(signal, update);
    }
  }
  function unsubscribeFromSignals(target) {
    if (TargetToSignalTrackerMap.has(target)) {
      const signalTracker = getSignalTracker(target);
      signalTracker.unsubscribeFromSignals();
      signalTracker.reset();
    }
  }
  var errorWithStack = (err) => {
    if (typeof err !== "object" || err === null) {
      return String(err);
    }
    const stack = "stack" in err ? String(err.stack) : "";
    const message = "message" in err ? String(err.message) : "";
    const constructor = err.constructor.name;
    return stack.includes(message) ? stack : `${constructor}: ${message}
${stack}`;
  };
  var SignalTracker = class {
    constructor() {
      this.signalToUnsubscribeMap = /* @__PURE__ */ new Map();
    }
    seen(signal) {
      return this.signalToUnsubscribeMap.has(signal);
    }
    subscribeToSignal(signal, update) {
      try {
        const unsubscribe = signal.subscribe(update);
        if (isFunction$1(unsubscribe)) {
          this.signalToUnsubscribeMap.set(signal, unsubscribe);
        }
      } catch (err) {
        logWarnOnce(`Attempted to subscribe to an object that has the shape of a signal but received the following error: ${errorWithStack(err)}`);
      }
    }
    unsubscribeFromSignals() {
      try {
        this.signalToUnsubscribeMap.forEach((unsubscribe) => unsubscribe());
      } catch (err) {
        logWarnOnce(`Attempted to call a signal's unsubscribe callback but received the following error: ${errorWithStack(err)}`);
      }
    }
    reset() {
      this.signalToUnsubscribeMap.clear();
    }
  };
  function componentValueMutated(vm, key) {
    {
      valueMutated(vm.component, key);
    }
  }
  function componentValueObserved(vm, key, target = {}) {
    const { component, tro } = vm;
    {
      valueObserved(component, key);
    }
    if (lwcRuntimeFlags.ENABLE_EXPERIMENTAL_SIGNALS && isObject(target) && !isNull(target) && true && // Only subscribe if a template is being rendered by the engine
    tro.isObserving()) {
      if (lwcRuntimeFlags.ENABLE_LEGACY_SIGNAL_CONTEXT_VALIDATION ? legacyIsTrustedSignal(target) : isTrustedSignal(target)) {
        subscribeToSignal(component, target, tro.notify.bind(tro));
      }
    }
  }
  function createReactiveObserver(callback) {
    return new ReactiveObserver(callback);
  }
  function resolveCircularModuleDependency(fn) {
    const module = fn();
    return module?.__esModule ? module.default : module;
  }
  function isCircularModuleDependency(obj) {
    return isFunction$1(obj) && hasOwnProperty$1.call(obj, "__circular__");
  }
  var instrumentDef = globalThis.__lwc_instrument_cmp_def ?? noop;
  var instrumentInstance = globalThis.__lwc_instrument_cmp_instance ?? noop;
  var HTMLElementConstructor = typeof HTMLElement !== "undefined" ? HTMLElement : function() {
  };
  var HTMLElementPrototype = HTMLElementConstructor.prototype;
  var ariaReflectionPolyfillDescriptors = create(null);
  for (const [propName, attrName] of entries(AriaPropNameToAttrNameMap)) {
    if (isUndefined$1(getPropertyDescriptor(HTMLElementPrototype, propName))) {
      ariaReflectionPolyfillDescriptors[propName] = {
        get() {
          return this.getAttribute(attrName);
        },
        set(newValue) {
          if (isNull(newValue)) {
            this.removeAttribute(attrName);
          } else {
            this.setAttribute(attrName, newValue);
          }
        },
        // configurable and enumerable to allow it to be overridden – this mimics Safari's/Chrome's behavior
        configurable: true,
        enumerable: true
      };
    }
  }
  for (const [attrName, propName] of entries(AriaAttrNameToPropNameMap)) {
  }
  var HTMLElementOriginalDescriptors = create(null);
  forEach.call(keys(AriaPropNameToAttrNameMap), (propName) => {
    const descriptor = getPropertyDescriptor(HTMLElementPrototype, propName);
    if (!isUndefined$1(descriptor)) {
      HTMLElementOriginalDescriptors[propName] = descriptor;
    }
  });
  for (const propName of REFLECTIVE_GLOBAL_PROPERTY_SET) {
    const descriptor = getPropertyDescriptor(HTMLElementPrototype, propName);
    if (!isUndefined$1(descriptor)) {
      HTMLElementOriginalDescriptors[propName] = descriptor;
    }
  }
  function updateComponentValue(vm, key, newValue) {
    const { cmpFields } = vm;
    if (newValue !== cmpFields[key]) {
      cmpFields[key] = newValue;
      componentValueMutated(vm, key);
    }
  }
  var { isArray } = Array;
  var { prototype: ObjectDotPrototype, getPrototypeOf, create: ObjectCreate, defineProperty: ObjectDefineProperty, isExtensible, getOwnPropertyDescriptor, getOwnPropertyNames, getOwnPropertySymbols, preventExtensions, hasOwnProperty } = Object;
  var { push: ArrayPush, concat: ArrayConcat } = Array.prototype;
  function isUndefined(obj) {
    return obj === void 0;
  }
  function isFunction(obj) {
    return typeof obj === "function";
  }
  var proxyToValueMap = /* @__PURE__ */ new WeakMap();
  function registerProxy(proxy, value) {
    proxyToValueMap.set(proxy, value);
  }
  var unwrap$1 = (replicaOrAny) => proxyToValueMap.get(replicaOrAny) || replicaOrAny;
  var BaseProxyHandler = class {
    constructor(membrane, value) {
      this.originalTarget = value;
      this.membrane = membrane;
    }
    // Shared utility methods
    wrapDescriptor(descriptor) {
      if (hasOwnProperty.call(descriptor, "value")) {
        descriptor.value = this.wrapValue(descriptor.value);
      } else {
        const { set: originalSet, get: originalGet } = descriptor;
        if (!isUndefined(originalGet)) {
          descriptor.get = this.wrapGetter(originalGet);
        }
        if (!isUndefined(originalSet)) {
          descriptor.set = this.wrapSetter(originalSet);
        }
      }
      return descriptor;
    }
    copyDescriptorIntoShadowTarget(shadowTarget, key) {
      const { originalTarget } = this;
      const originalDescriptor = getOwnPropertyDescriptor(originalTarget, key);
      if (!isUndefined(originalDescriptor)) {
        const wrappedDesc = this.wrapDescriptor(originalDescriptor);
        ObjectDefineProperty(shadowTarget, key, wrappedDesc);
      }
    }
    lockShadowTarget(shadowTarget) {
      const { originalTarget } = this;
      const targetKeys = ArrayConcat.call(getOwnPropertyNames(originalTarget), getOwnPropertySymbols(originalTarget));
      targetKeys.forEach((key) => {
        this.copyDescriptorIntoShadowTarget(shadowTarget, key);
      });
      const { membrane: { tagPropertyKey } } = this;
      if (!isUndefined(tagPropertyKey) && !hasOwnProperty.call(shadowTarget, tagPropertyKey)) {
        ObjectDefineProperty(shadowTarget, tagPropertyKey, ObjectCreate(null));
      }
      preventExtensions(shadowTarget);
    }
    // Shared Traps
    // TODO: apply() is never called
    /* istanbul ignore next */
    apply(shadowTarget, thisArg, argArray) {
    }
    // TODO: construct() is never called
    /* istanbul ignore next */
    construct(shadowTarget, argArray, newTarget) {
    }
    get(shadowTarget, key) {
      const { originalTarget, membrane: { valueObserved: valueObserved2 } } = this;
      const value = originalTarget[key];
      valueObserved2(originalTarget, key);
      return this.wrapValue(value);
    }
    has(shadowTarget, key) {
      const { originalTarget, membrane: { tagPropertyKey, valueObserved: valueObserved2 } } = this;
      valueObserved2(originalTarget, key);
      return key in originalTarget || key === tagPropertyKey;
    }
    ownKeys(shadowTarget) {
      const { originalTarget, membrane: { tagPropertyKey } } = this;
      const keys2 = isUndefined(tagPropertyKey) || hasOwnProperty.call(originalTarget, tagPropertyKey) ? [] : [tagPropertyKey];
      ArrayPush.apply(keys2, getOwnPropertyNames(originalTarget));
      ArrayPush.apply(keys2, getOwnPropertySymbols(originalTarget));
      return keys2;
    }
    isExtensible(shadowTarget) {
      const { originalTarget } = this;
      if (!isExtensible(shadowTarget)) {
        return false;
      }
      if (!isExtensible(originalTarget)) {
        this.lockShadowTarget(shadowTarget);
        return false;
      }
      return true;
    }
    getPrototypeOf(shadowTarget) {
      const { originalTarget } = this;
      return getPrototypeOf(originalTarget);
    }
    getOwnPropertyDescriptor(shadowTarget, key) {
      const { originalTarget, membrane: { valueObserved: valueObserved2, tagPropertyKey } } = this;
      valueObserved2(originalTarget, key);
      let desc = getOwnPropertyDescriptor(originalTarget, key);
      if (isUndefined(desc)) {
        if (key !== tagPropertyKey) {
          return void 0;
        }
        desc = { value: void 0, writable: false, configurable: false, enumerable: false };
        ObjectDefineProperty(shadowTarget, tagPropertyKey, desc);
        return desc;
      }
      if (desc.configurable === false) {
        this.copyDescriptorIntoShadowTarget(shadowTarget, key);
      }
      return this.wrapDescriptor(desc);
    }
  };
  var getterMap$1 = /* @__PURE__ */ new WeakMap();
  var setterMap$1 = /* @__PURE__ */ new WeakMap();
  var reverseGetterMap = /* @__PURE__ */ new WeakMap();
  var reverseSetterMap = /* @__PURE__ */ new WeakMap();
  var ReactiveProxyHandler = class extends BaseProxyHandler {
    wrapValue(value) {
      return this.membrane.getProxy(value);
    }
    wrapGetter(originalGet) {
      const wrappedGetter = getterMap$1.get(originalGet);
      if (!isUndefined(wrappedGetter)) {
        return wrappedGetter;
      }
      const handler = this;
      const get = function() {
        return handler.wrapValue(originalGet.call(unwrap$1(this)));
      };
      getterMap$1.set(originalGet, get);
      reverseGetterMap.set(get, originalGet);
      return get;
    }
    wrapSetter(originalSet) {
      const wrappedSetter = setterMap$1.get(originalSet);
      if (!isUndefined(wrappedSetter)) {
        return wrappedSetter;
      }
      const set = function(v) {
        originalSet.call(unwrap$1(this), unwrap$1(v));
      };
      setterMap$1.set(originalSet, set);
      reverseSetterMap.set(set, originalSet);
      return set;
    }
    unwrapDescriptor(descriptor) {
      if (hasOwnProperty.call(descriptor, "value")) {
        descriptor.value = unwrap$1(descriptor.value);
      } else {
        const { set, get } = descriptor;
        if (!isUndefined(get)) {
          descriptor.get = this.unwrapGetter(get);
        }
        if (!isUndefined(set)) {
          descriptor.set = this.unwrapSetter(set);
        }
      }
      return descriptor;
    }
    unwrapGetter(redGet) {
      const reverseGetter = reverseGetterMap.get(redGet);
      if (!isUndefined(reverseGetter)) {
        return reverseGetter;
      }
      const handler = this;
      const get = function() {
        return unwrap$1(redGet.call(handler.wrapValue(this)));
      };
      getterMap$1.set(get, redGet);
      reverseGetterMap.set(redGet, get);
      return get;
    }
    unwrapSetter(redSet) {
      const reverseSetter = reverseSetterMap.get(redSet);
      if (!isUndefined(reverseSetter)) {
        return reverseSetter;
      }
      const handler = this;
      const set = function(v) {
        redSet.call(handler.wrapValue(this), handler.wrapValue(v));
      };
      setterMap$1.set(set, redSet);
      reverseSetterMap.set(redSet, set);
      return set;
    }
    set(shadowTarget, key, value) {
      const { originalTarget, membrane: { valueMutated: valueMutated2 } } = this;
      const oldValue = originalTarget[key];
      if (oldValue !== value) {
        originalTarget[key] = value;
        valueMutated2(originalTarget, key);
      } else if (key === "length" && isArray(originalTarget)) {
        valueMutated2(originalTarget, key);
      }
      return true;
    }
    deleteProperty(shadowTarget, key) {
      const { originalTarget, membrane: { valueMutated: valueMutated2 } } = this;
      delete originalTarget[key];
      valueMutated2(originalTarget, key);
      return true;
    }
    setPrototypeOf(shadowTarget, prototype) {
    }
    preventExtensions(shadowTarget) {
      if (isExtensible(shadowTarget)) {
        const { originalTarget } = this;
        preventExtensions(originalTarget);
        if (isExtensible(originalTarget)) {
          return false;
        }
        this.lockShadowTarget(shadowTarget);
      }
      return true;
    }
    defineProperty(shadowTarget, key, descriptor) {
      const { originalTarget, membrane: { valueMutated: valueMutated2, tagPropertyKey } } = this;
      if (key === tagPropertyKey && !hasOwnProperty.call(originalTarget, key)) {
        return true;
      }
      ObjectDefineProperty(originalTarget, key, this.unwrapDescriptor(descriptor));
      if (descriptor.configurable === false) {
        this.copyDescriptorIntoShadowTarget(shadowTarget, key);
      }
      valueMutated2(originalTarget, key);
      return true;
    }
  };
  var getterMap = /* @__PURE__ */ new WeakMap();
  var setterMap = /* @__PURE__ */ new WeakMap();
  var ReadOnlyHandler = class extends BaseProxyHandler {
    wrapValue(value) {
      return this.membrane.getReadOnlyProxy(value);
    }
    wrapGetter(originalGet) {
      const wrappedGetter = getterMap.get(originalGet);
      if (!isUndefined(wrappedGetter)) {
        return wrappedGetter;
      }
      const handler = this;
      const get = function() {
        return handler.wrapValue(originalGet.call(unwrap$1(this)));
      };
      getterMap.set(originalGet, get);
      return get;
    }
    wrapSetter(originalSet) {
      const wrappedSetter = setterMap.get(originalSet);
      if (!isUndefined(wrappedSetter)) {
        return wrappedSetter;
      }
      const set = function(v) {
      };
      setterMap.set(originalSet, set);
      return set;
    }
    set(shadowTarget, key, value) {
      return false;
    }
    deleteProperty(shadowTarget, key) {
      return false;
    }
    setPrototypeOf(shadowTarget, prototype) {
    }
    preventExtensions(shadowTarget) {
      return false;
    }
    defineProperty(shadowTarget, key, descriptor) {
      return false;
    }
  };
  function defaultValueIsObservable(value) {
    if (value === null) {
      return false;
    }
    if (typeof value !== "object") {
      return false;
    }
    if (isArray(value)) {
      return true;
    }
    const proto = getPrototypeOf(value);
    return proto === ObjectDotPrototype || proto === null || getPrototypeOf(proto) === null;
  }
  var defaultValueObserved = (obj, key) => {
  };
  var defaultValueMutated = (obj, key) => {
  };
  function createShadowTarget(value) {
    return isArray(value) ? [] : {};
  }
  var ObservableMembrane = class {
    constructor(options = {}) {
      this.readOnlyObjectGraph = /* @__PURE__ */ new WeakMap();
      this.reactiveObjectGraph = /* @__PURE__ */ new WeakMap();
      const { valueMutated: valueMutated2, valueObserved: valueObserved2, valueIsObservable, tagPropertyKey } = options;
      this.valueMutated = isFunction(valueMutated2) ? valueMutated2 : defaultValueMutated;
      this.valueObserved = isFunction(valueObserved2) ? valueObserved2 : defaultValueObserved;
      this.valueIsObservable = isFunction(valueIsObservable) ? valueIsObservable : defaultValueIsObservable;
      this.tagPropertyKey = tagPropertyKey;
    }
    getProxy(value) {
      const unwrappedValue = unwrap$1(value);
      if (this.valueIsObservable(unwrappedValue)) {
        if (this.readOnlyObjectGraph.get(unwrappedValue) === value) {
          return value;
        }
        return this.getReactiveHandler(unwrappedValue);
      }
      return unwrappedValue;
    }
    getReadOnlyProxy(value) {
      value = unwrap$1(value);
      if (this.valueIsObservable(value)) {
        return this.getReadOnlyHandler(value);
      }
      return value;
    }
    unwrapProxy(p) {
      return unwrap$1(p);
    }
    getReactiveHandler(value) {
      let proxy = this.reactiveObjectGraph.get(value);
      if (isUndefined(proxy)) {
        const handler = new ReactiveProxyHandler(this, value);
        proxy = new Proxy(createShadowTarget(value), handler);
        registerProxy(proxy, value);
        this.reactiveObjectGraph.set(value, proxy);
      }
      return proxy;
    }
    getReadOnlyHandler(value) {
      let proxy = this.readOnlyObjectGraph.get(value);
      if (isUndefined(proxy)) {
        const handler = new ReadOnlyHandler(this, value);
        proxy = new Proxy(createShadowTarget(value), handler);
        registerProxy(proxy, value);
        this.readOnlyObjectGraph.set(value, proxy);
      }
      return proxy;
    }
  };
  var lockerLivePropertyKey = Symbol.for("@@lockerLiveValue");
  var reactiveMembrane = new ObservableMembrane({
    valueObserved,
    valueMutated,
    tagPropertyKey: lockerLivePropertyKey
  });
  function getReadOnlyProxy(value) {
    return reactiveMembrane.getReadOnlyProxy(value);
  }
  function getReactiveProxy(value) {
    return reactiveMembrane.getProxy(value);
  }
  function markLockerLiveObject(obj) {
    {
      obj[lockerLivePropertyKey] = void 0;
    }
  }
  var globalStylesheet;
  function isStyleElement(elm) {
    return elm.tagName === "STYLE";
  }
  async function fetchStylesheet(elm) {
    if (isStyleElement(elm)) {
      return elm.textContent;
    } else {
      const { href } = elm;
      try {
        return await (await fetch(href)).text();
      } catch (_err) {
        logWarnOnce(`Ignoring cross-origin stylesheet in migrate mode: ${href}`);
        return "";
      }
    }
  }
  function initGlobalStylesheet() {
    const stylesheet6 = new CSSStyleSheet();
    const elmsToPromises = /* @__PURE__ */ new Map();
    let lastSeenLength = 0;
    const copyToGlobalStylesheet = () => {
      const elms = document.head.querySelectorAll('style:not([data-rendered-by-lwc]),link[rel="stylesheet"]');
      if (elms.length === lastSeenLength) {
        return;
      }
      lastSeenLength = elms.length;
      const promises = [...elms].map((elm) => {
        let promise = elmsToPromises.get(elm);
        if (!promise) {
          promise = fetchStylesheet(elm);
          elmsToPromises.set(elm, promise);
        }
        return promise;
      });
      Promise.all(promises).then((stylesheetTexts) => {
        stylesheet6.replaceSync(stylesheetTexts.join("\n"));
      });
    };
    const headObserver = new MutationObserver(copyToGlobalStylesheet);
    headObserver.observe(document.head, {
      childList: true
    });
    copyToGlobalStylesheet();
    return stylesheet6;
  }
  function applyShadowMigrateMode(shadowRoot) {
    if (!globalStylesheet) {
      globalStylesheet = initGlobalStylesheet();
    }
    shadowRoot.synthetic = true;
    shadowRoot.adoptedStyleSheets.push(globalStylesheet);
  }
  function createBridgeToElementDescriptor(propName, descriptor) {
    const { get, set, enumerable, configurable } = descriptor;
    if (!isFunction$1(get)) {
      throw new TypeError(`Detected invalid public property descriptor for HTMLElement.prototype.${propName} definition. Missing the standard getter.`);
    }
    if (!isFunction$1(set)) {
      throw new TypeError(`Detected invalid public property descriptor for HTMLElement.prototype.${propName} definition. Missing the standard setter.`);
    }
    return {
      enumerable,
      configurable,
      get() {
        const vm = getAssociatedVM(this);
        if (isBeingConstructed(vm)) {
          if (false) {
            logError(`The value of property \`${propName}\` can't be read from the constructor because the owner component hasn't set the value yet. Instead, use the constructor to set a default value for the property.`, vm);
          }
          return;
        }
        componentValueObserved(vm, propName);
        return get.call(vm.elm);
      },
      set(newValue) {
        const vm = getAssociatedVM(this);
        if (false) {
          const vmBeingRendered2 = getVMBeingRendered();
          if (isInvokingRender) {
            logError(`${vmBeingRendered2}.render() method has side effects on the state of ${vm}.${propName}`);
          }
          if (isUpdatingTemplate) {
            logError(`When updating the template of ${vmBeingRendered2}, one of the accessors used by the template has side effects on the state of ${vm}.${propName}`);
          }
          if (isBeingConstructed(vm)) {
            logError(`Failed to construct '${getComponentTag(vm)}': The result must not have attributes.`);
          }
          if (isObject(newValue) && !isNull(newValue)) {
            logError(`Invalid value "${newValue}" for "${propName}" of ${vm}. Value cannot be an object, must be a primitive value.`);
          }
        }
        updateComponentValue(vm, propName, newValue);
        return set.call(vm.elm, newValue);
      }
    };
  }
  var refsCache = /* @__PURE__ */ new WeakMap();
  var LightningElement = function() {
    if (isNull(vmBeingConstructed)) {
      throw new TypeError("Illegal constructor");
    }
    instrumentInstance(this, vmBeingConstructed);
    const vm = vmBeingConstructed;
    const { def, elm } = vm;
    const { bridge } = def;
    if (false) {
      const { assertInstanceOfHTMLElement } = vm.renderer;
      assertInstanceOfHTMLElement(vm.elm, `Component creation requires a DOM element to be associated to ${vm}.`);
    }
    setPrototypeOf(elm, bridge.prototype);
    vm.component = this;
    if (arguments.length === 1) {
      const { callHook: callHook2, setHook: setHook2, getHook: getHook2 } = arguments[0];
      vm.callHook = callHook2;
      vm.setHook = setHook2;
      vm.getHook = getHook2;
    }
    markLockerLiveObject(this);
    associateVM(this, vm);
    associateVM(elm, vm);
    if (vm.renderMode === 1) {
      vm.renderRoot = doAttachShadow(vm);
    } else {
      vm.renderRoot = elm;
    }
    if (false) {
      patchCustomElementWithRestrictions(elm);
    }
    return this;
  };
  function doAttachShadow(vm) {
    const { elm, mode, shadowMode, def: { ctor }, renderer: { attachShadow } } = vm;
    const shadowRoot = attachShadow(elm, {
      [KEY__SYNTHETIC_MODE]: shadowMode === 1,
      delegatesFocus: Boolean(ctor.delegatesFocus),
      mode
    });
    vm.shadowRoot = shadowRoot;
    associateVM(shadowRoot, vm);
    if (false) {
      patchShadowRootWithRestrictions(shadowRoot);
    }
    if (lwcRuntimeFlags.ENABLE_FORCE_SHADOW_MIGRATE_MODE && vm.shadowMigrateMode) {
      applyShadowMigrateMode(shadowRoot);
    }
    return shadowRoot;
  }
  LightningElement.prototype = {
    constructor: LightningElement,
    dispatchEvent(event) {
      const vm = getAssociatedVM(this);
      const { elm, renderer: { dispatchEvent } } = vm;
      return dispatchEvent(elm, event);
    },
    addEventListener(type, listener, options) {
      const vm = getAssociatedVM(this);
      const { elm, renderer: { addEventListener } } = vm;
      if (false) {
        const vmBeingRendered2 = getVMBeingRendered();
        if (isInvokingRender) {
          logError(`${vmBeingRendered2}.render() method has side effects on the state of ${vm} by adding an event listener for "${type}".`);
        }
        if (isUpdatingTemplate) {
          logError(`Updating the template of ${vmBeingRendered2} has side effects on the state of ${vm} by adding an event listener for "${type}".`);
        }
        if (!isFunction$1(listener)) {
          logError(`Invalid second argument for this.addEventListener() in ${vm} for event "${type}". Expected an EventListener but received ${listener}.`);
        }
      }
      const wrappedListener = getWrappedComponentsListener(vm, listener);
      addEventListener(elm, type, wrappedListener, options);
    },
    removeEventListener(type, listener, options) {
      const vm = getAssociatedVM(this);
      const { elm, renderer: { removeEventListener } } = vm;
      const wrappedListener = getWrappedComponentsListener(vm, listener);
      removeEventListener(elm, type, wrappedListener, options);
    },
    hasAttribute(name) {
      const vm = getAssociatedVM(this);
      const { elm, renderer: { getAttribute } } = vm;
      return !isNull(getAttribute(elm, name));
    },
    hasAttributeNS(namespace, name) {
      const vm = getAssociatedVM(this);
      const { elm, renderer: { getAttribute } } = vm;
      return !isNull(getAttribute(elm, name, namespace));
    },
    removeAttribute(name) {
      const vm = getAssociatedVM(this);
      const { elm, renderer: { removeAttribute } } = vm;
      removeAttribute(elm, name);
    },
    removeAttributeNS(namespace, name) {
      const { elm, renderer: { removeAttribute } } = getAssociatedVM(this);
      removeAttribute(elm, name, namespace);
    },
    getAttribute(name) {
      const vm = getAssociatedVM(this);
      const { elm } = vm;
      const { getAttribute } = vm.renderer;
      return getAttribute(elm, name);
    },
    getAttributeNS(namespace, name) {
      const vm = getAssociatedVM(this);
      const { elm } = vm;
      const { getAttribute } = vm.renderer;
      return getAttribute(elm, name, namespace);
    },
    setAttribute(name, value) {
      const vm = getAssociatedVM(this);
      const { elm, renderer: { setAttribute } } = vm;
      if (false) {
        if (isBeingConstructed(vm)) {
          logError(`Failed to construct '${getComponentTag(vm)}': The result must not have attributes.`);
        }
      }
      setAttribute(elm, name, value);
    },
    setAttributeNS(namespace, name, value) {
      const vm = getAssociatedVM(this);
      const { elm, renderer: { setAttribute } } = vm;
      if (false) {
        if (isBeingConstructed(vm)) {
          logError(`Failed to construct '${getComponentTag(vm)}': The result must not have attributes.`);
        }
      }
      setAttribute(elm, name, value, namespace);
    },
    getBoundingClientRect() {
      const vm = getAssociatedVM(this);
      const { elm, renderer: { getBoundingClientRect } } = vm;
      if (false) {
        warnIfInvokedDuringConstruction(vm, "getBoundingClientRect()");
      }
      return getBoundingClientRect(elm);
    },
    attachInternals() {
      const vm = getAssociatedVM(this);
      const { def: { ctor }, elm, apiVersion, renderer: { attachInternals } } = vm;
      if (!isAPIFeatureEnabled(7, apiVersion)) {
        throw new Error(`The attachInternals API is only supported in API version 61 and above. The current version is ${apiVersion}. To use this API, update the LWC component API version. https://lwc.dev/guide/versioning`);
      }
      const internals = attachInternals(elm);
      if (vm.shadowMode === 1 && supportsSyntheticElementInternals(ctor)) {
        const handler = {
          get(target, prop) {
            if (prop === "shadowRoot") {
              return vm.shadowRoot;
            }
            const value = Reflect.get(target, prop);
            if (typeof value === "function") {
              return value.bind(target);
            }
            return value;
          },
          set(target, prop, value) {
            return Reflect.set(target, prop, value);
          }
        };
        return new Proxy(internals, handler);
      } else if (vm.shadowMode === 1) {
        throw new Error("attachInternals API is not supported in synthetic shadow.");
      }
      return internals;
    },
    get isConnected() {
      const vm = getAssociatedVM(this);
      const { elm, renderer: { isConnected } } = vm;
      return isConnected(elm);
    },
    get classList() {
      const vm = getAssociatedVM(this);
      const { elm, renderer: { getClassList } } = vm;
      if (false) {
        if (isBeingConstructed(vm)) {
          logError(`Failed to construct ${vm}: The result must not have attributes. Adding or tampering with classname in constructor is not allowed in a web component, use connectedCallback() instead.`);
        }
      }
      return getClassList(elm);
    },
    get template() {
      const vm = getAssociatedVM(this);
      if (false) {
        if (vm.renderMode === 0) {
          logError("`this.template` returns null for light DOM components. Since there is no shadow, the rendered content can be accessed via `this` itself. e.g. instead of `this.template.querySelector`, use `this.querySelector`.");
        }
      }
      return vm.shadowRoot;
    },
    get hostElement() {
      const vm = getAssociatedVM(this);
      const apiVersion = getComponentAPIVersion(vm.def.ctor);
      if (!isAPIFeatureEnabled(8, apiVersion)) {
        if (false) {
          logWarnOnce("The `this.hostElement` API within LightningElement is only supported in API version 62 and above. Increase the API version to use it.");
        }
        return void 0;
      }
      if (false) {
        assert.isTrue(vm.elm instanceof Element, `this.hostElement should be an Element, found: ${vm.elm}`);
      }
      return vm.elm;
    },
    get refs() {
      const vm = getAssociatedVM(this);
      if (isUpdatingTemplate) {
        if (false) {
          logError(`this.refs should not be called while ${getComponentTag(vm)} is rendering. Use this.refs only when the DOM is stable, e.g. in renderedCallback().`);
        }
        return;
      }
      if (false) {
        warnIfInvokedDuringConstruction(vm, "refs");
      }
      const { refVNodes, cmpTemplate } = vm;
      if (false) {
        logError(`this.refs is undefined for ${getComponentTag(vm)}. This is either because the attached template has no "lwc:ref" directive, or this.refs was invoked before renderedCallback(). Use this.refs only when the referenced HTML elements have been rendered to the DOM, such as within renderedCallback() or disconnectedCallback().`);
      }
      if (isNull(refVNodes)) {
        return;
      }
      let refs = refsCache.get(refVNodes);
      if (isUndefined$1(refs)) {
        refs = create(null);
        for (const key of keys(refVNodes)) {
          refs[key] = refVNodes[key].elm;
        }
        freeze(refs);
        refsCache.set(refVNodes, refs);
      }
      return refs;
    },
    // For backwards compat, we allow component authors to set `refs` as an expando
    set refs(value) {
      defineProperty(this, "refs", {
        configurable: true,
        enumerable: true,
        writable: true,
        value
      });
    },
    get shadowRoot() {
      return null;
    },
    get children() {
      const vm = getAssociatedVM(this);
      const renderer2 = vm.renderer;
      if (false) {
        warnIfInvokedDuringConstruction(vm, "children");
      }
      return renderer2.getChildren(vm.elm);
    },
    get childNodes() {
      const vm = getAssociatedVM(this);
      const renderer2 = vm.renderer;
      if (false) {
        warnIfInvokedDuringConstruction(vm, "childNodes");
      }
      return renderer2.getChildNodes(vm.elm);
    },
    get firstChild() {
      const vm = getAssociatedVM(this);
      const renderer2 = vm.renderer;
      if (false) {
        warnIfInvokedDuringConstruction(vm, "firstChild");
      }
      return renderer2.getFirstChild(vm.elm);
    },
    get firstElementChild() {
      const vm = getAssociatedVM(this);
      const renderer2 = vm.renderer;
      if (false) {
        warnIfInvokedDuringConstruction(vm, "firstElementChild");
      }
      return renderer2.getFirstElementChild(vm.elm);
    },
    get lastChild() {
      const vm = getAssociatedVM(this);
      const renderer2 = vm.renderer;
      if (false) {
        warnIfInvokedDuringConstruction(vm, "lastChild");
      }
      return renderer2.getLastChild(vm.elm);
    },
    get lastElementChild() {
      const vm = getAssociatedVM(this);
      const renderer2 = vm.renderer;
      if (false) {
        warnIfInvokedDuringConstruction(vm, "lastElementChild");
      }
      return renderer2.getLastElementChild(vm.elm);
    },
    get ownerDocument() {
      const vm = getAssociatedVM(this);
      const renderer2 = vm.renderer;
      if (false) {
        warnIfInvokedDuringConstruction(vm, "ownerDocument");
      }
      return renderer2.ownerDocument(vm.elm);
    },
    get tagName() {
      const { elm, renderer: renderer2 } = getAssociatedVM(this);
      return renderer2.getTagName(elm);
    },
    get style() {
      const { elm, renderer: renderer2, def } = getAssociatedVM(this);
      const apiVersion = getComponentAPIVersion(def.ctor);
      if (!isAPIFeatureEnabled(9, apiVersion)) {
        if (false) {
          logWarnOnce("The `this.style` API within LightningElement returning the CSSStyleDeclaration is only supported in API version 62 and above. Increase the API version to use it.");
        }
        return void 0;
      }
      return renderer2.getStyle(elm);
    },
    render() {
      const vm = getAssociatedVM(this);
      return vm.def.template;
    },
    toString() {
      const vm = getAssociatedVM(this);
      return `[object ${vm.def.name}]`;
    }
  };
  var queryAndChildGetterDescriptors = create(null);
  var queryMethods = [
    "getElementsByClassName",
    "getElementsByTagName",
    "querySelector",
    "querySelectorAll"
  ];
  for (const queryMethod of queryMethods) {
    queryAndChildGetterDescriptors[queryMethod] = {
      value(arg) {
        const vm = getAssociatedVM(this);
        const { elm, renderer: renderer2 } = vm;
        if (false) {
          warnIfInvokedDuringConstruction(vm, `${queryMethod}()`);
        }
        return renderer2[queryMethod](elm, arg);
      },
      configurable: true,
      enumerable: true,
      writable: true
    };
  }
  defineProperties(LightningElement.prototype, queryAndChildGetterDescriptors);
  var lightningBasedDescriptors = create(null);
  for (const propName in HTMLElementOriginalDescriptors) {
    lightningBasedDescriptors[propName] = createBridgeToElementDescriptor(propName, HTMLElementOriginalDescriptors[propName]);
  }
  {
    for (const [propName, descriptor] of entries(ariaReflectionPolyfillDescriptors)) {
      lightningBasedDescriptors[propName] = createBridgeToElementDescriptor(propName, descriptor);
    }
  }
  defineProperties(LightningElement.prototype, lightningBasedDescriptors);
  defineProperty(LightningElement, "CustomElementConstructor", {
    get() {
      throw new ReferenceError("The current runtime does not support CustomElementConstructor.");
    },
    configurable: true
  });
  function createObservedFieldPropertyDescriptor(key) {
    return {
      get() {
        const vm = getAssociatedVM(this);
        const val = vm.cmpFields[key];
        componentValueObserved(vm, key, val);
        return val;
      },
      set(newValue) {
        const vm = getAssociatedVM(this);
        updateComponentValue(vm, key, newValue);
      },
      enumerable: true,
      configurable: true
    };
  }
  var AdapterToTokenMap = /* @__PURE__ */ new Map();
  function createContextWatcher(vm, wireDef, callbackWhenContextIsReady) {
    const { adapter } = wireDef;
    const adapterContextToken = AdapterToTokenMap.get(adapter);
    if (isUndefined$1(adapterContextToken)) {
      return;
    }
    const { elm, context: { wiredConnecting, wiredDisconnecting }, renderer: { registerContextConsumer } } = vm;
    ArrayPush$1.call(wiredConnecting, () => {
      registerContextConsumer(elm, adapterContextToken, {
        setNewContext(newContext) {
          callbackWhenContextIsReady(newContext);
          return true;
        },
        setDisconnectedCallback(disconnectCallback) {
          ArrayPush$1.call(wiredDisconnecting, disconnectCallback);
        }
      });
    });
  }
  var DeprecatedWiredElementHost = "$$DeprecatedWiredElementHostKey$$";
  var DeprecatedWiredParamsMeta = "$$DeprecatedWiredParamsMetaKey$$";
  var WireMetaMap = /* @__PURE__ */ new Map();
  function createFieldDataCallback(vm, name) {
    return (value) => {
      updateComponentValue(vm, name, value);
    };
  }
  function createMethodDataCallback(vm, method) {
    return (value) => {
      runWithBoundaryProtection(vm, vm.owner, noop, () => {
        method.call(vm.component, value);
      }, noop);
    };
  }
  function createConfigWatcher(component, configCallback, callbackWhenConfigIsReady) {
    let hasPendingConfig = false;
    const ro = createReactiveObserver(() => {
      if (hasPendingConfig === false) {
        hasPendingConfig = true;
        Promise.resolve().then(() => {
          hasPendingConfig = false;
          ro.reset();
          computeConfigAndUpdate();
        });
      }
    });
    if (false) {
      associateReactiveObserverWithVM(ro, getAssociatedVM(component));
    }
    const computeConfigAndUpdate = () => {
      let config;
      ro.observe(() => config = configCallback(component));
      callbackWhenConfigIsReady(config);
    };
    return {
      computeConfigAndUpdate,
      ro
    };
  }
  function createConnector(vm, name, wireDef) {
    const { method, adapter, configCallback, dynamic } = wireDef;
    let debugInfo;
    if (false) {
      const wiredPropOrMethod = isUndefined$1(method) ? name : method.name;
      debugInfo = create(null);
      debugInfo.wasDataProvisionedForConfig = false;
      vm.debugInfo[WIRE_DEBUG_ENTRY][wiredPropOrMethod] = debugInfo;
    }
    const fieldOrMethodCallback = isUndefined$1(method) ? createFieldDataCallback(vm, name) : createMethodDataCallback(vm, method);
    const dataCallback = (value) => {
      if (false) {
        debugInfo.data = value;
        debugInfo.wasDataProvisionedForConfig = true;
      }
      fieldOrMethodCallback(value);
    };
    let context;
    let connector;
    defineProperty(dataCallback, DeprecatedWiredElementHost, {
      value: vm.elm
    });
    defineProperty(dataCallback, DeprecatedWiredParamsMeta, {
      value: dynamic
    });
    runWithBoundaryProtection(vm, vm, noop, () => {
      connector = new adapter(dataCallback, { tagName: vm.tagName });
    }, noop);
    const updateConnectorConfig = (config) => {
      runWithBoundaryProtection(vm, vm, noop, () => {
        if (false) {
          debugInfo.config = config;
          debugInfo.context = context;
          debugInfo.wasDataProvisionedForConfig = false;
        }
        connector.update(config, context);
      }, noop);
    };
    const { computeConfigAndUpdate, ro } = createConfigWatcher(vm.component, configCallback, updateConnectorConfig);
    if (!isUndefined$1(adapter.contextSchema)) {
      createContextWatcher(vm, wireDef, (newContext) => {
        if (context !== newContext) {
          context = newContext;
          if (vm.state === 1) {
            computeConfigAndUpdate();
          }
        }
      });
    }
    return {
      // @ts-expect-error the boundary protection executes sync, connector is always defined
      connector,
      computeConfigAndUpdate,
      resetConfigWatcher: () => ro.reset()
    };
  }
  function storeWiredMethodMeta(descriptor, adapter, configCallback, dynamic) {
    if (adapter.adapter) {
      adapter = adapter.adapter;
    }
    const method = descriptor.value;
    const def = {
      adapter,
      method,
      configCallback,
      dynamic
    };
    WireMetaMap.set(descriptor, def);
  }
  function storeWiredFieldMeta(descriptor, adapter, configCallback, dynamic) {
    if (adapter.adapter) {
      adapter = adapter.adapter;
    }
    const def = {
      adapter,
      configCallback,
      dynamic
    };
    WireMetaMap.set(descriptor, def);
  }
  function installWireAdapters(vm) {
    const { context, def: { wire } } = vm;
    if (false) {
      vm.debugInfo[WIRE_DEBUG_ENTRY] = create(null);
    }
    const wiredConnecting = context.wiredConnecting = [];
    const wiredDisconnecting = context.wiredDisconnecting = [];
    for (const fieldNameOrMethod in wire) {
      const descriptor = wire[fieldNameOrMethod];
      const wireDef = WireMetaMap.get(descriptor);
      if (false) {
        assert.invariant(wireDef, `Internal Error: invalid wire definition found.`);
      }
      if (!isUndefined$1(wireDef)) {
        const { connector, computeConfigAndUpdate, resetConfigWatcher } = createConnector(vm, fieldNameOrMethod, wireDef);
        const hasDynamicParams = wireDef.dynamic.length > 0;
        ArrayPush$1.call(wiredConnecting, () => {
          connector.connect();
          if (!lwcRuntimeFlags.ENABLE_WIRE_SYNC_EMIT) {
            if (hasDynamicParams) {
              Promise.resolve().then(computeConfigAndUpdate);
              return;
            }
          }
          computeConfigAndUpdate();
        });
        ArrayPush$1.call(wiredDisconnecting, () => {
          connector.disconnect();
          resetConfigWatcher();
        });
      }
    }
  }
  function connectWireAdapters(vm) {
    const { wiredConnecting } = vm.context;
    for (let i2 = 0, len = wiredConnecting.length; i2 < len; i2 += 1) {
      wiredConnecting[i2]();
    }
  }
  function disconnectWireAdapters(vm) {
    const { wiredDisconnecting } = vm.context;
    runWithBoundaryProtection(vm, vm, noop, () => {
      for (let i2 = 0, len = wiredDisconnecting.length; i2 < len; i2 += 1) {
        wiredDisconnecting[i2]();
      }
    }, noop);
  }
  function createPublicPropertyDescriptor(key) {
    return {
      get() {
        const vm = getAssociatedVM(this);
        if (isBeingConstructed(vm)) {
          if (false) {
            logError(`Can\u2019t read the value of property \`${toString(key)}\` from the constructor because the owner component hasn\u2019t set the value yet. Instead, use the constructor to set a default value for the property.`, vm);
          }
          return;
        }
        const val = vm.cmpProps[key];
        componentValueObserved(vm, key, val);
        return val;
      },
      set(newValue) {
        const vm = getAssociatedVM(this);
        if (false) {
          const vmBeingRendered2 = getVMBeingRendered();
          if (isInvokingRender) {
            logError(`render() method has side effects on the state of property "${toString(key)}"`, isNull(vmBeingRendered2) ? vm : vmBeingRendered2);
          }
          if (isUpdatingTemplate) {
            logError(`Updating the template has side effects on the state of property "${toString(key)}"`, isNull(vmBeingRendered2) ? vm : vmBeingRendered2);
          }
        }
        vm.cmpProps[key] = newValue;
        componentValueMutated(vm, key);
      },
      enumerable: true,
      configurable: true
    };
  }
  function createPublicAccessorDescriptor(key, descriptor) {
    const { get, set, enumerable, configurable } = descriptor;
    assert.invariant(isFunction$1(get), `Invalid public accessor ${toString(key)} decorated with @api. The property is missing a getter.`);
    return {
      get() {
        if (false) {
          getAssociatedVM(this);
        }
        return get.call(this);
      },
      set(newValue) {
        const vm = getAssociatedVM(this);
        if (false) {
          const vmBeingRendered2 = getVMBeingRendered();
          if (isInvokingRender) {
            logError(`render() method has side effects on the state of property "${toString(key)}"`, isNull(vmBeingRendered2) ? vm : vmBeingRendered2);
          }
          if (isUpdatingTemplate) {
            logError(`Updating the template has side effects on the state of property "${toString(key)}"`, isNull(vmBeingRendered2) ? vm : vmBeingRendered2);
          }
        }
        if (set) {
          set.call(this, newValue);
        } else if (false) {
          logError(`Invalid attempt to set a new value for property "${toString(key)}" that does not has a setter decorated with @api.`, vm);
        }
      },
      enumerable,
      configurable
    };
  }
  function internalTrackDecorator(key) {
    return {
      get() {
        const vm = getAssociatedVM(this);
        const val = vm.cmpFields[key];
        componentValueObserved(vm, key, val);
        return val;
      },
      set(newValue) {
        const vm = getAssociatedVM(this);
        if (false) {
          const vmBeingRendered2 = getVMBeingRendered();
          if (isInvokingRender) {
            logError(`${vmBeingRendered2}.render() method has side effects on the state of ${vm}.${toString(key)}`);
          }
          if (isUpdatingTemplate) {
            logError(`Updating the template of ${vmBeingRendered2} has side effects on the state of ${vm}.${toString(key)}`);
          }
        }
        const reactiveOrAnyValue = getReactiveProxy(newValue);
        if (false) {
          trackTargetForMutationLogging(key, newValue);
        }
        updateComponentValue(vm, key, reactiveOrAnyValue);
      },
      enumerable: true,
      configurable: true
    };
  }
  function internalWireFieldDecorator(key) {
    return {
      get() {
        const vm = getAssociatedVM(this);
        componentValueObserved(vm, key);
        return vm.cmpFields[key];
      },
      set(value) {
        const vm = getAssociatedVM(this);
        updateComponentValue(vm, key, value);
      },
      enumerable: true,
      configurable: true
    };
  }
  function registerDecorators(Ctor, meta) {
    const proto = Ctor.prototype;
    const { publicProps, publicMethods, wire, track, fields } = meta;
    const apiMethods = create(null);
    const apiFields = create(null);
    const wiredMethods = create(null);
    const wiredFields = create(null);
    const observedFields = create(null);
    const apiFieldsConfig = create(null);
    let descriptor;
    if (!isUndefined$1(publicProps)) {
      for (const fieldName in publicProps) {
        const propConfig = publicProps[fieldName];
        apiFieldsConfig[fieldName] = propConfig.config;
        descriptor = getOwnPropertyDescriptor$1(proto, fieldName);
        if (propConfig.config > 0) {
          if (isUndefined$1(descriptor)) {
            throw new Error();
          }
          if (false) {
            validateAccessorDecoratedWithApi(Ctor, fieldName, descriptor);
          }
          descriptor = createPublicAccessorDescriptor(fieldName, descriptor);
        } else {
          if (false) {
            validateFieldDecoratedWithApi(Ctor, fieldName, descriptor);
          }
          if (!isUndefined$1(descriptor) && !isUndefined$1(descriptor.get)) {
            descriptor = createPublicAccessorDescriptor(fieldName, descriptor);
          } else {
            descriptor = createPublicPropertyDescriptor(fieldName);
          }
        }
        apiFields[fieldName] = descriptor;
        defineProperty(proto, fieldName, descriptor);
      }
    }
    if (!isUndefined$1(publicMethods)) {
      forEach.call(publicMethods, (methodName) => {
        descriptor = getOwnPropertyDescriptor$1(proto, methodName);
        if (false) {
          validateMethodDecoratedWithApi(Ctor, methodName, descriptor);
        }
        if (isUndefined$1(descriptor)) {
          throw new Error();
        }
        apiMethods[methodName] = descriptor;
      });
    }
    if (!isUndefined$1(wire)) {
      for (const fieldOrMethodName in wire) {
        const { adapter, method, config: configCallback, dynamic = [] } = wire[fieldOrMethodName];
        descriptor = getOwnPropertyDescriptor$1(proto, fieldOrMethodName);
        if (method === 1) {
          if (false) {
            if (!adapter) {
              logError(`@wire on method "${fieldOrMethodName}": adapter id must be truthy.`);
            }
            validateMethodDecoratedWithWire(Ctor, fieldOrMethodName, descriptor);
          }
          if (isUndefined$1(descriptor)) {
            throw new Error(`Missing descriptor for wired method "${fieldOrMethodName}".`);
          }
          wiredMethods[fieldOrMethodName] = descriptor;
          storeWiredMethodMeta(descriptor, adapter, configCallback, dynamic);
        } else {
          if (false) {
            if (!adapter) {
              logError(`@wire on field "${fieldOrMethodName}": adapter id must be truthy.`);
            }
            validateFieldDecoratedWithWire(Ctor, fieldOrMethodName, descriptor);
          }
          descriptor = internalWireFieldDecorator(fieldOrMethodName);
          wiredFields[fieldOrMethodName] = descriptor;
          storeWiredFieldMeta(descriptor, adapter, configCallback, dynamic);
          defineProperty(proto, fieldOrMethodName, descriptor);
        }
      }
    }
    if (!isUndefined$1(track)) {
      for (const fieldName in track) {
        descriptor = getOwnPropertyDescriptor$1(proto, fieldName);
        if (false) {
          validateFieldDecoratedWithTrack(Ctor, fieldName, descriptor);
        }
        descriptor = internalTrackDecorator(fieldName);
        defineProperty(proto, fieldName, descriptor);
      }
    }
    if (!isUndefined$1(fields)) {
      for (let i2 = 0, n = fields.length; i2 < n; i2++) {
        const fieldName = fields[i2];
        descriptor = getOwnPropertyDescriptor$1(proto, fieldName);
        if (false) {
          validateObservedField(Ctor, fieldName, descriptor);
        }
        const isDuplicatePublicProp = !isUndefined$1(publicProps) && fieldName in publicProps;
        const isDuplicateTrackedProp = !isUndefined$1(track) && fieldName in track;
        if (!isDuplicatePublicProp && !isDuplicateTrackedProp) {
          observedFields[fieldName] = createObservedFieldPropertyDescriptor(fieldName);
        }
      }
    }
    setDecoratorsMeta(Ctor, {
      apiMethods,
      apiFields,
      apiFieldsConfig,
      wiredMethods,
      wiredFields,
      observedFields
    });
    return Ctor;
  }
  var signedDecoratorToMetaMap = /* @__PURE__ */ new Map();
  function setDecoratorsMeta(Ctor, meta) {
    signedDecoratorToMetaMap.set(Ctor, meta);
  }
  var defaultMeta = {
    apiMethods: EmptyObject,
    apiFields: EmptyObject,
    apiFieldsConfig: EmptyObject,
    wiredMethods: EmptyObject,
    wiredFields: EmptyObject,
    observedFields: EmptyObject
  };
  function getDecoratorsMeta(Ctor) {
    const meta = signedDecoratorToMetaMap.get(Ctor);
    return isUndefined$1(meta) ? defaultMeta : meta;
  }
  if (false) {
    window.__lwcResetWarnedOnVersionMismatch = () => {
      warned = false;
    };
  }
  var signedTemplateSet = /* @__PURE__ */ new Set();
  function defaultEmptyTemplate() {
    return [];
  }
  signedTemplateSet.add(defaultEmptyTemplate);
  function isTemplateRegistered(tpl) {
    return signedTemplateSet.has(tpl);
  }
  function registerTemplate(tpl) {
    if (false) {
      checkVersionMismatch(tpl, "template");
    }
    signedTemplateSet.add(tpl);
    return tpl;
  }
  var cachedGetterByKey = create(null);
  var cachedSetterByKey = create(null);
  function createGetter(key) {
    let fn = cachedGetterByKey[key];
    if (isUndefined$1(fn)) {
      fn = cachedGetterByKey[key] = function() {
        const vm = getAssociatedVM(this);
        const { getHook: getHook2 } = vm;
        return getHook2(vm.component, key);
      };
    }
    return fn;
  }
  function createSetter(key) {
    let fn = cachedSetterByKey[key];
    if (isUndefined$1(fn)) {
      fn = cachedSetterByKey[key] = function(newValue) {
        const vm = getAssociatedVM(this);
        const { setHook: setHook2 } = vm;
        newValue = getReadOnlyProxy(newValue);
        setHook2(vm.component, key, newValue);
      };
    }
    return fn;
  }
  function createMethodCaller(methodName) {
    return function() {
      const vm = getAssociatedVM(this);
      const { callHook: callHook2, component } = vm;
      const fn = component[methodName];
      return callHook2(vm.component, fn, ArraySlice.call(arguments));
    };
  }
  function createAttributeChangedCallback(attributeToPropMap, superAttributeChangedCallback) {
    return function attributeChangedCallback(attrName, oldValue, newValue) {
      if (oldValue === newValue) {
        return;
      }
      const propName = attributeToPropMap[attrName];
      if (isUndefined$1(propName)) {
        if (!isUndefined$1(superAttributeChangedCallback)) {
          superAttributeChangedCallback.apply(this, arguments);
        }
        return;
      }
      this[propName] = newValue;
    };
  }
  function HTMLBridgeElementFactory(SuperClass, publicProperties, methods, observedFields, proto, hasCustomSuperClass) {
    const HTMLBridgeElement = class extends SuperClass {
    };
    const attributeToPropMap = create(null);
    const { attributeChangedCallback: superAttributeChangedCallback } = SuperClass.prototype;
    const { observedAttributes: superObservedAttributes = [] } = SuperClass;
    const descriptors = create(null);
    if (false) {
      if (!isUndefined$1(proto) && !isNull(proto) && !hasCustomSuperClass) {
        const nonPublicPropertiesToWarnOn = new Set([
          // getters, setters, and methods
          ...keys(getOwnPropertyDescriptors(proto)),
          // class properties
          ...observedFields
        ].filter((propName) => !(propName in HTMLElementPrototype) && !(propName in ariaReflectionPolyfillDescriptors)));
        for (const propName of nonPublicPropertiesToWarnOn) {
          if (ArrayIndexOf.call(publicProperties, propName) === -1) {
            descriptors[propName] = createAccessorThatWarns(propName);
          }
        }
      }
    }
    for (let i2 = 0, len = publicProperties.length; i2 < len; i2 += 1) {
      const propName = publicProperties[i2];
      attributeToPropMap[htmlPropertyToAttribute(propName)] = propName;
      descriptors[propName] = {
        get: createGetter(propName),
        set: createSetter(propName),
        enumerable: true,
        configurable: true
      };
    }
    for (let i2 = 0, len = methods.length; i2 < len; i2 += 1) {
      const methodName = methods[i2];
      descriptors[methodName] = {
        value: createMethodCaller(methodName),
        writable: true,
        configurable: true
      };
    }
    descriptors.attributeChangedCallback = {
      value: createAttributeChangedCallback(attributeToPropMap, superAttributeChangedCallback)
    };
    descriptors.attachInternals = {
      set() {
        if (false) {
          logWarn("attachInternals cannot be accessed outside of a component. Use this.attachInternals instead.");
        }
      },
      get() {
        if (false) {
          logWarn("attachInternals cannot be accessed outside of a component. Use this.attachInternals instead.");
        }
      }
    };
    descriptors.formAssociated = {
      set() {
        if (false) {
          logWarn("formAssociated cannot be accessed outside of a component. Set the value within the component class.");
        }
      },
      get() {
        if (false) {
          logWarn("formAssociated cannot be accessed outside of a component. Set the value within the component class.");
        }
      }
    };
    defineProperty(HTMLBridgeElement, "observedAttributes", {
      get() {
        return [...superObservedAttributes, ...keys(attributeToPropMap)];
      }
    });
    defineProperties(HTMLBridgeElement.prototype, descriptors);
    return HTMLBridgeElement;
  }
  var basePublicProperties = [
    ...getOwnPropertyNames$1(HTMLElementOriginalDescriptors),
    ...getOwnPropertyNames$1(ariaReflectionPolyfillDescriptors)
  ];
  var BaseBridgeElement = HTMLBridgeElementFactory(HTMLElementConstructor, basePublicProperties, [], [], null, false);
  freeze(BaseBridgeElement);
  seal(BaseBridgeElement.prototype);
  var VALID_SCOPE_TOKEN_REGEX = /^[a-zA-Z0-9\-_]+$/;
  if (false) {
    window.__lwcResetStylesheetCache = () => {
      stylesheetsToCssContent = /* @__PURE__ */ new WeakMap();
      cssContentToAbortControllers = /* @__PURE__ */ new Map();
    };
  }
  function getOrCreateAbortSignal(cssContent) {
    if (false) {
      return getOrCreateAbortControllerInDevMode(cssContent).signal;
    }
    return void 0;
  }
  function makeHostToken(token) {
    return `${token}-host`;
  }
  function createInlineStyleVNode(content) {
    return api.h("style", {
      key: "style",
      // special key
      attrs: {
        type: "text/css"
      }
    }, [api.t(content)]);
  }
  function updateStylesheetToken(vm, template, legacy) {
    const { elm, context, renderMode, shadowMode, renderer: { getClassList, removeAttribute, setAttribute } } = vm;
    const { stylesheets: newStylesheets } = template;
    const newStylesheetToken = legacy ? template.legacyStylesheetToken : template.stylesheetToken;
    const { stylesheets: newVmStylesheets } = vm;
    const isSyntheticShadow = renderMode === 1 && shadowMode === 1;
    const { hasScopedStyles } = context;
    let newToken;
    let newHasTokenInClass;
    let newHasTokenInAttribute;
    let oldToken;
    let oldHasTokenInClass;
    let oldHasTokenInAttribute;
    if (legacy) {
      oldToken = context.legacyStylesheetToken;
      oldHasTokenInClass = context.hasLegacyTokenInClass;
      oldHasTokenInAttribute = context.hasLegacyTokenInAttribute;
    } else {
      oldToken = context.stylesheetToken;
      oldHasTokenInClass = context.hasTokenInClass;
      oldHasTokenInAttribute = context.hasTokenInAttribute;
    }
    if (!isUndefined$1(oldToken)) {
      if (oldHasTokenInClass) {
        getClassList(elm).remove(makeHostToken(oldToken));
      }
      if (oldHasTokenInAttribute) {
        removeAttribute(elm, makeHostToken(oldToken));
      }
    }
    const hasNewStylesheets = hasStyles(newStylesheets);
    const hasNewVmStylesheets = hasStyles(newVmStylesheets);
    if (hasNewStylesheets || hasNewVmStylesheets) {
      newToken = newStylesheetToken;
    }
    if (!isUndefined$1(newToken)) {
      if (hasScopedStyles) {
        const hostScopeTokenClass = makeHostToken(newToken);
        getClassList(elm).add(hostScopeTokenClass);
        newHasTokenInClass = true;
      }
      if (isSyntheticShadow) {
        setAttribute(elm, makeHostToken(newToken), "");
        newHasTokenInAttribute = true;
      }
    }
    if (legacy) {
      context.legacyStylesheetToken = newToken;
      context.hasLegacyTokenInClass = newHasTokenInClass;
      context.hasLegacyTokenInAttribute = newHasTokenInAttribute;
    } else {
      context.stylesheetToken = newToken;
      context.hasTokenInClass = newHasTokenInClass;
      context.hasTokenInAttribute = newHasTokenInAttribute;
    }
  }
  function evaluateStylesheetsContent(stylesheets, stylesheetToken, vm) {
    const content = [];
    let root;
    for (let i2 = 0; i2 < stylesheets.length; i2++) {
      let stylesheet6 = stylesheets[i2];
      if (isArray$1(stylesheet6)) {
        ArrayPush$1.apply(content, evaluateStylesheetsContent(stylesheet6, stylesheetToken, vm));
      } else {
        if (false) {
          checkVersionMismatch(stylesheet6, "stylesheet");
          stylesheet6 = getStyleOrSwappedStyle(stylesheet6);
        }
        const isScopedCss = isTrue(stylesheet6[KEY__SCOPED_CSS]);
        const isNativeOnlyCss = isTrue(stylesheet6[KEY__NATIVE_ONLY_CSS]);
        const { renderMode, shadowMode } = vm;
        if (lwcRuntimeFlags.DISABLE_LIGHT_DOM_UNSCOPED_CSS && !isScopedCss && renderMode === 0) {
          logError("Unscoped CSS is not supported in Light DOM in this environment. Please use scoped CSS (*.scoped.css) instead of unscoped CSS (*.css). See also: https://sfdc.co/scoped-styles-light-dom");
          continue;
        }
        const scopeToken = isScopedCss || shadowMode === 1 && renderMode === 1 ? stylesheetToken : void 0;
        const useActualHostSelector = renderMode === 0 ? !isScopedCss : shadowMode === 0;
        let useNativeDirPseudoclass;
        if (renderMode === 1) {
          useNativeDirPseudoclass = shadowMode === 0;
        } else {
          if (isUndefined$1(root)) {
            root = getNearestShadowComponent(vm);
          }
          useNativeDirPseudoclass = isNull(root) || root.shadowMode === 0;
        }
        let cssContent;
        if (isNativeOnlyCss && renderMode === 1 && shadowMode === 1) {
          cssContent = "/* ignored native-only CSS */";
        } else {
          cssContent = stylesheet6(scopeToken, useActualHostSelector, useNativeDirPseudoclass);
        }
        if (false) {
          linkStylesheetToCssContentInDevMode(stylesheet6, cssContent);
        }
        ArrayPush$1.call(content, cssContent);
      }
    }
    return content;
  }
  function getStylesheetsContent(vm, template) {
    const { stylesheets, stylesheetToken } = template;
    const { stylesheets: vmStylesheets } = vm;
    if (!isUndefined$1(stylesheetToken) && !isValidScopeToken(stylesheetToken)) {
      throw new Error("stylesheet token must be a valid string");
    }
    const hasTemplateStyles = hasStyles(stylesheets);
    const hasVmStyles = hasStyles(vmStylesheets);
    if (hasTemplateStyles) {
      const content = evaluateStylesheetsContent(stylesheets, stylesheetToken, vm);
      if (hasVmStyles) {
        ArrayPush$1.apply(content, evaluateStylesheetsContent(vmStylesheets, stylesheetToken, vm));
      }
      return content;
    }
    if (hasVmStyles) {
      return evaluateStylesheetsContent(vmStylesheets, stylesheetToken, vm);
    }
    return EmptyArray;
  }
  function getNearestShadowComponent(vm) {
    let owner = vm;
    while (!isNull(owner)) {
      if (owner.renderMode === 1) {
        return owner;
      }
      owner = owner.owner;
    }
    return owner;
  }
  function getScopeTokenClass(owner, legacy) {
    const { cmpTemplate, context } = owner;
    return context.hasScopedStyles && (legacy ? cmpTemplate?.legacyStylesheetToken : cmpTemplate?.stylesheetToken) || null;
  }
  function getNearestNativeShadowComponent(vm) {
    const owner = getNearestShadowComponent(vm);
    if (!isNull(owner) && owner.shadowMode === 1) {
      return null;
    }
    return owner;
  }
  function createStylesheet(vm, stylesheets) {
    const { renderMode, shadowMode, renderer: { insertStylesheet: insertStylesheet2 } } = vm;
    if (renderMode === 1 && shadowMode === 1) {
      for (let i2 = 0; i2 < stylesheets.length; i2++) {
        const stylesheet6 = stylesheets[i2];
        insertStylesheet2(stylesheet6, void 0, getOrCreateAbortSignal(stylesheet6));
      }
    } else if (vm.hydrated) {
      return ArrayMap.call(stylesheets, createInlineStyleVNode);
    } else {
      const root = getNearestNativeShadowComponent(vm);
      const target = isNull(root) ? void 0 : root.shadowRoot;
      for (let i2 = 0; i2 < stylesheets.length; i2++) {
        const stylesheet6 = stylesheets[i2];
        insertStylesheet2(stylesheet6, target, getOrCreateAbortSignal(stylesheet6));
      }
    }
    return null;
  }
  function isValidScopeToken(token) {
    if (!isString(token)) {
      return false;
    }
    return lwcRuntimeFlags.DISABLE_SCOPE_TOKEN_VALIDATION || VALID_SCOPE_TOKEN_REGEX.test(token);
  }
  if (false) {
    window.__lwcResetHotSwaps = () => {
      swappedTemplateMap = /* @__PURE__ */ new WeakMap();
      swappedComponentMap = /* @__PURE__ */ new WeakMap();
      swappedStyleMap = /* @__PURE__ */ new WeakMap();
      activeTemplates = new WeakMultiMap();
      activeComponents = new WeakMultiMap();
      activeStyles = new WeakMultiMap();
    };
  }
  var CtorToDefMap = /* @__PURE__ */ new WeakMap();
  function getCtorProto(Ctor) {
    let proto = getPrototypeOf$1(Ctor);
    if (isNull(proto)) {
      throw new ReferenceError(`Invalid prototype chain for ${Ctor.name}, you must extend LightningElement.`);
    }
    if (isCircularModuleDependency(proto)) {
      const p = resolveCircularModuleDependency(proto);
      if (false) {
        if (isNull(p)) {
          throw new ReferenceError(`Circular module dependency for ${Ctor.name}, must resolve to a constructor that extends LightningElement.`);
        }
      }
      proto = p === proto ? LightningElement : p;
    }
    return proto;
  }
  function createComponentDef(Ctor) {
    if (!isComponentFeatureEnabled(Ctor)) {
      const metadata = getComponentMetadata(Ctor);
      const componentName = Ctor.name || metadata?.sel || "Unknown";
      const componentFeatureFlagPath = metadata?.componentFeatureFlag?.path || "Unknown";
      throw new Error(`Component ${componentName} is disabled by the feature flag at ${componentFeatureFlagPath}.`);
    }
    const { shadowSupportMode: ctorShadowSupportMode, renderMode: ctorRenderMode, formAssociated: ctorFormAssociated } = Ctor;
    if (false) {
      const ctorName = Ctor.name;
      if (!Ctor.constructor) {
        logError(`Missing ${ctorName}.constructor, ${ctorName} should have a "constructor" property.`);
      }
      if (!isUndefined$1(ctorShadowSupportMode) && ctorShadowSupportMode !== "any" && ctorShadowSupportMode !== "reset" && ctorShadowSupportMode !== "native") {
        logError(`Invalid value for static property shadowSupportMode: '${ctorShadowSupportMode}'`);
      }
      if (ctorShadowSupportMode === "any") {
        logWarn(`Invalid value 'any' for static property shadowSupportMode. 'any' is deprecated and will be removed in a future release--use 'native' instead.`);
      }
      if (!isUndefined$1(ctorRenderMode) && ctorRenderMode !== "light" && ctorRenderMode !== "shadow") {
        logError(`Invalid value for static property renderMode: '${ctorRenderMode}'. renderMode must be either 'light' or 'shadow'.`);
      }
    }
    const decoratorsMeta = getDecoratorsMeta(Ctor);
    const { apiFields, apiFieldsConfig, apiMethods, wiredFields, wiredMethods, observedFields } = decoratorsMeta;
    const proto = Ctor.prototype;
    let { connectedCallback, disconnectedCallback, renderedCallback, errorCallback, formAssociatedCallback, formResetCallback, formDisabledCallback, formStateRestoreCallback, render } = proto;
    const superProto = getCtorProto(Ctor);
    const hasCustomSuperClass = superProto !== LightningElement;
    const superDef = hasCustomSuperClass ? getComponentInternalDef(superProto) : lightingElementDef;
    const bridge = HTMLBridgeElementFactory(superDef.bridge, keys(apiFields), keys(apiMethods), keys(observedFields), proto, hasCustomSuperClass);
    const props = assign(create(null), superDef.props, apiFields);
    const propsConfig = assign(create(null), superDef.propsConfig, apiFieldsConfig);
    const methods = assign(create(null), superDef.methods, apiMethods);
    const wire = assign(create(null), superDef.wire, wiredFields, wiredMethods);
    connectedCallback = connectedCallback || superDef.connectedCallback;
    disconnectedCallback = disconnectedCallback || superDef.disconnectedCallback;
    renderedCallback = renderedCallback || superDef.renderedCallback;
    errorCallback = errorCallback || superDef.errorCallback;
    formAssociatedCallback = formAssociatedCallback || superDef.formAssociatedCallback;
    formResetCallback = formResetCallback || superDef.formResetCallback;
    formDisabledCallback = formDisabledCallback || superDef.formDisabledCallback;
    formStateRestoreCallback = formStateRestoreCallback || superDef.formStateRestoreCallback;
    render = render || superDef.render;
    let shadowSupportMode = superDef.shadowSupportMode;
    if (!isUndefined$1(ctorShadowSupportMode)) {
      shadowSupportMode = ctorShadowSupportMode;
      if (isReportingEnabled() && (shadowSupportMode === "any" || shadowSupportMode === "native")) {
        report("ShadowSupportModeUsage", {
          tagName: Ctor.name,
          mode: shadowSupportMode
        });
      }
    }
    let renderMode = superDef.renderMode;
    if (!isUndefined$1(ctorRenderMode)) {
      renderMode = ctorRenderMode === "light" ? 0 : 1;
    }
    let formAssociated = superDef.formAssociated;
    if (!isUndefined$1(ctorFormAssociated)) {
      formAssociated = ctorFormAssociated;
    }
    const template = getComponentRegisteredTemplate(Ctor) || superDef.template;
    const name = Ctor.name || superDef.name;
    defineProperties(proto, observedFields);
    const def = {
      ctor: Ctor,
      name,
      wire,
      props,
      propsConfig,
      methods,
      bridge,
      template,
      renderMode,
      shadowSupportMode,
      formAssociated,
      connectedCallback,
      disconnectedCallback,
      errorCallback,
      formAssociatedCallback,
      formDisabledCallback,
      formResetCallback,
      formStateRestoreCallback,
      renderedCallback,
      render
    };
    instrumentDef(def);
    if (false) {
      freeze(Ctor.prototype);
    }
    return def;
  }
  function isComponentConstructor(ctor) {
    if (!isFunction$1(ctor)) {
      return false;
    }
    if (ctor.prototype instanceof LightningElement) {
      return true;
    }
    let current = ctor;
    do {
      if (isCircularModuleDependency(current)) {
        const circularResolved = resolveCircularModuleDependency(current);
        if (circularResolved === current) {
          return true;
        }
        current = circularResolved;
      }
      if (current === LightningElement) {
        return true;
      }
    } while (!isNull(current) && (current = getPrototypeOf$1(current)));
    return false;
  }
  function getComponentInternalDef(Ctor) {
    if (false) {
      Ctor = getComponentOrSwappedComponent(Ctor);
    }
    let def = CtorToDefMap.get(Ctor);
    if (isUndefined$1(def)) {
      if (isCircularModuleDependency(Ctor)) {
        const resolvedCtor = resolveCircularModuleDependency(Ctor);
        def = getComponentInternalDef(resolvedCtor);
        CtorToDefMap.set(Ctor, def);
        return def;
      }
      if (!isComponentConstructor(Ctor)) {
        throw new TypeError(`${Ctor} is not a valid component, or does not extends LightningElement from "lwc". You probably forgot to add the extend clause on the class declaration.`);
      }
      def = createComponentDef(Ctor);
      CtorToDefMap.set(Ctor, def);
    }
    return def;
  }
  function getComponentHtmlPrototype(Ctor) {
    const def = getComponentInternalDef(Ctor);
    return def.bridge;
  }
  var lightingElementDef = {
    name: LightningElement.name,
    props: lightningBasedDescriptors,
    propsConfig: EmptyObject,
    methods: EmptyObject,
    renderMode: 1,
    shadowSupportMode: "reset",
    formAssociated: void 0,
    wire: EmptyObject,
    bridge: BaseBridgeElement,
    template: defaultEmptyTemplate,
    render: LightningElement.prototype.render
  };
  function isVBaseElement(vnode) {
    const { type } = vnode;
    return type === 2 || type === 3;
  }
  function isSameVnode(vnode1, vnode2) {
    return vnode1.key === vnode2.key && vnode1.sel === vnode2.sel;
  }
  function isVCustomElement(vnode) {
    return vnode.type === 3;
  }
  function isVFragment(vnode) {
    return vnode.type === 5;
  }
  function isVScopedSlotFragment(vnode) {
    return vnode.type === 6;
  }
  function isVStatic(vnode) {
    return vnode.type === 4;
  }
  function isVStaticPartElement(vnode) {
    return vnode.type === 1;
  }
  var sanitizedHtmlContentSymbol = Symbol("lwc-get-sanitized-html-content");
  function isSanitizedHtmlContent(object) {
    return isObject(object) && !isNull(object) && sanitizedHtmlContentSymbol in object;
  }
  function createSanitizedHtmlContent(sanitizedString) {
    return create(null, {
      [sanitizedHtmlContentSymbol]: {
        value: sanitizedString,
        configurable: false,
        writable: false
      }
    });
  }
  function safelySetProperty(setProperty, elm, key, value) {
    if ((key === "innerHTML" || key === "outerHTML") && !isUndefined$1(value)) {
      if (isSanitizedHtmlContent(value)) {
        setProperty(elm, key, value[sanitizedHtmlContentSymbol]);
      } else {
        if (false) {
          logWarn(`Cannot set property "${key}". Instead, use lwc:inner-html or lwc:dom-manual.`);
        }
      }
    } else {
      setProperty(elm, key, value);
    }
  }
  var ColonCharCode = 58;
  function patchAttributes(oldVnode, vnode, renderer2) {
    const { data, elm } = vnode;
    const { attrs } = data;
    if (isUndefined$1(attrs)) {
      return;
    }
    const oldAttrs = isNull(oldVnode) ? EmptyObject : oldVnode.data.attrs;
    if (oldAttrs === attrs) {
      return;
    }
    const external = "external" in data ? data.external : false;
    const { setAttribute, removeAttribute, setProperty } = renderer2;
    for (const key in attrs) {
      const cur = attrs[key];
      const old = oldAttrs[key];
      if (old !== cur) {
        let propName;
        if (external && (propName = kebabCaseToCamelCase(key)) in elm) {
          safelySetProperty(setProperty, elm, propName, cur);
        } else if (StringCharCodeAt.call(key, 3) === ColonCharCode) {
          setAttribute(elm, key, cur, XML_NAMESPACE);
        } else if (StringCharCodeAt.call(key, 5) === ColonCharCode) {
          setAttribute(elm, key, cur, XLINK_NAMESPACE);
        } else if (isNull(cur) || isUndefined$1(cur)) {
          removeAttribute(elm, key);
        } else {
          setAttribute(elm, key, cur);
        }
      }
    }
  }
  function patchSlotAssignment(oldVnode, vnode, renderer2) {
    const { slotAssignment } = vnode;
    if (oldVnode?.slotAssignment === slotAssignment) {
      return;
    }
    const { elm } = vnode;
    const { setAttribute, removeAttribute } = renderer2;
    if (isUndefined$1(slotAssignment) || isNull(slotAssignment)) {
      removeAttribute(elm, "slot");
    } else {
      setAttribute(elm, "slot", slotAssignment);
    }
  }
  function isLiveBindingProp(sel, key) {
    return sel === "input" && (key === "value" || key === "checked");
  }
  function patchProps(oldVnode, vnode, renderer2) {
    const { props } = vnode.data;
    if (isUndefined$1(props)) {
      return;
    }
    let oldProps;
    if (!isNull(oldVnode)) {
      oldProps = oldVnode.data.props;
      if (oldProps === props) {
        return;
      }
      if (isUndefined$1(oldProps)) {
        oldProps = EmptyObject;
      }
    }
    const isFirstPatch = isNull(oldVnode);
    const { elm, sel } = vnode;
    const { getProperty, setProperty } = renderer2;
    for (const key in props) {
      const cur = props[key];
      if (isFirstPatch || cur !== (isLiveBindingProp(sel, key) ? getProperty(elm, key) : oldProps[key]) || !(key in oldProps)) {
        if (false) {
          if (!(key in elm)) {
            logWarn(`Unknown public property "${key}" of element <${elm.tagName.toLowerCase()}>. This is either a typo on the corresponding attribute "${htmlPropertyToAttribute(key)}", or the attribute does not exist in this browser or DOM implementation.`);
          }
        }
        safelySetProperty(setProperty, elm, key, cur);
      }
    }
  }
  var classNameToClassMap = create(null);
  function getMapFromClassName(className) {
    if (isUndefined$1(className) || isNull(className) || className === "") {
      return EmptyObject;
    }
    className = isString(className) ? className : className + "";
    let map = classNameToClassMap[className];
    if (map) {
      return map;
    }
    map = create(null);
    let start2 = 0;
    let o;
    const len = className.length;
    for (o = 0; o < len; o++) {
      if (StringCharCodeAt.call(className, o) === SPACE_CHAR) {
        if (o > start2) {
          map[StringSlice.call(className, start2, o)] = true;
        }
        start2 = o + 1;
      }
    }
    if (o > start2) {
      map[StringSlice.call(className, start2, o)] = true;
    }
    classNameToClassMap[className] = map;
    if (false) {
      freeze(map);
    }
    return map;
  }
  function patchClassAttribute(oldVnode, vnode, renderer2) {
    const { elm, data: { className: newClass } } = vnode;
    const oldClass = isNull(oldVnode) ? void 0 : oldVnode.data.className;
    if (oldClass === newClass) {
      return;
    }
    const newClassMap = getMapFromClassName(newClass);
    const oldClassMap = getMapFromClassName(oldClass);
    if (oldClassMap === newClassMap) {
      return;
    }
    const { getClassList } = renderer2;
    const classList = getClassList(elm);
    let name;
    for (name in oldClassMap) {
      if (isUndefined$1(newClassMap[name])) {
        classList.remove(name);
      }
    }
    for (name in newClassMap) {
      if (isUndefined$1(oldClassMap[name])) {
        classList.add(name);
      }
    }
  }
  function patchStyleAttribute(oldVnode, vnode, renderer2, owner) {
    const { elm, data: { style: newStyle } } = vnode;
    if (false) {
      if (!isNull(newStyle) && !isUndefined$1(newStyle) && !isString(newStyle)) {
        logError(`Invalid 'style' attribute passed to <${elm.tagName.toLowerCase()}> is ignored. This attribute must be a string value.`, owner);
      }
    }
    const oldStyle = isNull(oldVnode) ? void 0 : oldVnode.data.style;
    if (oldStyle === newStyle) {
      return;
    }
    const { setAttribute, removeAttribute } = renderer2;
    if (!isString(newStyle) || newStyle === "") {
      removeAttribute(elm, "style");
    } else {
      setAttribute(elm, "style", newStyle);
    }
  }
  function applyEventListeners(vnode, renderer2) {
    const { elm, data } = vnode;
    const { on } = data;
    if (isUndefined$1(on)) {
      return;
    }
    const { addEventListener } = renderer2;
    for (const name in on) {
      const handler = on[name];
      addEventListener(elm, name, handler);
    }
  }
  function patchDynamicEventListeners(oldVnode, vnode, renderer2, owner) {
    const { elm, data: { dynamicOn, dynamicOnRaw }, sel } = vnode;
    const oldDynamicOn = oldVnode?.data?.dynamicOn ?? EmptyObject;
    const newDynamicOn = dynamicOn ?? EmptyObject;
    const isObjectSame = oldVnode?.data?.dynamicOnRaw === dynamicOnRaw;
    const { addEventListener, removeEventListener } = renderer2;
    const attachedEventListeners = getAttachedEventListeners(owner, elm);
    for (const eventType in oldDynamicOn) {
      if (!(eventType in newDynamicOn)) {
        if (isObjectSame && false) {
          logError(`Detected mutation of property '${eventType}' in the object passed to lwc:on for <${sel}>. Reusing the same object with modified properties is prohibited. Please pass a new object instead.`, owner);
        }
        const attachedEventListener = attachedEventListeners[eventType];
        removeEventListener(elm, eventType, attachedEventListener);
        attachedEventListeners[eventType] = void 0;
      }
    }
    for (const eventType in newDynamicOn) {
      const typeExistsInOld = eventType in oldDynamicOn;
      const newCallback = newDynamicOn[eventType];
      if (typeExistsInOld && oldDynamicOn[eventType] === newCallback) {
        continue;
      }
      if (isObjectSame && false) {
        logError(`Detected mutation of property '${eventType}' in the object passed to lwc:on for <${sel}>. Reusing the same object with modified properties is prohibited. Please pass a new object instead.`, owner);
      }
      if (typeExistsInOld) {
        const attachedEventListener = attachedEventListeners[eventType];
        removeEventListener(elm, eventType, attachedEventListener);
      }
      const newBoundEventListener = bindEventListener(owner, newCallback);
      addEventListener(elm, eventType, newBoundEventListener);
      attachedEventListeners[eventType] = newBoundEventListener;
    }
  }
  function getAttachedEventListeners(vm, elm) {
    let attachedEventListeners = vm.attachedEventListeners.get(elm);
    if (isUndefined$1(attachedEventListeners)) {
      attachedEventListeners = {};
      vm.attachedEventListeners.set(elm, attachedEventListeners);
    }
    return attachedEventListeners;
  }
  function bindEventListener(vm, fn) {
    return function(event) {
      invokeEventListener(vm, fn, vm.component, event);
    };
  }
  function applyStaticClassAttribute(vnode, renderer2) {
    const { elm, data: { classMap } } = vnode;
    if (isUndefined$1(classMap)) {
      return;
    }
    const { getClassList } = renderer2;
    const classList = getClassList(elm);
    for (const name in classMap) {
      classList.add(name);
    }
  }
  function applyStaticStyleAttribute(vnode, renderer2) {
    const { elm, data: { styleDecls } } = vnode;
    if (isUndefined$1(styleDecls)) {
      return;
    }
    const { setCSSStyleProperty } = renderer2;
    for (let i2 = 0; i2 < styleDecls.length; i2++) {
      const [prop, value, important] = styleDecls[i2];
      setCSSStyleProperty(elm, prop, value, important);
    }
  }
  function applyRefs(vnode, owner) {
    const { data } = vnode;
    const { ref } = data;
    if (isUndefined$1(ref)) {
      return;
    }
    if (false) {
      throw new Error("refVNodes must be defined when setting a ref");
    }
    const refVNodes = owner.refVNodes;
    refVNodes[ref] = vnode;
  }
  function patchTextVNode(n1, n2, renderer2) {
    n2.elm = n1.elm;
    if (n2.text !== n1.text) {
      updateTextContent$1(n2, renderer2);
    }
  }
  function patchTextVStaticPart(n1, n2, renderer2) {
    if (isNull(n1) || n2.text !== n1.text) {
      updateTextContent$1(n2, renderer2);
    }
  }
  function updateTextContent$1(vnode, renderer2) {
    const { elm, text } = vnode;
    const { setText } = renderer2;
    if (false) {
      unlockDomMutation();
    }
    setText(elm, text);
    if (false) {
      lockDomMutation();
    }
  }
  function traverseAndSetElements(root, parts, renderer2) {
    const numParts = parts.length;
    if (numParts === 1) {
      const firstPart = parts[0];
      if (firstPart.partId === 0) {
        firstPart.elm = root;
        return;
      }
    }
    const partIdsToParts = /* @__PURE__ */ new Map();
    for (const staticPart of parts) {
      partIdsToParts.set(staticPart.partId, staticPart);
    }
    const { nextSibling, getFirstChild, getParentNode } = renderer2;
    let numFoundParts = 0;
    let partId = -1;
    function assertNotRoot(node2) {
      if (false) {
        assert.isFalse(node2 === root, `Reached the root without finding all parts. Found ${numFoundParts}, needed ${numParts}.`);
      }
    }
    let node = root;
    while (!isNull(node)) {
      partId++;
      const part = partIdsToParts.get(partId);
      if (!isUndefined$1(part)) {
        part.elm = node;
        numFoundParts++;
        if (numFoundParts === numParts) {
          return;
        }
      }
      const child = getFirstChild(node);
      if (!isNull(child)) {
        node = child;
      } else {
        let sibling;
        while (isNull(sibling = nextSibling(node))) {
          assertNotRoot(node);
          node = getParentNode(node);
        }
        assertNotRoot(node);
        node = sibling;
      }
    }
    if (false) {
      assert.isTrue(numFoundParts === numParts, `Should have found all parts by now. Found ${numFoundParts}, needed ${numParts}.`);
    }
  }
  function mountStaticParts(root, vnode, renderer2) {
    const { parts, owner } = vnode;
    if (isUndefined$1(parts)) {
      return;
    }
    traverseAndSetElements(root, parts, renderer2);
    for (const part of parts) {
      if (isVStaticPartElement(part)) {
        applyEventListeners(part, renderer2);
        applyRefs(part, owner);
        patchAttributes(null, part, renderer2);
        patchClassAttribute(null, part, renderer2);
        patchStyleAttribute(null, part, renderer2, owner);
      } else {
        if (false) {
          throw new Error(`LWC internal error, encountered unknown static part type: ${part.type}`);
        }
        patchTextVStaticPart(null, part, renderer2);
      }
    }
  }
  function patchStaticParts(n1, n2, renderer2) {
    const { parts: currParts, owner: currPartsOwner } = n2;
    if (isUndefined$1(currParts)) {
      return;
    }
    const { parts: prevParts } = n1;
    if (false) {
      assert.isTrue(currParts.length === prevParts?.length, "Expected static parts to be the same for the same element. This is an error with the LWC framework itself.");
    }
    for (let i2 = 0; i2 < currParts.length; i2++) {
      const prevPart = prevParts[i2];
      const part = currParts[i2];
      part.elm = prevPart.elm;
      if (false) {
        throw new Error(`LWC internal error, static part types do not match. Previous type was ${prevPart.type} and current type is ${part.type}`);
      }
      if (isVStaticPartElement(part)) {
        applyRefs(part, currPartsOwner);
        patchAttributes(prevPart, part, renderer2);
        patchClassAttribute(prevPart, part, renderer2);
        patchStyleAttribute(prevPart, part, renderer2, currPartsOwner);
      } else {
        patchTextVStaticPart(null, part, renderer2);
      }
    }
  }
  function patchChildren(c1, c2, parent, renderer2) {
    if (hasDynamicChildren(c2)) {
      updateDynamicChildren(c1, c2, parent, renderer2);
    } else {
      updateStaticChildren(c1, c2, parent, renderer2);
    }
  }
  function patch(n1, n2, parent, renderer2) {
    if (n1 === n2) {
      return;
    }
    if (false) {
      if (!isSameVnode(n1, n2) && // Currently the only scenario when patch does not receive the same vnodes are for
      // dynamic components. When a dynamic component's constructor changes, the value of its
      // tag name (sel) will be different. The engine will unmount the previous element
      // and mount the new one using the new constructor in patchCustomElement.
      !(isVCustomElement(n1) && isVCustomElement(n2))) {
        throw new Error("Expected these VNodes to be the same: " + JSON.stringify({ sel: n1.sel, key: n1.key }) + ", " + JSON.stringify({ sel: n2.sel, key: n2.key }));
      }
    }
    switch (n2.type) {
      case 0:
        patchTextVNode(n1, n2, renderer2);
        break;
      case 1:
        patchComment(n1, n2, renderer2);
        break;
      case 4:
        patchStatic(n1, n2, renderer2);
        break;
      case 5:
        patchFragment(n1, n2, parent, renderer2);
        break;
      case 2:
        patchElement(n1, n2, n2.data.renderer ?? renderer2);
        break;
      case 3:
        patchCustomElement(n1, n2, parent, n2.data.renderer ?? renderer2);
        break;
    }
  }
  function mount(node, parent, renderer2, anchor) {
    switch (node.type) {
      case 0:
        mountText(node, parent, anchor, renderer2);
        break;
      case 1:
        mountComment(node, parent, anchor, renderer2);
        break;
      case 4:
        mountStatic(node, parent, anchor, renderer2);
        break;
      case 5:
        mountFragment(node, parent, anchor, renderer2);
        break;
      case 2:
        mountElement(node, parent, anchor, node.data.renderer ?? renderer2);
        break;
      case 3:
        mountCustomElement(node, parent, anchor, node.data.renderer ?? renderer2);
        break;
    }
  }
  function mountText(vnode, parent, anchor, renderer2) {
    const { owner } = vnode;
    const { createText } = renderer2;
    const textNode = vnode.elm = createText(vnode.text);
    linkNodeToShadow(textNode, owner, renderer2);
    insertNode(textNode, parent, anchor, renderer2);
  }
  function patchComment(n1, n2, renderer2) {
    n2.elm = n1.elm;
    if (n2.text !== n1.text) {
      updateTextContent$1(n2, renderer2);
    }
  }
  function mountComment(vnode, parent, anchor, renderer2) {
    const { owner } = vnode;
    const { createComment } = renderer2;
    const commentNode = vnode.elm = createComment(vnode.text);
    linkNodeToShadow(commentNode, owner, renderer2);
    insertNode(commentNode, parent, anchor, renderer2);
  }
  function mountFragment(vnode, parent, anchor, renderer2) {
    const { children } = vnode;
    mountVNodes(children, parent, renderer2, anchor);
    vnode.elm = vnode.leading.elm;
  }
  function patchFragment(n1, n2, parent, renderer2) {
    const { children, stable } = n2;
    if (stable) {
      updateStaticChildren(n1.children, children, parent, renderer2);
    } else {
      updateDynamicChildren(n1.children, children, parent, renderer2);
    }
    n2.elm = n2.leading.elm;
  }
  function mountElement(vnode, parent, anchor, renderer2) {
    const { sel, owner, data: { svg } } = vnode;
    const { createElement: createElement2 } = renderer2;
    const namespace = isTrue(svg) ? SVG_NAMESPACE : void 0;
    const elm = vnode.elm = createElement2(sel, namespace);
    linkNodeToShadow(elm, owner, renderer2);
    applyStyleScoping(elm, owner, renderer2);
    applyDomManual(elm, vnode);
    applyElementRestrictions(elm, vnode);
    patchElementPropsAndAttrsAndRefs$1(null, vnode, renderer2);
    insertNode(elm, parent, anchor, renderer2);
    mountVNodes(vnode.children, elm, renderer2, null);
  }
  function patchStatic(n1, n2, renderer2) {
    n2.elm = n1.elm;
    patchSlotAssignment(n1, n2, renderer2);
    patchStaticParts(n1, n2, renderer2);
  }
  function patchElement(n1, n2, renderer2) {
    const elm = n2.elm = n1.elm;
    patchElementPropsAndAttrsAndRefs$1(n1, n2, renderer2);
    patchChildren(n1.children, n2.children, elm, renderer2);
  }
  function mountStatic(vnode, parent, anchor, renderer2) {
    const { owner } = vnode;
    const { cloneNode, isSyntheticShadowDefined } = renderer2;
    const elm = vnode.elm = cloneNode(vnode.fragment, true);
    linkNodeToShadow(elm, owner, renderer2);
    applyElementRestrictions(elm, vnode);
    const { renderMode, shadowMode } = owner;
    if (isSyntheticShadowDefined) {
      if (shadowMode === 1 || renderMode === 0) {
        elm[KEY__SHADOW_STATIC] = true;
      }
    }
    patchSlotAssignment(null, vnode, renderer2);
    mountStaticParts(elm, vnode, renderer2);
    insertNode(elm, parent, anchor, renderer2);
  }
  function mountCustomElement(vnode, parent, anchor, renderer2) {
    const { sel, owner, ctor } = vnode;
    const { createCustomElement: createCustomElement2 } = renderer2;
    let vm;
    const upgradeCallback = (elm2) => {
      vm = createViewModelHook(elm2, vnode, renderer2);
    };
    const normalizedTagname = sel.toLowerCase();
    const useNativeLifecycle = !lwcRuntimeFlags.DISABLE_NATIVE_CUSTOM_ELEMENT_LIFECYCLE;
    const isFormAssociated = shouldBeFormAssociated(ctor);
    const elm = createCustomElement2(normalizedTagname, upgradeCallback, useNativeLifecycle, isFormAssociated);
    vnode.elm = elm;
    vnode.vm = vm;
    linkNodeToShadow(elm, owner, renderer2);
    applyStyleScoping(elm, owner, renderer2);
    if (vm) {
      allocateChildren(vnode, vm);
    }
    patchElementPropsAndAttrsAndRefs$1(null, vnode, renderer2);
    insertNode(elm, parent, anchor, renderer2);
    if (vm) {
      {
        if (!useNativeLifecycle) {
          if (false) {
            assert.isTrue(vm.state === 0, `${vm} cannot be recycled.`);
          }
          runConnectedCallback(vm);
        }
      }
    }
    mountVNodes(vnode.children, elm, renderer2, null);
    if (vm) {
      appendVM(vm);
    }
  }
  function patchCustomElement(n1, n2, parent, renderer2) {
    if (n1.ctor !== n2.ctor) {
      const anchor = renderer2.nextSibling(n1.elm);
      unmount(n1, parent, renderer2, true);
      mountCustomElement(n2, parent, anchor, renderer2);
    } else {
      const elm = n2.elm = n1.elm;
      const vm = n2.vm = n1.vm;
      patchElementPropsAndAttrsAndRefs$1(n1, n2, renderer2);
      if (!isUndefined$1(vm)) {
        allocateChildren(n2, vm);
        const { shadowMode, renderMode } = vm;
        if (shadowMode == 0 && renderMode !== 0 && hasDynamicChildren(n1.children)) {
          markAsDynamicChildren(n2.children);
        }
      }
      patchChildren(n1.children, n2.children, elm, renderer2);
      if (!isUndefined$1(vm)) {
        rerenderVM(vm);
      }
    }
  }
  function mountVNodes(vnodes, parent, renderer2, anchor, start2 = 0, end2 = vnodes.length) {
    for (; start2 < end2; ++start2) {
      const vnode = vnodes[start2];
      if (isVNode(vnode)) {
        mount(vnode, parent, renderer2, anchor);
      }
    }
  }
  function unmount(vnode, parent, renderer2, doRemove = false) {
    const { type, elm, sel } = vnode;
    if (doRemove && type !== 5) {
      removeNode(elm, parent, renderer2);
    }
    switch (type) {
      case 5: {
        unmountVNodes(vnode.children, parent, renderer2, doRemove);
        break;
      }
      case 2: {
        const shouldRemoveChildren = sel === "slot" && vnode.owner.shadowMode === 1;
        unmountVNodes(vnode.children, elm, renderer2, shouldRemoveChildren);
        break;
      }
      case 3: {
        const { vm } = vnode;
        if (!isUndefined$1(vm)) {
          removeVM(vm);
        }
      }
    }
  }
  function unmountVNodes(vnodes, parent, renderer2, doRemove = false, start2 = 0, end2 = vnodes.length) {
    for (; start2 < end2; ++start2) {
      const ch = vnodes[start2];
      if (isVNode(ch)) {
        unmount(ch, parent, renderer2, doRemove);
      }
    }
  }
  function isVNode(vnode) {
    return vnode != null;
  }
  function linkNodeToShadow(elm, owner, renderer2) {
    const { renderRoot, renderMode, shadowMode } = owner;
    const { isSyntheticShadowDefined } = renderer2;
    if (isSyntheticShadowDefined) {
      if (shadowMode === 1 || renderMode === 0) {
        elm[KEY__SHADOW_RESOLVER] = renderRoot[KEY__SHADOW_RESOLVER];
      }
    }
  }
  function insertFragmentOrNode(vnode, parent, anchor, renderer2) {
    if (false) {
      unlockDomMutation();
    }
    if (isVFragment(vnode)) {
      const children = vnode.children;
      for (let i2 = 0; i2 < children.length; i2 += 1) {
        const child = children[i2];
        if (!isNull(child)) {
          renderer2.insert(child.elm, parent, anchor);
        }
      }
    } else {
      renderer2.insert(vnode.elm, parent, anchor);
    }
    if (false) {
      lockDomMutation();
    }
  }
  function insertNode(node, parent, anchor, renderer2) {
    if (false) {
      unlockDomMutation();
    }
    renderer2.insert(node, parent, anchor);
    if (false) {
      lockDomMutation();
    }
  }
  function removeNode(node, parent, renderer2) {
    if (false) {
      unlockDomMutation();
    }
    renderer2.remove(node, parent);
    if (false) {
      lockDomMutation();
    }
  }
  function patchElementPropsAndAttrsAndRefs$1(oldVnode, vnode, renderer2) {
    if (isNull(oldVnode)) {
      applyEventListeners(vnode, renderer2);
      applyStaticClassAttribute(vnode, renderer2);
      applyStaticStyleAttribute(vnode, renderer2);
    }
    const { owner } = vnode;
    patchDynamicEventListeners(oldVnode, vnode, renderer2, owner);
    patchClassAttribute(oldVnode, vnode, renderer2);
    patchStyleAttribute(oldVnode, vnode, renderer2, owner);
    patchAttributes(oldVnode, vnode, renderer2);
    patchProps(oldVnode, vnode, renderer2);
    patchSlotAssignment(oldVnode, vnode, renderer2);
    applyRefs(vnode, owner);
  }
  function applyStyleScoping(elm, owner, renderer2) {
    const { getClassList } = renderer2;
    const scopeToken = getScopeTokenClass(
      owner,
      /* legacy */
      false
    );
    if (!isNull(scopeToken)) {
      if (!isValidScopeToken(scopeToken)) {
        throw new Error("stylesheet token must be a valid string");
      }
      getClassList(elm).add(scopeToken);
    }
    if (lwcRuntimeFlags.ENABLE_LEGACY_SCOPE_TOKENS) {
      const legacyScopeToken = getScopeTokenClass(
        owner,
        /* legacy */
        true
      );
      if (!isNull(legacyScopeToken)) {
        if (!isValidScopeToken(legacyScopeToken)) {
          throw new Error("stylesheet token must be a valid string");
        }
        getClassList(elm).add(legacyScopeToken);
      }
    }
    const { stylesheetToken: syntheticToken } = owner.context;
    if (owner.shadowMode === 1) {
      if (!isUndefined$1(syntheticToken)) {
        elm.$shadowToken$ = syntheticToken;
      }
      if (lwcRuntimeFlags.ENABLE_LEGACY_SCOPE_TOKENS) {
        const legacyToken = owner.context.legacyStylesheetToken;
        if (!isUndefined$1(legacyToken)) {
          elm.$legacyShadowToken$ = legacyToken;
        }
      }
    }
  }
  function applyDomManual(elm, vnode) {
    const { owner, data: { context } } = vnode;
    if (owner.shadowMode === 1 && context?.lwc?.dom === "manual") {
      elm.$domManual$ = true;
    }
  }
  function applyElementRestrictions(elm, vnode) {
    if (false) {
      const isSynthetic = vnode.owner.shadowMode === 1;
      const isPortal = vnode.type === 2 && vnode.data.context?.lwc?.dom === "manual";
      const isLight = vnode.owner.renderMode === 0;
      patchElementWithRestrictions(elm, {
        isPortal,
        isLight,
        isSynthetic
      });
    }
  }
  function allocateChildren(vnode, vm) {
    const children = vnode.aChildren || vnode.children;
    const { renderMode, shadowMode } = vm;
    if (false) {
      if (renderMode !== 0 && ArraySome.call(children, (child) => !isNull(child) && isVScopedSlotFragment(child))) {
        logError(`Invalid usage of 'lwc:slot-data' on ${getComponentTag(vm)} tag. Scoped slot content can only be passed to a light dom child.`);
      }
    }
    const allocatedChildren = flattenFragmentsInChildren(children);
    vnode.children = allocatedChildren;
    vm.aChildren = allocatedChildren;
    if (shadowMode === 1 || renderMode === 0) {
      allocateInSlot(vm, allocatedChildren, vnode.owner);
      vnode.aChildren = allocatedChildren;
      vnode.children = EmptyArray;
    }
  }
  function flattenFragmentsInChildren(children) {
    const flattenedChildren = [];
    const nodeStack = [];
    let fragmentFound = false;
    for (let i2 = children.length - 1; i2 > -1; i2 -= 1) {
      const child = children[i2];
      ArrayPush$1.call(nodeStack, child);
      fragmentFound = fragmentFound || !!(child && isVFragment(child));
    }
    if (!fragmentFound) {
      return children;
    }
    let currentNode;
    while (!isUndefined$1(currentNode = ArrayPop.call(nodeStack))) {
      if (!isNull(currentNode) && isVFragment(currentNode)) {
        const fChildren = currentNode.children;
        for (let i2 = fChildren.length - 2; i2 > 0; i2 -= 1) {
          ArrayPush$1.call(nodeStack, fChildren[i2]);
        }
      } else {
        ArrayPush$1.call(flattenedChildren, currentNode);
      }
    }
    markAsDynamicChildren(flattenedChildren);
    return flattenedChildren;
  }
  function createViewModelHook(elm, vnode, renderer2) {
    let vm = getAssociatedVMIfPresent(elm);
    if (!isUndefined$1(vm)) {
      return vm;
    }
    const { sel, mode, ctor, owner } = vnode;
    vm = createVM(elm, ctor, renderer2, {
      mode,
      owner,
      tagName: sel
    });
    if (false) {
      assert.isTrue(isArray$1(vnode.children), `Invalid vnode for a custom element, it must have children defined.`);
    }
    return vm;
  }
  function allocateInSlot(vm, children, owner) {
    const { cmpSlots: { slotAssignments: oldSlotsMapping } } = vm;
    const cmpSlotsMapping = create(null);
    for (let i2 = 0, len = children.length; i2 < len; i2 += 1) {
      const vnode = children[i2];
      if (isNull(vnode)) {
        continue;
      }
      let slotName = "";
      if (isVBaseElement(vnode) || isVStatic(vnode)) {
        slotName = vnode.slotAssignment ?? "";
      } else if (isVScopedSlotFragment(vnode)) {
        slotName = vnode.slotName;
      }
      const normalizedSlotName = "" + slotName;
      const vnodes = cmpSlotsMapping[normalizedSlotName] = cmpSlotsMapping[normalizedSlotName] || [];
      ArrayPush$1.call(vnodes, vnode);
    }
    vm.cmpSlots = { owner, slotAssignments: cmpSlotsMapping };
    if (isFalse(vm.isDirty)) {
      const oldKeys = keys(oldSlotsMapping);
      if (oldKeys.length !== keys(cmpSlotsMapping).length) {
        markComponentAsDirty(vm);
        return;
      }
      for (let i2 = 0, len = oldKeys.length; i2 < len; i2 += 1) {
        const key = oldKeys[i2];
        if (isUndefined$1(cmpSlotsMapping[key]) || oldSlotsMapping[key].length !== cmpSlotsMapping[key].length) {
          markComponentAsDirty(vm);
          return;
        }
        const oldVNodes = oldSlotsMapping[key];
        const vnodes = cmpSlotsMapping[key];
        for (let j = 0, a = cmpSlotsMapping[key].length; j < a; j += 1) {
          if (oldVNodes[j] !== vnodes[j]) {
            markComponentAsDirty(vm);
            return;
          }
        }
      }
    }
  }
  var DynamicChildren = /* @__PURE__ */ new WeakSet();
  function markAsDynamicChildren(children) {
    DynamicChildren.add(children);
  }
  function hasDynamicChildren(children) {
    return DynamicChildren.has(children);
  }
  function createKeyToOldIdx(children, beginIdx, endIdx) {
    const map = {};
    for (let j = beginIdx; j <= endIdx; ++j) {
      const ch = children[j];
      if (isVNode(ch)) {
        const { key } = ch;
        if (key !== void 0) {
          map[key] = j;
        }
      }
    }
    return map;
  }
  function updateDynamicChildren(oldCh, newCh, parent, renderer2) {
    let oldStartIdx = 0;
    let newStartIdx = 0;
    let oldEndIdx = oldCh.length - 1;
    let oldStartVnode = oldCh[0];
    let oldEndVnode = oldCh[oldEndIdx];
    const newChEnd = newCh.length - 1;
    let newEndIdx = newChEnd;
    let newStartVnode = newCh[0];
    let newEndVnode = newCh[newEndIdx];
    let oldKeyToIdx;
    let idxInOld;
    let elmToMove;
    let before;
    let clonedOldCh = false;
    while (oldStartIdx <= oldEndIdx && newStartIdx <= newEndIdx) {
      if (!isVNode(oldStartVnode)) {
        oldStartVnode = oldCh[++oldStartIdx];
      } else if (!isVNode(oldEndVnode)) {
        oldEndVnode = oldCh[--oldEndIdx];
      } else if (!isVNode(newStartVnode)) {
        newStartVnode = newCh[++newStartIdx];
      } else if (!isVNode(newEndVnode)) {
        newEndVnode = newCh[--newEndIdx];
      } else if (isSameVnode(oldStartVnode, newStartVnode)) {
        patch(oldStartVnode, newStartVnode, parent, renderer2);
        oldStartVnode = oldCh[++oldStartIdx];
        newStartVnode = newCh[++newStartIdx];
      } else if (isSameVnode(oldEndVnode, newEndVnode)) {
        patch(oldEndVnode, newEndVnode, parent, renderer2);
        oldEndVnode = oldCh[--oldEndIdx];
        newEndVnode = newCh[--newEndIdx];
      } else if (isSameVnode(oldStartVnode, newEndVnode)) {
        patch(oldStartVnode, newEndVnode, parent, renderer2);
        let anchor;
        if (isVFragment(oldEndVnode)) {
          anchor = renderer2.nextSibling(oldEndVnode.trailing.elm);
        } else {
          anchor = renderer2.nextSibling(oldEndVnode.elm);
        }
        insertFragmentOrNode(oldStartVnode, parent, anchor, renderer2);
        oldStartVnode = oldCh[++oldStartIdx];
        newEndVnode = newCh[--newEndIdx];
      } else if (isSameVnode(oldEndVnode, newStartVnode)) {
        patch(oldEndVnode, newStartVnode, parent, renderer2);
        insertFragmentOrNode(newStartVnode, parent, oldStartVnode.elm, renderer2);
        oldEndVnode = oldCh[--oldEndIdx];
        newStartVnode = newCh[++newStartIdx];
      } else {
        if (oldKeyToIdx === void 0) {
          oldKeyToIdx = createKeyToOldIdx(oldCh, oldStartIdx, oldEndIdx);
        }
        idxInOld = oldKeyToIdx[newStartVnode.key];
        if (isUndefined$1(idxInOld)) {
          mount(newStartVnode, parent, renderer2, oldStartVnode.elm);
          newStartVnode = newCh[++newStartIdx];
        } else {
          elmToMove = oldCh[idxInOld];
          if (isVNode(elmToMove)) {
            if (elmToMove.sel !== newStartVnode.sel) {
              mount(newStartVnode, parent, renderer2, oldStartVnode.elm);
            } else {
              patch(elmToMove, newStartVnode, parent, renderer2);
              if (!clonedOldCh) {
                clonedOldCh = true;
                oldCh = [...oldCh];
              }
              oldCh[idxInOld] = void 0;
              insertFragmentOrNode(elmToMove, parent, oldStartVnode.elm, renderer2);
            }
          }
          newStartVnode = newCh[++newStartIdx];
        }
      }
    }
    if (oldStartIdx <= oldEndIdx || newStartIdx <= newEndIdx) {
      if (oldStartIdx > oldEndIdx) {
        let i2 = newEndIdx;
        let n;
        do {
          n = newCh[++i2];
        } while (!isVNode(n) && i2 < newChEnd);
        before = isVNode(n) ? n.elm : null;
        mountVNodes(newCh, parent, renderer2, before, newStartIdx, newEndIdx + 1);
      } else {
        unmountVNodes(oldCh, parent, renderer2, true, oldStartIdx, oldEndIdx + 1);
      }
    }
  }
  function updateStaticChildren(c1, c2, parent, renderer2) {
    const c1Length = c1.length;
    const c2Length = c2.length;
    if (c1Length === 0) {
      mountVNodes(c2, parent, renderer2, null);
      return;
    }
    if (c2Length === 0) {
      unmountVNodes(c1, parent, renderer2, true);
      return;
    }
    let anchor = null;
    for (let i2 = c2Length - 1; i2 >= 0; i2 -= 1) {
      const n1 = c1[i2];
      const n2 = c2[i2];
      if (n2 !== n1) {
        if (isVNode(n1)) {
          if (isVNode(n2)) {
            if (isSameVnode(n1, n2)) {
              patch(n1, n2, parent, renderer2);
              anchor = n2.elm;
            } else {
              unmount(n1, parent, renderer2, true);
              mount(n2, parent, renderer2, anchor);
              anchor = n2.elm;
            }
          } else {
            unmount(n1, parent, renderer2, true);
          }
        } else if (isVNode(n2)) {
          mount(n2, parent, renderer2, anchor);
          anchor = n2.elm;
        }
      }
    }
  }
  var SymbolIterator = Symbol.iterator;
  function addVNodeToChildLWC(vnode) {
    ArrayPush$1.call(getVMBeingRendered().velements, vnode);
  }
  function sp(partId, data, text) {
    const type = isNull(text) ? 1 : 0;
    return {
      type,
      partId,
      data,
      text,
      elm: void 0
      // elm is defined later
    };
  }
  function ssf(slotName, factory) {
    return {
      type: 6,
      factory,
      owner: getVMBeingRendered(),
      elm: void 0,
      sel: "__scoped_slot_fragment__",
      key: void 0,
      slotName
    };
  }
  function st(fragmentFactory, key, parts) {
    const owner = getVMBeingRendered();
    const fragment = fragmentFactory(parts);
    const vnode = {
      type: 4,
      sel: "__static__",
      key,
      elm: void 0,
      fragment,
      owner,
      parts,
      slotAssignment: void 0
    };
    return vnode;
  }
  function fr(key, children, stable) {
    const owner = getVMBeingRendered();
    const useCommentNodes = isAPIFeatureEnabled(5, owner.apiVersion);
    const leading = useCommentNodes ? co("") : t("");
    const trailing = useCommentNodes ? co("") : t("");
    return {
      type: 5,
      sel: "__fragment__",
      key,
      elm: void 0,
      children: [leading, ...children, trailing],
      stable,
      owner,
      leading,
      trailing
    };
  }
  function h(sel, data, children = EmptyArray) {
    const vmBeingRendered2 = getVMBeingRendered();
    if (false) {
      assert.isTrue(isString(sel), `h() 1st argument sel must be a string.`);
      assert.isTrue(isObject(data), `h() 2nd argument data must be an object.`);
      assert.isTrue(isArray$1(children), `h() 3rd argument children must be an array.`);
      assert.isTrue("key" in data, ` <${sel}> "key" attribute is invalid or missing for ${vmBeingRendered2}. Key inside iterator is either undefined or null.`);
      assert.isFalse(data.className && data.classMap, `vnode.data.className and vnode.data.classMap ambiguous declaration.`);
      assert.isFalse(data.styleDecls && data.style, `vnode.data.styleDecls and vnode.data.style ambiguous declaration.`);
      forEach.call(children, (childVnode) => {
        if (childVnode != null) {
          assert.isTrue("type" in childVnode && "sel" in childVnode && "elm" in childVnode && "key" in childVnode, `${childVnode} is not a vnode.`);
        }
      });
    }
    const { key, slotAssignment } = data;
    const vnode = {
      type: 2,
      sel,
      data,
      children,
      elm: void 0,
      key,
      owner: vmBeingRendered2,
      slotAssignment
    };
    return vnode;
  }
  function ti(value) {
    const shouldNormalize = value > 0 && !(isTrue(value) || isFalse(value));
    if (false) {
      const vmBeingRendered2 = getVMBeingRendered();
      if (shouldNormalize) {
        logError(`Invalid tabindex value \`${toString(value)}\` in template for ${vmBeingRendered2}. This attribute must be set to 0 or -1.`, vmBeingRendered2);
      }
    }
    return shouldNormalize ? 0 : value;
  }
  function s(slotName, data, children, slotset) {
    if (false) {
      assert.isTrue(isString(slotName), `s() 1st argument slotName must be a string.`);
      assert.isTrue(isObject(data), `s() 2nd argument data must be an object.`);
      assert.isTrue(isArray$1(children), `h() 3rd argument children must be an array.`);
    }
    const vmBeingRendered2 = getVMBeingRendered();
    const { renderMode, apiVersion } = vmBeingRendered2;
    if (!isUndefined$1(slotset) && !isUndefined$1(slotset.slotAssignments) && !isUndefined$1(slotset.slotAssignments[slotName]) && slotset.slotAssignments[slotName].length !== 0) {
      const newChildren = [];
      const slotAssignments = slotset.slotAssignments[slotName];
      for (let i2 = 0; i2 < slotAssignments.length; i2++) {
        const vnode = slotAssignments[i2];
        if (!isNull(vnode)) {
          const assignedNodeIsScopedSlot = isVScopedSlotFragment(vnode);
          const isScopedSlotElement = !isUndefined$1(data.slotData);
          if (assignedNodeIsScopedSlot !== isScopedSlotElement) {
            if (false) {
              logError(`Mismatched slot types for ${slotName === "" ? "(default)" : slotName} slot. Both parent and child component must use standard type or scoped type for a given slot.`, slotset.owner);
            }
            continue;
          }
          if (assignedNodeIsScopedSlot) {
            setVMBeingRendered(slotset.owner);
            try {
              const { tro } = slotset.owner;
              tro.observe(() => {
                ArrayPush$1.call(newChildren, vnode.factory(data.slotData, data.key));
              });
            } finally {
              setVMBeingRendered(vmBeingRendered2);
            }
          } else {
            let clonedVNode;
            if (renderMode === 0 && isAPIFeatureEnabled(6, apiVersion) && (isVBaseElement(vnode) || isVStatic(vnode)) && vnode.slotAssignment !== data.slotAssignment) {
              clonedVNode = { ...vnode, slotAssignment: data.slotAssignment };
              if (isVCustomElement(vnode)) {
                addVNodeToChildLWC(clonedVNode);
              }
            }
            ArrayPush$1.call(newChildren, clonedVNode ?? vnode);
          }
        }
      }
      children = newChildren;
    }
    const { shadowMode } = vmBeingRendered2;
    if (renderMode === 0) {
      if (isAPIFeatureEnabled(2, apiVersion)) {
        return fr(data.key, children, 0);
      } else {
        sc(children);
        return children;
      }
    }
    if (shadowMode === 1) {
      sc(children);
    }
    return h("slot", data, children);
  }
  function c(sel, Ctor, data, children = EmptyArray) {
    const vmBeingRendered2 = getVMBeingRendered();
    if (false) {
      assert.isTrue(isString(sel), `c() 1st argument sel must be a string.`);
      assert.isTrue(isFunction$1(Ctor), `c() 2nd argument Ctor must be a function.`);
      assert.isTrue(isObject(data), `c() 3nd argument data must be an object.`);
      assert.isTrue(arguments.length === 3 || isArray$1(children), `c() 4nd argument data must be an array.`);
      assert.isFalse(data.className && data.classMap, `vnode.data.className and vnode.data.classMap ambiguous declaration.`);
      assert.isFalse(data.styleDecls && data.style, `vnode.data.styleDecls and vnode.data.style ambiguous declaration.`);
      if (data.style && !isString(data.style)) {
        logError(`Invalid 'style' attribute passed to <${sel}> is ignored. This attribute must be a string value.`, vmBeingRendered2);
      }
      if (arguments.length === 4) {
        forEach.call(children, (childVnode) => {
          if (childVnode != null) {
            assert.isTrue("type" in childVnode && "sel" in childVnode && "elm" in childVnode && "key" in childVnode, `${childVnode} is not a vnode.`);
          }
        });
      }
    }
    const { key, slotAssignment } = data;
    const vnode = {
      type: 3,
      sel,
      data,
      children,
      elm: void 0,
      key,
      slotAssignment,
      ctor: Ctor,
      owner: vmBeingRendered2,
      mode: "open",
      // TODO [#1294]: this should be defined in Ctor
      aChildren: void 0,
      vm: void 0
    };
    addVNodeToChildLWC(vnode);
    return vnode;
  }
  function i(iterable, factory) {
    const list = [];
    sc(list);
    const vmBeingRendered2 = getVMBeingRendered();
    if (isUndefined$1(iterable) || isNull(iterable)) {
      if (false) {
        logError(`Invalid template iteration for value \`${toString(iterable)}\` in ${vmBeingRendered2}. It must be an array-like object.`, vmBeingRendered2);
      }
      return list;
    }
    if (false) {
      assert.isFalse(isUndefined$1(iterable[SymbolIterator]), `Invalid template iteration for value \`${toString(iterable)}\` in ${vmBeingRendered2}. It must be an array-like object.`);
    }
    const iterator = iterable[SymbolIterator]();
    if (false) {
      assert.isTrue(iterator && isFunction$1(iterator.next), `Invalid iterator function for "${toString(iterable)}" in ${vmBeingRendered2}.`);
    }
    let next = iterator.next();
    let j = 0;
    let { value, done: last } = next;
    let keyMap;
    let iterationError;
    if (false) {
      keyMap = create(null);
    }
    while (last === false) {
      next = iterator.next();
      last = next.done;
      const vnode = factory(value, j, j === 0, last === true);
      if (isArray$1(vnode)) {
        ArrayPush$1.apply(list, vnode);
      } else {
        ArrayPush$1.call(list, vnode);
      }
      if (false) {
        const vnodes = isArray$1(vnode) ? vnode : [vnode];
        forEach.call(vnodes, (childVnode) => {
          if (!isNull(childVnode) && (isVBaseElement(childVnode) || isVStatic(childVnode))) {
            const { key } = childVnode;
            const { tagName } = vmBeingRendered2;
            if (isString(key) || isNumber(key)) {
              if (keyMap[key] === 1 && isUndefined$1(iterationError)) {
                iterationError = `Duplicated "key" attribute value in "<${tagName}>" for item number ${j}. A key with value "${key}" appears more than once in the iteration. Key values must be unique numbers or strings.`;
              }
              keyMap[key] = 1;
            } else if (isUndefined$1(iterationError)) {
              iterationError = `Invalid "key" attribute value in "<${tagName}>" for item number ${j}. Set a unique "key" value on all iterated child elements.`;
            }
          }
        });
      }
      j += 1;
      value = next.value;
    }
    if (false) {
      if (!isUndefined$1(iterationError)) {
        logError(iterationError, vmBeingRendered2);
      }
    }
    return list;
  }
  function f(items) {
    if (false) {
      assert.isTrue(isArray$1(items), "flattening api can only work with arrays.");
    }
    const len = items.length;
    const flattened = [];
    sc(flattened);
    for (let j = 0; j < len; j += 1) {
      const item = items[j];
      if (isArray$1(item)) {
        ArrayPush$1.apply(flattened, item);
      } else {
        ArrayPush$1.call(flattened, item);
      }
    }
    return flattened;
  }
  function t(text) {
    return {
      type: 0,
      sel: "__text__",
      text,
      elm: void 0,
      key: void 0,
      owner: getVMBeingRendered()
    };
  }
  function co(text) {
    return {
      type: 1,
      sel: "__comment__",
      text,
      elm: void 0,
      key: void 0,
      owner: getVMBeingRendered()
    };
  }
  function d(value) {
    return value == null ? "" : String(value);
  }
  function b(fn) {
    const vmBeingRendered2 = getVMBeingRendered();
    if (isNull(vmBeingRendered2)) {
      throw new Error();
    }
    const vm = vmBeingRendered2;
    return function(event) {
      invokeEventListener(vm, fn, vm.component, event);
    };
  }
  function k(compilerKey, obj) {
    switch (typeof obj) {
      case "number":
      case "string":
        return compilerKey + ":" + obj;
      case "object":
        if (false) {
          logError(`Invalid key value "${obj}" in ${getVMBeingRendered()}. Key must be a string or number.`);
        }
    }
  }
  function gid(id) {
    const vmBeingRendered2 = getVMBeingRendered();
    if (isUndefined$1(id) || id === "") {
      return id;
    }
    if (isNull(id)) {
      return null;
    }
    const { idx: idx2, shadowMode } = vmBeingRendered2;
    if (shadowMode === 1) {
      return StringReplace.call(id, /\S+/g, (id2) => `${id2}-${idx2}`);
    }
    return id;
  }
  function fid(url) {
    const vmBeingRendered2 = getVMBeingRendered();
    if (isUndefined$1(url) || url === "") {
      return url;
    }
    if (isNull(url)) {
      return null;
    }
    const { idx: idx2, shadowMode } = vmBeingRendered2;
    if (shadowMode === 1 && /^#/.test(url)) {
      return `${url}-${idx2}`;
    }
    return url;
  }
  function ddc(sel, Ctor, data, children = EmptyArray) {
    if (false) {
      assert.isTrue(isString(sel), `dc() 1st argument sel must be a string.`);
      assert.isTrue(isObject(data), `dc() 3nd argument data must be an object.`);
      assert.isTrue(arguments.length === 3 || isArray$1(children), `dc() 4nd argument data must be an array.`);
    }
    if (isNull(Ctor) || isUndefined$1(Ctor)) {
      return null;
    }
    if (!isComponentConstructor(Ctor)) {
      throw new Error(`Invalid LWC Constructor ${toString(Ctor)} for custom element <${sel}>.`);
    }
    return c(sel, Ctor, data, children);
  }
  function dc(Ctor, data, children = EmptyArray) {
    if (false) {
      assert.isTrue(isObject(data), `dc() 2nd argument data must be an object.`);
      assert.isTrue(arguments.length === 3 || isArray$1(children), `dc() 3rd argument data must be an array.`);
    }
    if (isNull(Ctor) || isUndefined$1(Ctor)) {
      return null;
    }
    if (!isComponentConstructor(Ctor)) {
      throw new Error(`Invalid constructor: "${toString(Ctor)}" is not a LightningElement constructor.`);
    }
    const sel = getComponentRegisteredName(Ctor);
    if (isUndefined$1(sel) || sel === "") {
      throw new Error(`Invalid LWC constructor ${toString(Ctor)} does not have a registered name`);
    }
    return c(sel, Ctor, data, children);
  }
  function sc(vnodes) {
    if (false) {
      assert.isTrue(isArray$1(vnodes), "sc() api can only work with arrays.");
    }
    markAsDynamicChildren(vnodes);
    return vnodes;
  }
  function shc(content) {
    const sanitizedString = sanitizeHtmlContent(content);
    return createSanitizedHtmlContent(sanitizedString);
  }
  var ncls = normalizeClass;
  var api = freeze({
    s,
    h,
    c,
    i,
    f,
    t,
    d,
    b,
    k,
    co,
    dc,
    fr,
    ti,
    st,
    gid,
    fid,
    shc,
    ssf,
    ddc,
    sp,
    ncls
  });
  var operationIdNameMapping = [
    "constructor",
    "render",
    "patch",
    "connectedCallback",
    "renderedCallback",
    "disconnectedCallback",
    "errorCallback",
    "lwc-render",
    "lwc-rerender",
    "lwc-ssr-hydrate"
  ];
  var operationTooltipMapping = [
    // constructor
    "component constructor()",
    // render
    "component render() and virtual DOM rendered",
    // patch
    "component DOM rendered",
    // connectedCallback
    "component connectedCallback()",
    // renderedCallback
    "component renderedCallback()",
    // disconnectedCallback
    "component disconnectedCallback()",
    // errorCallback
    "component errorCallback()",
    // lwc-render
    "component first rendered",
    // lwc-rerender
    "component re-rendered",
    // lwc-ssr-hydrate
    "component hydrated from server-rendered HTML"
  ];
  var isUserTimingSupported = typeof performance !== "undefined" && typeof performance.mark === "function" && typeof performance.clearMarks === "function" && typeof performance.measure === "function" && typeof performance.clearMeasures === "function";
  var start = !isUserTimingSupported ? noop : (markName) => {
    performance.mark(markName);
  };
  var end = !isUserTimingSupported ? noop : (measureName, markName, devtools) => {
    performance.measure(measureName, {
      start: markName,
      detail: {
        devtools: {
          dataType: "track-entry",
          track: "\u26A1\uFE0F Lightning Web Components",
          ...devtools
        }
      }
    });
    performance.clearMarks(markName);
    performance.clearMeasures(measureName);
  };
  function getOperationName(opId) {
    return operationIdNameMapping[opId];
  }
  function getMeasureName(opId, vm) {
    return `${getComponentTag(vm)} - ${getOperationName(opId)}`;
  }
  function getMarkName(opId, vm) {
    return `${getMeasureName(opId, vm)} - ${vm.idx}`;
  }
  function getProperties(vm) {
    return [
      ["Tag Name", vm.tagName],
      ["Component ID", String(vm.idx)],
      ["Render Mode", vm.renderMode === 0 ? "light DOM" : "shadow DOM"],
      ["Shadow Mode", vm.shadowMode === 0 ? "native" : "synthetic"]
    ];
  }
  function getColor(opId) {
    switch (opId) {
      // GlobalSsrHydrate, GlobalRender, and Constructor tend to occur at the top level
      case 7:
      case 9:
      case 0:
        return "primary";
      // GlobalRerender also occurs at the top level, but we want to use tertiary (green) because it's easier to
      // distinguish from primary, and at a glance you should be able to easily tell re-renders from first renders.
      case 8:
        return "tertiary";
      // Everything else (patch/render/callbacks)
      default:
        return "secondary";
    }
  }
  function getMutationProperties(mutationLogs) {
    if (isUndefined$1(mutationLogs)) {
      return EmptyArray;
    }
    if (!mutationLogs.length) {
      return EmptyArray;
    }
    const tagNamesToIdsAndProps = /* @__PURE__ */ new Map();
    for (const { vm: { tagName, idx: idx2 }, prop } of mutationLogs) {
      let idsAndProps = tagNamesToIdsAndProps.get(tagName);
      if (isUndefined$1(idsAndProps)) {
        idsAndProps = { ids: /* @__PURE__ */ new Set(), keys: /* @__PURE__ */ new Set() };
        tagNamesToIdsAndProps.set(tagName, idsAndProps);
      }
      idsAndProps.ids.add(idx2);
      idsAndProps.keys.add(prop);
    }
    const entries2 = ArraySort.call([...tagNamesToIdsAndProps], (a, b2) => a[0].localeCompare(b2[0]));
    const tagNames = ArrayMap.call(entries2, (item) => item[0]);
    const tagNamesToDisplayTagNames = /* @__PURE__ */ new Map();
    for (const tagName of tagNames) {
      const { ids } = tagNamesToIdsAndProps.get(tagName);
      const displayTagName = `<${tagName}>${ids.size > 1 ? ` (\xD7${ids.size})` : ""}`;
      tagNamesToDisplayTagNames.set(tagName, displayTagName);
    }
    const usePlural = tagNames.length > 1 || tagNamesToIdsAndProps.get(tagNames[0]).ids.size > 1;
    const result = [
      [
        `Component${usePlural ? "s" : ""}`,
        ArrayJoin.call(ArrayMap.call(tagNames, (_) => tagNamesToDisplayTagNames.get(_)), ", ")
      ]
    ];
    for (const [prettyTagName, { keys: keys2 }] of entries2) {
      const displayTagName = tagNamesToDisplayTagNames.get(prettyTagName);
      ArrayPush$1.call(result, [displayTagName, ArrayJoin.call(ArraySort.call([...keys2]), ", ")]);
    }
    return result;
  }
  function getTooltipText(measureName, opId) {
    return `${measureName} - ${operationTooltipMapping[opId]}`;
  }
  var isMeasureEnabled = false;
  var isProfilerEnabled = false;
  var currentDispatcher = noop;
  function logOperationStart(opId, vm) {
    if (isMeasureEnabled) {
      const markName = getMarkName(opId, vm);
      start(markName);
    }
    if (isProfilerEnabled) {
      currentDispatcher(opId, 0, vm.tagName, vm.idx, vm.renderMode, vm.shadowMode);
    }
  }
  function logOperationEnd(opId, vm) {
    if (isMeasureEnabled) {
      const markName = getMarkName(opId, vm);
      const measureName = getMeasureName(opId, vm);
      end(measureName, markName, {
        color: getColor(opId),
        tooltipText: getTooltipText(measureName, opId),
        properties: getProperties(vm)
      });
    }
    if (isProfilerEnabled) {
      currentDispatcher(opId, 1, vm.tagName, vm.idx, vm.renderMode, vm.shadowMode);
    }
  }
  function logGlobalOperationStart(opId) {
    if (isMeasureEnabled) {
      const markName = getOperationName(opId);
      start(markName);
    }
    if (isProfilerEnabled) {
      currentDispatcher(
        opId,
        0
        /* Phase.Start */
      );
    }
  }
  function logGlobalOperationStartWithVM(opId, vm) {
    if (isMeasureEnabled) {
      const markName = getMarkName(opId, vm);
      start(markName);
    }
    if (isProfilerEnabled) {
      currentDispatcher(opId, 0, vm.tagName, vm.idx, vm.renderMode, vm.shadowMode);
    }
  }
  function logGlobalOperationEnd(opId, mutationLogs) {
    if (isMeasureEnabled) {
      const opName = getOperationName(opId);
      const markName = opName;
      end(opName, markName, {
        color: getColor(opId),
        tooltipText: getTooltipText(opName, opId),
        properties: getMutationProperties(mutationLogs)
      });
    }
    if (isProfilerEnabled) {
      currentDispatcher(
        opId,
        1
        /* Phase.Stop */
      );
    }
  }
  function logGlobalOperationEndWithVM(opId, vm) {
    if (isMeasureEnabled) {
      const opName = getOperationName(opId);
      const markName = getMarkName(opId, vm);
      end(opName, markName, {
        color: getColor(opId),
        tooltipText: getTooltipText(opName, opId),
        properties: getProperties(vm)
      });
    }
    if (isProfilerEnabled) {
      currentDispatcher(opId, 1, vm.tagName, vm.idx, vm.renderMode, vm.shadowMode);
    }
  }
  var MAX_CACHE_KEY = 3;
  var fragmentCache = ArrayFrom({ length: MAX_CACHE_KEY + 1 }, () => /* @__PURE__ */ new WeakMap());
  if (false) {
    window.__lwcResetFragmentCache = () => {
      for (let i2 = 0; i2 < fragmentCache.length; i2++) {
        fragmentCache[i2] = /* @__PURE__ */ new WeakMap();
      }
    };
  }
  function getFromFragmentCache(cacheKey, strings) {
    return fragmentCache[cacheKey].get(strings);
  }
  function setInFragmentCache(cacheKey, strings, element) {
    fragmentCache[cacheKey].set(strings, element);
  }
  var isUpdatingTemplate = false;
  var vmBeingRendered = null;
  function getVMBeingRendered() {
    return vmBeingRendered;
  }
  function setVMBeingRendered(vm) {
    vmBeingRendered = vm;
  }
  function checkHasMatchingRenderMode(template, vm) {
    if (!isReportingEnabled()) {
      return;
    }
    if (template === defaultEmptyTemplate) {
      return;
    }
    const vmIsLight = vm.renderMode === 0;
    const templateIsLight = template.renderMode === "light";
    if (vmIsLight !== templateIsLight) {
      report("RenderModeMismatch", {
        tagName: vm.tagName,
        mode: vm.renderMode
      });
      if (false) {
        const tagName = getComponentTag(vm);
        const message = vmIsLight ? `Light DOM components can't render shadow DOM templates. Add an 'lwc:render-mode="light"' directive to the root template tag of ${tagName}.` : `Shadow DOM components template can't render light DOM templates. Either remove the 'lwc:render-mode' directive from ${tagName} or set it to 'lwc:render-mode="shadow"`;
        logError(message);
      }
    }
  }
  var browserExpressionSerializer = (partToken, classAttrToken) => {
    const type = StringCharAt.call(partToken, 0);
    switch (type) {
      case "c":
        return classAttrToken;
      case "t":
        return " ";
      default:
        return "";
    }
  };
  function buildSerializeExpressionFn(parts) {
    {
      return browserExpressionSerializer;
    }
  }
  function buildParseFragmentFn(createFragmentFn) {
    return function parseFragment2(strings, ...keys2) {
      return function applyFragmentParts(parts) {
        const { context: { hasScopedStyles, stylesheetToken, legacyStylesheetToken }, shadowMode, renderer: renderer2 } = getVMBeingRendered();
        const hasStyleToken = !isUndefined$1(stylesheetToken);
        const isSyntheticShadow = shadowMode === 1;
        const hasLegacyToken = lwcRuntimeFlags.ENABLE_LEGACY_SCOPE_TOKENS && !isUndefined$1(legacyStylesheetToken);
        let cacheKey = 0;
        if (hasStyleToken && hasScopedStyles) {
          cacheKey |= 1;
        }
        if (hasStyleToken && isSyntheticShadow) {
          cacheKey |= 2;
        }
        {
          const cached = getFromFragmentCache(cacheKey, strings);
          if (!isUndefined$1(cached)) {
            return cached;
          }
        }
        if (hasStyleToken && !isValidScopeToken(stylesheetToken) || hasLegacyToken && !isValidScopeToken(legacyStylesheetToken)) {
          throw new Error("stylesheet token must be a valid string");
        }
        const stylesheetTokenToRender = stylesheetToken + (hasLegacyToken ? ` ${legacyStylesheetToken}` : "");
        const classToken = hasScopedStyles && hasStyleToken ? " " + stylesheetTokenToRender : "";
        const classAttrToken = hasScopedStyles && hasStyleToken ? ` class="${stylesheetTokenToRender}"` : "";
        const attrToken = hasStyleToken && isSyntheticShadow ? " " + stylesheetTokenToRender : "";
        const exprClassToken = classAttrToken;
        const serializeExpression = buildSerializeExpressionFn();
        let htmlFragment = "";
        for (let i2 = 0, n = keys2.length; i2 < n; i2++) {
          switch (keys2[i2]) {
            case 0:
              htmlFragment += strings[i2] + classToken;
              break;
            case 1:
              htmlFragment += strings[i2] + classAttrToken;
              break;
            case 2:
              htmlFragment += strings[i2] + attrToken;
              break;
            case 3:
              htmlFragment += strings[i2] + classAttrToken + attrToken;
              break;
            default:
              htmlFragment += strings[i2] + serializeExpression(keys2[i2], exprClassToken);
              break;
          }
        }
        htmlFragment += strings[strings.length - 1];
        const element = createFragmentFn(htmlFragment, renderer2);
        {
          setInFragmentCache(cacheKey, strings, element);
        }
        return element;
      };
    };
  }
  var parseFragment = buildParseFragmentFn((html, renderer2) => {
    const { createFragment } = renderer2;
    return createFragment(html);
  });
  var parseSVGFragment = buildParseFragmentFn((html, renderer2) => {
    const { createFragment, getFirstChild } = renderer2;
    const fragment = createFragment("<svg>" + html + "</svg>");
    return getFirstChild(fragment);
  });
  function evaluateTemplate(vm, html) {
    if (false) {
      html = getTemplateOrSwappedTemplate(html);
    }
    const isUpdatingTemplateInception = isUpdatingTemplate;
    const vmOfTemplateBeingUpdatedInception = vmBeingRendered;
    let vnodes = [];
    runWithBoundaryProtection(vm, vm.owner, () => {
      vmBeingRendered = vm;
      logOperationStart(1, vm);
    }, () => {
      const { component, context, cmpSlots, cmpTemplate, tro } = vm;
      tro.observe(() => {
        if (html !== cmpTemplate) {
          if (!isTemplateRegistered(html)) {
            throw new TypeError(`Invalid template returned by the render() method on ${vm.tagName}. It must return an imported template (e.g.: \`import html from "./${vm.def.name}.html"\`), instead, it has returned: ${toString(html)}.`);
          }
          checkHasMatchingRenderMode(html, vm);
          if (!isNull(cmpTemplate)) {
            resetComponentRoot(vm);
          }
          vm.cmpTemplate = html;
          context.tplCache = create(null);
          context.hasScopedStyles = computeHasScopedStyles(html, vm);
          updateStylesheetToken(
            vm,
            html,
            /* legacy */
            false
          );
          if (lwcRuntimeFlags.ENABLE_LEGACY_SCOPE_TOKENS) {
            updateStylesheetToken(
              vm,
              html,
              /* legacy */
              true
            );
          }
          const stylesheetsContent = getStylesheetsContent(vm, html);
          context.styleVNodes = stylesheetsContent.length === 0 ? null : createStylesheet(vm, stylesheetsContent);
        }
        if (false) {
          validateSlots(vm);
          setActiveVM(vm);
        }
        vm.velements = [];
        isUpdatingTemplate = true;
        vnodes = html.call(void 0, api, component, cmpSlots, context.tplCache);
        const { styleVNodes } = context;
        if (!isNull(styleVNodes)) {
          vnodes = [...styleVNodes, ...vnodes];
        }
      });
    }, () => {
      isUpdatingTemplate = isUpdatingTemplateInception;
      vmBeingRendered = vmOfTemplateBeingUpdatedInception;
      logOperationEnd(1, vm);
    });
    if (false) {
      if (!isArray$1(vnodes)) {
        logError(`Compiler should produce html functions that always return an array.`);
      }
    }
    return vnodes;
  }
  function computeHasScopedStylesInStylesheets(stylesheets) {
    if (hasStyles(stylesheets)) {
      for (let i2 = 0; i2 < stylesheets.length; i2++) {
        if (isTrue(stylesheets[i2][KEY__SCOPED_CSS])) {
          return true;
        }
      }
    }
    return false;
  }
  function computeHasScopedStyles(template, vm) {
    const { stylesheets } = template;
    const vmStylesheets = !isUndefined$1(vm) ? vm.stylesheets : null;
    return computeHasScopedStylesInStylesheets(stylesheets) || computeHasScopedStylesInStylesheets(vmStylesheets);
  }
  function hasStyles(stylesheets) {
    return !isUndefined$1(stylesheets) && !isNull(stylesheets) && stylesheets.length > 0;
  }
  var isInvokingRender = false;
  var vmBeingConstructed = null;
  function isBeingConstructed(vm) {
    return vmBeingConstructed === vm;
  }
  function invokeComponentCallback(vm, fn, args) {
    const { component, callHook: callHook2, owner } = vm;
    runWithBoundaryProtection(vm, owner, noop, () => {
      callHook2(component, fn, args);
    }, noop);
  }
  function invokeComponentConstructor(vm, Ctor) {
    const vmBeingConstructedInception = vmBeingConstructed;
    let error;
    logOperationStart(0, vm);
    vmBeingConstructed = vm;
    try {
      const result = new Ctor();
      const useStrictValidation = !lwcRuntimeFlags.DISABLE_STRICT_VALIDATION && true;
      const isMismatchedConstructor = vmBeingConstructed.component !== result;
      const isInvalidConstructor = isMismatchedConstructor || useStrictValidation && result instanceof HTMLElement;
      if (isInvalidConstructor) {
        throw new TypeError("Invalid component constructor, the class should extend LightningElement.");
      }
    } catch (e) {
      error = Object(e);
    } finally {
      logOperationEnd(0, vm);
      vmBeingConstructed = vmBeingConstructedInception;
      if (!isUndefined$1(error)) {
        addErrorComponentStack(vm, error);
        throw error;
      }
    }
  }
  function invokeComponentRenderMethod(vm) {
    const { def: { render }, callHook: callHook2, component, owner } = vm;
    const isRenderBeingInvokedInception = isInvokingRender;
    const vmBeingRenderedInception = getVMBeingRendered();
    let html;
    let renderInvocationSuccessful = false;
    runWithBoundaryProtection(vm, owner, () => {
      isInvokingRender = true;
      setVMBeingRendered(vm);
    }, () => {
      vm.tro.observe(() => {
        html = callHook2(component, render);
        renderInvocationSuccessful = true;
      });
    }, () => {
      isInvokingRender = isRenderBeingInvokedInception;
      setVMBeingRendered(vmBeingRenderedInception);
    });
    return renderInvocationSuccessful ? evaluateTemplate(vm, html) : [];
  }
  function invokeEventListener(vm, fn, thisValue, event) {
    const { callHook: callHook2, owner } = vm;
    runWithBoundaryProtection(vm, owner, noop, () => {
      if (false) {
        assert.isTrue(isFunction$1(fn), `Invalid event handler for event '${event.type}' on ${vm}.`);
      }
      callHook2(thisValue, fn, [event]);
    }, noop);
  }
  var registeredComponentMap = /* @__PURE__ */ new Map();
  function registerComponent(Ctor, metadata) {
    if (isFunction$1(Ctor)) {
      if (false) {
        checkVersionMismatch(Ctor, "component");
      }
      registeredComponentMap.set(Ctor, metadata);
    }
    return Ctor;
  }
  function getComponentRegisteredTemplate(Ctor) {
    return registeredComponentMap.get(Ctor)?.tmpl;
  }
  function getComponentRegisteredName(Ctor) {
    return registeredComponentMap.get(Ctor)?.sel;
  }
  function getComponentAPIVersion(Ctor) {
    const metadata = registeredComponentMap.get(Ctor);
    const apiVersion = metadata?.apiVersion;
    if (isUndefined$1(apiVersion)) {
      return LOWEST_API_VERSION;
    }
    return apiVersion;
  }
  function supportsSyntheticElementInternals(Ctor) {
    return registeredComponentMap.get(Ctor)?.enableSyntheticElementInternals || false;
  }
  function isComponentFeatureEnabled(Ctor) {
    const flag = registeredComponentMap.get(Ctor)?.componentFeatureFlag;
    return flag?.value !== false;
  }
  function getComponentMetadata(Ctor) {
    return registeredComponentMap.get(Ctor);
  }
  function getTemplateReactiveObserver(vm) {
    const reactiveObserver = createReactiveObserver(() => {
      const { isDirty } = vm;
      if (isFalse(isDirty)) {
        markComponentAsDirty(vm);
        scheduleRehydration(vm);
      }
    });
    if (false) {
      associateReactiveObserverWithVM(reactiveObserver, vm);
    }
    return reactiveObserver;
  }
  function resetTemplateObserverAndUnsubscribe(vm) {
    const { tro, component } = vm;
    tro.reset();
    if (lwcRuntimeFlags.ENABLE_EXPERIMENTAL_SIGNALS) {
      unsubscribeFromSignals(component);
    }
  }
  function renderComponent(vm) {
    if (false) {
      assert.invariant(vm.isDirty, `${vm} is not dirty.`);
    }
    resetTemplateObserverAndUnsubscribe(vm);
    const vnodes = invokeComponentRenderMethod(vm);
    vm.isDirty = false;
    vm.isScheduled = false;
    return vnodes;
  }
  function markComponentAsDirty(vm) {
    if (false) {
      const vmBeingRendered2 = getVMBeingRendered();
      assert.isFalse(vm.isDirty, `markComponentAsDirty() for ${vm} should not be called when the component is already dirty.`);
      assert.isFalse(isInvokingRender, `markComponentAsDirty() for ${vm} cannot be called during rendering of ${vmBeingRendered2}.`);
      assert.isFalse(isUpdatingTemplate, `markComponentAsDirty() for ${vm} cannot be called while updating template of ${vmBeingRendered2}.`);
    }
    vm.isDirty = true;
  }
  var cmpEventListenerMap = /* @__PURE__ */ new WeakMap();
  function getWrappedComponentsListener(vm, listener) {
    if (!isFunction$1(listener)) {
      throw new TypeError("Expected an EventListener but received " + typeof listener);
    }
    let wrappedListener = cmpEventListenerMap.get(listener);
    if (isUndefined$1(wrappedListener)) {
      wrappedListener = function(event) {
        invokeEventListener(vm, listener, void 0, event);
      };
      cmpEventListenerMap.set(listener, wrappedListener);
    }
    return wrappedListener;
  }
  function __classPrivateFieldGet(receiver, state, kind, f2) {
    if (typeof state === "function" ? receiver !== state || !f2 : !state.has(receiver)) throw new TypeError("Cannot read private member from an object whose class did not declare it");
    return kind === "m" ? f2 : kind === "a" ? f2.call(receiver) : f2 ? f2.value : state.get(receiver);
  }
  function __classPrivateFieldSet(receiver, state, value, kind, f2) {
    if (typeof state === "function" ? receiver !== state || true : !state.has(receiver)) throw new TypeError("Cannot write private member to an object whose class did not declare it");
    return state.set(receiver, value), value;
  }
  var _ContextBinding_renderer;
  var _ContextBinding_providedContextVarieties;
  var _ContextBinding_elm;
  var ContextBinding = class {
    constructor(vm, component, providedContextVarieties) {
      _ContextBinding_renderer.set(this, void 0);
      _ContextBinding_providedContextVarieties.set(this, void 0);
      _ContextBinding_elm.set(this, void 0);
      this.component = component;
      __classPrivateFieldSet(this, _ContextBinding_renderer, vm.renderer);
      __classPrivateFieldSet(this, _ContextBinding_elm, vm.elm);
      __classPrivateFieldSet(this, _ContextBinding_providedContextVarieties, providedContextVarieties);
      __classPrivateFieldGet(this, _ContextBinding_renderer, "f").registerContextProvider(__classPrivateFieldGet(this, _ContextBinding_elm, "f"), ContextEventName, (contextConsumer) => {
        return contextConsumer.setNewContext(__classPrivateFieldGet(this, _ContextBinding_providedContextVarieties, "f"));
      });
    }
    provideContext(contextVariety, providedContextSignal) {
      if (__classPrivateFieldGet(this, _ContextBinding_providedContextVarieties, "f").has(contextVariety)) {
        logWarnOnce("Multiple contexts of the same variety were provided. Only the first context will be used.");
        return;
      }
      __classPrivateFieldGet(this, _ContextBinding_providedContextVarieties, "f").set(contextVariety, providedContextSignal);
    }
    consumeContext(contextVariety, contextProvidedCallback) {
      __classPrivateFieldGet(this, _ContextBinding_renderer, "f").registerContextConsumer(__classPrivateFieldGet(this, _ContextBinding_elm, "f"), ContextEventName, {
        setNewContext: (providerContextVarieties) => {
          if (providerContextVarieties.has(contextVariety)) {
            contextProvidedCallback(providerContextVarieties.get(contextVariety));
            return true;
          }
          return false;
        }
      });
    }
  };
  _ContextBinding_renderer = /* @__PURE__ */ new WeakMap(), _ContextBinding_providedContextVarieties = /* @__PURE__ */ new WeakMap(), _ContextBinding_elm = /* @__PURE__ */ new WeakMap();
  function connectContext(vm) {
    if (lwcRuntimeFlags.ENABLE_LEGACY_CONTEXT_CONNECTION) {
      connect(vm, keys(getPrototypeOf$1(vm.component)), vm.component);
    } else {
      connect(vm, keys(vm.cmpFields), vm.cmpFields);
      connect(vm, keys(vm.cmpProps), vm.cmpProps);
    }
  }
  function disconnectContext(vm) {
    if (lwcRuntimeFlags.ENABLE_LEGACY_CONTEXT_CONNECTION) {
      connect(vm, keys(getPrototypeOf$1(vm.component)), vm.component);
    } else {
      disconnect(vm, keys(vm.cmpFields), vm.cmpFields);
      disconnect(vm, keys(vm.cmpProps), vm.cmpProps);
    }
  }
  function connect(vm, enumerableKeys, contextContainer) {
    const contextKeys2 = getContextKeys();
    if (isUndefined$1(contextKeys2)) {
      return;
    }
    const { connectContext: connectContext2 } = contextKeys2;
    const { component } = vm;
    const contextfulKeys = ArrayFilter.call(enumerableKeys, (enumerableKey) => isTrustedContext(contextContainer[enumerableKey]));
    if (contextfulKeys.length === 0) {
      return;
    }
    const providedContextVarieties = /* @__PURE__ */ new Map();
    try {
      for (let i2 = 0; i2 < contextfulKeys.length; i2++) {
        contextContainer[contextfulKeys[i2]][connectContext2](new ContextBinding(vm, component, providedContextVarieties));
      }
    } catch (err) {
      logWarnOnce(`Attempted to connect to trusted context but received the following error: ${err.message}`);
    }
  }
  function disconnect(vm, enumerableKeys, contextContainer) {
    const contextKeys2 = getContextKeys();
    if (!contextKeys2) {
      return;
    }
    const { disconnectContext: disconnectContext2 } = contextKeys2;
    const { component } = vm;
    const contextfulKeys = ArrayFilter.call(enumerableKeys, (enumerableKey) => isTrustedContext(contextContainer[enumerableKey]));
    if (contextfulKeys.length === 0) {
      return;
    }
    try {
      for (let i2 = 0; i2 < contextfulKeys.length; i2++) {
        contextContainer[contextfulKeys[i2]][disconnectContext2](component);
      }
    } catch (err) {
      logWarnOnce(`Attempted to disconnect from trusted context but received the following error: ${err.message}`);
    }
  }
  var idx = 0;
  var ViewModelReflection = /* @__PURE__ */ new WeakMap();
  function callHook(cmp, fn, args = []) {
    return fn.apply(cmp, args);
  }
  function setHook(cmp, prop, newValue) {
    cmp[prop] = newValue;
  }
  function getHook(cmp, prop) {
    return cmp[prop];
  }
  function rerenderVM(vm) {
    rehydrate(vm);
  }
  function connectRootElement(elm) {
    const vm = getAssociatedVM(elm);
    if (false) {
      flushMutationLogsForVM(vm);
    }
    logGlobalOperationStartWithVM(7, vm);
    if (vm.state === 1) {
      disconnectRootElement(elm);
    }
    runConnectedCallback(vm);
    rehydrate(vm);
    logGlobalOperationEndWithVM(7, vm);
  }
  function disconnectRootElement(elm) {
    const vm = getAssociatedVM(elm);
    resetComponentStateWhenRemoved(vm);
  }
  function appendVM(vm) {
    rehydrate(vm);
  }
  function resetComponentStateWhenRemoved(vm) {
    const { state } = vm;
    if (state !== 2) {
      resetTemplateObserverAndUnsubscribe(vm);
      runDisconnectedCallback(vm);
      runChildNodesDisconnectedCallback(vm);
      runLightChildNodesDisconnectedCallback(vm);
    }
  }
  function removeVM(vm) {
    if (false) {
      if (lwcRuntimeFlags.DISABLE_NATIVE_CUSTOM_ELEMENT_LIFECYCLE) {
        assert.isTrue(vm.state === 1 || vm.state === 2, `${vm} must have been connected.`);
      }
    }
    resetComponentStateWhenRemoved(vm);
  }
  function getNearestShadowAncestor(owner) {
    let ancestor = owner;
    while (!isNull(ancestor) && ancestor.renderMode === 0) {
      ancestor = ancestor.owner;
    }
    return ancestor;
  }
  function createVM(elm, ctor, renderer2, options) {
    const { mode, owner, tagName, hydrated } = options;
    const def = getComponentInternalDef(ctor);
    const apiVersion = getComponentAPIVersion(ctor);
    const vm = {
      elm,
      def,
      idx: idx++,
      state: 0,
      isScheduled: false,
      isDirty: true,
      tagName,
      mode,
      owner,
      refVNodes: null,
      attachedEventListeners: /* @__PURE__ */ new WeakMap(),
      children: EmptyArray,
      aChildren: EmptyArray,
      velements: EmptyArray,
      cmpProps: create(null),
      cmpFields: create(null),
      cmpSlots: { slotAssignments: create(null) },
      cmpTemplate: null,
      hydrated: Boolean(hydrated),
      renderMode: def.renderMode,
      context: {
        stylesheetToken: void 0,
        hasTokenInClass: void 0,
        hasTokenInAttribute: void 0,
        legacyStylesheetToken: void 0,
        hasLegacyTokenInClass: void 0,
        hasLegacyTokenInAttribute: void 0,
        hasScopedStyles: void 0,
        styleVNodes: null,
        tplCache: EmptyObject,
        wiredConnecting: EmptyArray,
        wiredDisconnecting: EmptyArray
      },
      // Properties set right after VM creation.
      tro: null,
      shadowMode: null,
      shadowMigrateMode: false,
      stylesheets: null,
      // Properties set by the LightningElement constructor.
      component: null,
      shadowRoot: null,
      renderRoot: null,
      callHook,
      setHook,
      getHook,
      renderer: renderer2,
      apiVersion
    };
    if (false) {
      vm.debugInfo = create(null);
    }
    vm.stylesheets = computeStylesheets(vm, def.ctor);
    const computedShadowMode = computeShadowMode(def, vm.owner, renderer2, hydrated);
    if (lwcRuntimeFlags.ENABLE_FORCE_SHADOW_MIGRATE_MODE) {
      vm.shadowMode = 0;
      vm.shadowMigrateMode = computedShadowMode === 1;
    } else {
      vm.shadowMode = computedShadowMode;
    }
    vm.tro = getTemplateReactiveObserver(vm);
    if (isReportingEnabled() && vm.renderMode === 1) {
      report("ShadowModeUsage", {
        tagName: vm.tagName,
        mode: vm.shadowMode
      });
    }
    if (false) {
      vm.toString = () => {
        return `[object:vm ${def.name} (${vm.idx})]`;
      };
    }
    invokeComponentConstructor(vm, def.ctor);
    if (hasWireAdapters(vm)) {
      installWireAdapters(vm);
    }
    return vm;
  }
  function validateComponentStylesheets(vm, stylesheets) {
    let valid = true;
    const validate = (arrayOrStylesheet) => {
      if (isArray$1(arrayOrStylesheet)) {
        for (let i2 = 0; i2 < arrayOrStylesheet.length; i2++) {
          validate(arrayOrStylesheet[i2]);
        }
      } else if (!isFunction$1(arrayOrStylesheet)) {
        valid = false;
      }
    };
    if (!isArray$1(stylesheets)) {
      valid = false;
    } else {
      validate(stylesheets);
    }
    return valid;
  }
  function computeStylesheets(vm, ctor) {
    warnOnStylesheetsMutation(ctor);
    const { stylesheets } = ctor;
    if (!isUndefined$1(stylesheets)) {
      const valid = validateComponentStylesheets(vm, stylesheets);
      if (valid) {
        return flattenStylesheets(stylesheets);
      } else if (false) {
        logError(`static stylesheets must be an array of CSS stylesheets. Found invalid stylesheets on <${vm.tagName}>`, vm);
      }
    }
    return null;
  }
  function warnOnStylesheetsMutation(ctor) {
    if (false) {
      let { stylesheets } = ctor;
      defineProperty(ctor, "stylesheets", {
        enumerable: true,
        configurable: true,
        get() {
          return stylesheets;
        },
        set(newValue) {
          logWarnOnce(`Dynamically setting the "stylesheets" static property on ${ctor.name} will not affect the stylesheets injected.`);
          stylesheets = newValue;
        }
      });
    }
  }
  function computeShadowAndRenderMode(Ctor, renderer2) {
    const def = getComponentInternalDef(Ctor);
    const { renderMode } = def;
    const shadowMode = computeShadowMode(
      def,
      /* owner */
      null,
      renderer2,
      false
    );
    return { renderMode, shadowMode };
  }
  function computeShadowMode(def, owner, renderer2, hydrated) {
    if (
      // Force the shadow mode to always be native. Used for running tests with synthetic shadow patches
      // on, but components running in actual native shadow mode
      // If synthetic shadow is explicitly disabled, use pure-native
      lwcRuntimeFlags.DISABLE_SYNTHETIC_SHADOW || // hydration only supports native shadow
      isTrue(hydrated)
    ) {
      return 0;
    }
    const { isSyntheticShadowDefined } = renderer2;
    let shadowMode;
    if (isSyntheticShadowDefined || lwcRuntimeFlags.ENABLE_FORCE_SHADOW_MIGRATE_MODE) {
      if (def.renderMode === 0) {
        shadowMode = 0;
      } else if (def.shadowSupportMode === "native") {
        shadowMode = 0;
      } else {
        const shadowAncestor = getNearestShadowAncestor(owner);
        if (!isNull(shadowAncestor) && shadowAncestor.shadowMode === 0) {
          shadowMode = 0;
        } else {
          shadowMode = 1;
        }
      }
    } else {
      shadowMode = 0;
    }
    return shadowMode;
  }
  function associateVM(obj, vm) {
    ViewModelReflection.set(obj, vm);
  }
  function getAssociatedVM(obj) {
    const vm = ViewModelReflection.get(obj);
    if (false) {
      assertIsVM(vm);
    }
    return vm;
  }
  function getAssociatedVMIfPresent(obj) {
    const maybeVm = ViewModelReflection.get(obj);
    if (false) {
      if (!isUndefined$1(maybeVm)) {
        assertIsVM(maybeVm);
      }
    }
    return maybeVm;
  }
  function rehydrate(vm) {
    if (isTrue(vm.isDirty)) {
      const children = renderComponent(vm);
      patchShadowRoot(vm, children);
    }
  }
  function patchShadowRoot(vm, newCh) {
    const { renderRoot, children: oldCh, renderer: renderer2 } = vm;
    resetRefVNodes(vm);
    vm.children = newCh;
    if (newCh.length > 0 || oldCh.length > 0) {
      if (oldCh !== newCh) {
        runWithBoundaryProtection(vm, vm, () => {
          logOperationStart(2, vm);
        }, () => {
          patchChildren(oldCh, newCh, renderRoot, renderer2);
        }, () => {
          logOperationEnd(2, vm);
        });
      }
    }
    if (vm.state === 1) {
      runRenderedCallback(vm);
    }
  }
  function runRenderedCallback(vm) {
    const { def: { renderedCallback } } = vm;
    if (!isUndefined$1(renderedCallback)) {
      logOperationStart(4, vm);
      invokeComponentCallback(vm, renderedCallback);
      logOperationEnd(4, vm);
    }
  }
  var rehydrateQueue = [];
  function flushRehydrationQueue() {
    const mutationLogs = true ? void 0 : getAndFlushMutationLogs();
    logGlobalOperationStart(
      8
      /* OperationId.GlobalRerender */
    );
    if (false) {
      assert.invariant(rehydrateQueue.length, `If rehydrateQueue was scheduled, it is because there must be at least one VM on this pending queue instead of ${rehydrateQueue}.`);
    }
    const vms = rehydrateQueue.sort((a, b2) => a.idx - b2.idx);
    rehydrateQueue = [];
    for (let i2 = 0, len = vms.length; i2 < len; i2 += 1) {
      const vm = vms[i2];
      try {
        if (!lwcRuntimeFlags.DISABLE_DETACHED_REHYDRATION || vm.state === 1) {
          rehydrate(vm);
        }
      } catch (error) {
        if (i2 + 1 < len) {
          if (rehydrateQueue.length === 0) {
            addCallbackToNextTick(flushRehydrationQueue);
          }
          ArrayUnshift.apply(rehydrateQueue, ArraySlice.call(vms, i2 + 1));
        }
        logGlobalOperationEnd(8, mutationLogs);
        throw error;
      }
    }
    logGlobalOperationEnd(8, mutationLogs);
  }
  function runConnectedCallback(vm) {
    const { state } = vm;
    if (state === 1) {
      return;
    }
    vm.state = 1;
    if (hasWireAdapters(vm)) {
      connectWireAdapters(vm);
    }
    if (lwcRuntimeFlags.ENABLE_EXPERIMENTAL_SIGNALS) {
      connectContext(vm);
    }
    const { connectedCallback } = vm.def;
    if (!isUndefined$1(connectedCallback)) {
      logOperationStart(3, vm);
      invokeComponentCallback(vm, connectedCallback);
      logOperationEnd(3, vm);
    }
    if (lwcRuntimeFlags.DISABLE_NATIVE_CUSTOM_ELEMENT_LIFECYCLE && isReportingEnabled()) {
      if (!vm.renderer.isConnected(vm.elm)) {
        if (false) {
          logWarnOnce(`Element <${vm.tagName}> fired a \`connectedCallback\` and rendered, but was not connected to the DOM. Please ensure all components are actually connected to the DOM, e.g. using \`document.body.appendChild(element)\`. This will not be supported in future versions of LWC and could cause component errors. For details, see: https://sfdc.co/synthetic-lifecycle`);
        }
        report("ConnectedCallbackWhileDisconnected", {
          tagName: vm.tagName
        });
      }
    }
  }
  function hasWireAdapters(vm) {
    return getOwnPropertyNames$1(vm.def.wire).length > 0;
  }
  function runDisconnectedCallback(vm) {
    if (false) {
      assert.isTrue(vm.state !== 2, `${vm} must be inserted.`);
    }
    if (lwcRuntimeFlags.ENABLE_EXPERIMENTAL_SIGNALS) {
      disconnectContext(vm);
    }
    if (isFalse(vm.isDirty)) {
      vm.isDirty = true;
    }
    vm.state = 2;
    if (hasWireAdapters(vm)) {
      disconnectWireAdapters(vm);
    }
    const { disconnectedCallback } = vm.def;
    if (!isUndefined$1(disconnectedCallback)) {
      logOperationStart(5, vm);
      invokeComponentCallback(vm, disconnectedCallback);
      logOperationEnd(5, vm);
    }
  }
  function runChildNodesDisconnectedCallback(vm) {
    const { velements: vCustomElementCollection } = vm;
    for (let i2 = vCustomElementCollection.length - 1; i2 >= 0; i2 -= 1) {
      const { elm } = vCustomElementCollection[i2];
      if (!isUndefined$1(elm)) {
        const childVM = getAssociatedVMIfPresent(elm);
        if (!isUndefined$1(childVM)) {
          resetComponentStateWhenRemoved(childVM);
        }
      }
    }
  }
  function runLightChildNodesDisconnectedCallback(vm) {
    const { aChildren: adoptedChildren } = vm;
    recursivelyDisconnectChildren(adoptedChildren);
  }
  function recursivelyDisconnectChildren(vnodes) {
    for (let i2 = 0, len = vnodes.length; i2 < len; i2 += 1) {
      const vnode = vnodes[i2];
      if (!isNull(vnode) && !isUndefined$1(vnode.elm)) {
        switch (vnode.type) {
          case 2:
            recursivelyDisconnectChildren(vnode.children);
            break;
          case 3: {
            const vm = getAssociatedVM(vnode.elm);
            resetComponentStateWhenRemoved(vm);
            break;
          }
        }
      }
    }
  }
  function resetComponentRoot(vm) {
    recursivelyRemoveChildren(vm.children, vm);
    vm.children = EmptyArray;
    runChildNodesDisconnectedCallback(vm);
    vm.velements = EmptyArray;
  }
  function recursivelyRemoveChildren(vnodes, vm) {
    const { renderRoot, renderer: { remove } } = vm;
    for (let i2 = 0, len = vnodes.length; i2 < len; i2 += 1) {
      const vnode = vnodes[i2];
      if (!isNull(vnode)) {
        if (isVFragment(vnode)) {
          recursivelyRemoveChildren(vnode.children, vm);
        } else if (!isUndefined$1(vnode.elm)) {
          remove(vnode.elm, renderRoot);
        }
      }
    }
  }
  function scheduleRehydration(vm) {
    if (isTrue(vm.isScheduled)) {
      return;
    }
    vm.isScheduled = true;
    if (rehydrateQueue.length === 0) {
      addCallbackToNextTick(flushRehydrationQueue);
    }
    ArrayPush$1.call(rehydrateQueue, vm);
  }
  function getErrorBoundaryVM(vm) {
    let currentVm = vm;
    while (!isNull(currentVm)) {
      if (!isUndefined$1(currentVm.def.errorCallback)) {
        return currentVm;
      }
      currentVm = currentVm.owner;
    }
  }
  function runWithBoundaryProtection(vm, owner, pre, job, post) {
    let error;
    pre();
    try {
      job();
    } catch (e) {
      error = Object(e);
    } finally {
      post();
      if (!isUndefined$1(error)) {
        addErrorComponentStack(vm, error);
        const errorBoundaryVm = isNull(owner) ? void 0 : getErrorBoundaryVM(owner);
        if (isUndefined$1(errorBoundaryVm)) {
          throw error;
        }
        resetComponentRoot(vm);
        logOperationStart(6, vm);
        const errorCallback = errorBoundaryVm.def.errorCallback;
        invokeComponentCallback(errorBoundaryVm, errorCallback, [error, error.wcStack]);
        logOperationEnd(6, vm);
      }
    }
  }
  function runFormAssociatedCustomElementCallback(vm, faceCb, args) {
    const { renderMode, shadowMode, def: { ctor } } = vm;
    if (shadowMode === 1 && renderMode !== 0 && !supportsSyntheticElementInternals(ctor)) {
      throw new Error("Form associated lifecycle methods are not available in synthetic shadow. Please use native shadow or light DOM.");
    }
    invokeComponentCallback(vm, faceCb, args);
  }
  function runFormAssociatedCallback(elm, form) {
    const vm = getAssociatedVM(elm);
    const { formAssociatedCallback } = vm.def;
    if (!isUndefined$1(formAssociatedCallback)) {
      runFormAssociatedCustomElementCallback(vm, formAssociatedCallback, [form]);
    }
  }
  function runFormDisabledCallback(elm, disabled) {
    const vm = getAssociatedVM(elm);
    const { formDisabledCallback } = vm.def;
    if (!isUndefined$1(formDisabledCallback)) {
      runFormAssociatedCustomElementCallback(vm, formDisabledCallback, [disabled]);
    }
  }
  function runFormResetCallback(elm) {
    const vm = getAssociatedVM(elm);
    const { formResetCallback } = vm.def;
    if (!isUndefined$1(formResetCallback)) {
      runFormAssociatedCustomElementCallback(vm, formResetCallback);
    }
  }
  function runFormStateRestoreCallback(elm, state, reason) {
    const vm = getAssociatedVM(elm);
    const { formStateRestoreCallback } = vm.def;
    if (!isUndefined$1(formStateRestoreCallback)) {
      runFormAssociatedCustomElementCallback(vm, formStateRestoreCallback, [state, reason]);
    }
  }
  function resetRefVNodes(vm) {
    const { cmpTemplate } = vm;
    vm.refVNodes = !isNull(cmpTemplate) && cmpTemplate.hasRefs ? create(null) : null;
  }
  var getElementById = globalThis[KEY__NATIVE_GET_ELEMENT_BY_ID];
  var querySelectorAll = globalThis[KEY__NATIVE_QUERY_SELECTOR_ALL];
  delete globalThis[KEY__NATIVE_GET_ELEMENT_BY_ID];
  delete globalThis[KEY__NATIVE_QUERY_SELECTOR_ALL];
  function isSyntheticShadowRootInstance(rootNode) {
    return rootNode !== document && isTrue(rootNode.synthetic);
  }
  function reportViolation$1(source, target, attrName) {
    let vm = getAssociatedVMIfPresent(source.getRootNode().host);
    if (isUndefined$1(vm)) {
      vm = getAssociatedVMIfPresent(target.getRootNode().host);
    }
    if (isUndefined$1(vm)) {
      return;
    }
    report("CrossRootAriaInSyntheticShadow", {
      tagName: vm.tagName,
      attributeName: attrName
    });
    if (false) {
      logWarnOnce(`Element <${source.tagName.toLowerCase()}> uses attribute "${attrName}" to reference element <${target.tagName.toLowerCase()}>, which is not in the same shadow root. This will break in native shadow DOM. For details, see: https://sfdc.co/synthetic-aria`, vm);
    }
  }
  function parseIdRefAttributeValue(attrValue) {
    return isString(attrValue) ? ArrayFilter.call(StringSplit.call(attrValue, /\s+/), Boolean) : [];
  }
  function detectSyntheticCrossRootAria(elm, attrName, attrValue) {
    const root = elm.getRootNode();
    if (!isSyntheticShadowRootInstance(root)) {
      return;
    }
    if (attrName === "id") {
      if (!isString(attrValue) || attrValue.length === 0) {
        return;
      }
      for (const idRefAttrName of ID_REFERENCING_ATTRIBUTES_SET) {
        const query = `[${idRefAttrName}~="${CSS.escape(attrValue)}"]`;
        const sourceElements = querySelectorAll.call(document, query);
        for (let i2 = 0; i2 < sourceElements.length; i2++) {
          const sourceElement = sourceElements[i2];
          const sourceRoot = sourceElement.getRootNode();
          if (sourceRoot !== root) {
            reportViolation$1(sourceElement, elm, idRefAttrName);
            break;
          }
        }
      }
    } else {
      const ids = parseIdRefAttributeValue(attrValue);
      for (const id of ids) {
        const target = getElementById.call(document, id);
        if (!isNull(target)) {
          const targetRoot = target.getRootNode();
          if (targetRoot !== root) {
            reportViolation$1(elm, target, attrName);
          }
        }
      }
    }
  }
  var enabled = false;
  function enableDetection$1() {
    if (enabled) {
      return;
    }
    enabled = true;
    const { setAttribute } = Element.prototype;
    assign(Element.prototype, {
      setAttribute(attrName, attrValue) {
        setAttribute.call(this, attrName, attrValue);
        if (attrName === "id" || ID_REFERENCING_ATTRIBUTES_SET.has(attrName)) {
          detectSyntheticCrossRootAria(this, attrName, attrValue);
        }
      }
    });
    const idDescriptor = getOwnPropertyDescriptor$1(Element.prototype, "id");
    if (!isUndefined$1(idDescriptor)) {
      const { get, set } = idDescriptor;
      if (isFunction$1(get) && isFunction$1(set)) {
        defineProperty(Element.prototype, "id", {
          get() {
            return get.call(this);
          },
          set(value) {
            set.call(this, value);
            detectSyntheticCrossRootAria(this, "id", value);
          },
          // On the default descriptor for 'id', enumerable and configurable are true
          enumerable: true,
          configurable: true
        });
      }
    }
  }
  function supportsCssEscape() {
    return typeof CSS !== "undefined" && isFunction$1(CSS.escape);
  }
  function isSyntheticShadowLoaded() {
    return hasOwnProperty$1.call(Element.prototype, KEY__SHADOW_TOKEN);
  }
  if (supportsCssEscape() && isSyntheticShadowLoaded()) {
    if (false) {
      enableDetection$1();
    } else {
      onReportingEnabled(enableDetection$1);
    }
  }
  var NON_STANDARD_ARIA_PROPS = [
    "ariaActiveDescendant",
    "ariaControls",
    "ariaDescribedBy",
    "ariaDetails",
    "ariaErrorMessage",
    "ariaFlowTo",
    "ariaLabelledBy",
    "ariaOwns"
  ];
  function isGlobalAriaPolyfillLoaded() {
    return !isUndefined$1(getOwnPropertyDescriptor$1(Element.prototype, "ariaActiveDescendant"));
  }
  function findVM(elm) {
    const { host } = elm.getRootNode();
    const vm = isUndefined$1(host) ? void 0 : getAssociatedVMIfPresent(host);
    if (!isUndefined$1(vm)) {
      return vm;
    }
    let parentElement = elm;
    while (!isNull(parentElement = parentElement.parentElement)) {
      if (parentElement instanceof BaseBridgeElement) {
        const vm2 = getAssociatedVMIfPresent(parentElement);
        if (!isUndefined$1(vm2)) {
          return vm2;
        }
      }
    }
  }
  function checkAndReportViolation(elm, prop, isSetter, setValue) {
    const vm = findVM(elm);
    if (false) {
      logWarnOnce(`Element <${elm.tagName.toLowerCase()}> ` + (isUndefined$1(vm) ? "" : `owned by <${vm.elm.tagName.toLowerCase()}> `) + `uses non-standard property "${prop}". This will be removed in a future version of LWC. See https://sfdc.co/deprecated-aria`);
    }
    let setValueType;
    if (isSetter) {
      setValueType = isNull(setValue) ? "null" : typeof setValue;
    }
    report("NonStandardAriaReflection", {
      tagName: vm?.tagName,
      propertyName: prop,
      isSetter,
      setValueType
    });
  }
  function enableDetection() {
    const { prototype } = Element;
    for (const prop of NON_STANDARD_ARIA_PROPS) {
      const descriptor = getOwnPropertyDescriptor$1(prototype, prop);
      if (false) {
        if (isUndefined$1(descriptor) || isUndefined$1(descriptor.get) || isUndefined$1(descriptor.set)) {
          throw new Error("detect-non-standard-aria.ts loaded before @lwc/aria-reflection");
        }
      }
      const { get, set } = descriptor;
      defineProperty(prototype, prop, {
        get() {
          checkAndReportViolation(this, prop, false, void 0);
          return get.call(this);
        },
        set(val) {
          checkAndReportViolation(this, prop, true, val);
          return set.call(this, val);
        },
        configurable: true,
        enumerable: true
      });
    }
  }
  if (isGlobalAriaPolyfillLoaded()) {
    if (false) {
      enableDetection();
    } else {
      onReportingEnabled(enableDetection);
    }
  }
  var TEMPLATE_PROPS = [
    "slots",
    "stylesheetToken",
    "stylesheets",
    "renderMode",
    "legacyStylesheetToken"
  ];
  var STYLESHEET_PROPS = [KEY__SCOPED_CSS, KEY__NATIVE_ONLY_CSS];
  var ARRAY_MUTATION_METHODS = [
    "pop",
    "push",
    "shift",
    "unshift",
    "reverse",
    "sort",
    "fill",
    "splice",
    "copyWithin"
  ];
  var mutationTrackingDisabled = false;
  function getOriginalArrayMethod(prop) {
    switch (prop) {
      case "pop":
        return ArrayPop;
      case "push":
        return ArrayPush$1;
      case "shift":
        return ArrayShift;
      case "unshift":
        return ArrayUnshift;
      case "reverse":
        return ArrayReverse;
      case "sort":
        return ArraySort;
      case "fill":
        return ArrayFill;
      case "splice":
        return ArraySplice;
      case "copyWithin":
        return ArrayCopyWithin;
    }
  }
  function reportViolation(type, eventId, prop) {
    if (false) {
      logWarnOnce(`Mutating the "${prop}" property on a ${type} is deprecated and will be removed in a future version of LWC. See: https://sfdc.co/template-mutation`);
    }
    report(eventId, { propertyName: prop });
  }
  function reportTemplateViolation(prop) {
    reportViolation("template", "TemplateMutation", prop);
  }
  function reportStylesheetViolation(prop) {
    reportViolation("stylesheet", "StylesheetMutation", prop);
  }
  function warnOnArrayMutation(stylesheets) {
    for (const prop of ARRAY_MUTATION_METHODS) {
      const originalArrayMethod = getOriginalArrayMethod(prop);
      stylesheets[prop] = function arrayMutationWarningWrapper() {
        reportTemplateViolation("stylesheets");
        return originalArrayMethod.apply(this, arguments);
      };
    }
  }
  function warnOnStylesheetFunctionMutation(stylesheet6) {
    for (const prop of STYLESHEET_PROPS) {
      let value = stylesheet6[prop];
      defineProperty(stylesheet6, prop, {
        enumerable: true,
        configurable: true,
        get() {
          return value;
        },
        set(newValue) {
          reportStylesheetViolation(prop);
          value = newValue;
        }
      });
    }
  }
  function trackStylesheetsMutation(stylesheets) {
    traverseStylesheets(stylesheets, (subStylesheets) => {
      if (isArray$1(subStylesheets)) {
        warnOnArrayMutation(subStylesheets);
      } else {
        warnOnStylesheetFunctionMutation(subStylesheets);
      }
    });
  }
  function deepFreeze(stylesheets) {
    traverseStylesheets(stylesheets, (subStylesheets) => {
      freeze(subStylesheets);
    });
  }
  function traverseStylesheets(stylesheets, callback) {
    callback(stylesheets);
    for (let i2 = 0; i2 < stylesheets.length; i2++) {
      const stylesheet6 = stylesheets[i2];
      if (isArray$1(stylesheet6)) {
        traverseStylesheets(stylesheet6, callback);
      } else {
        callback(stylesheet6);
      }
    }
  }
  function trackMutations(tmpl6) {
    if (!isUndefined$1(tmpl6.stylesheets)) {
      trackStylesheetsMutation(tmpl6.stylesheets);
    }
    for (const prop of TEMPLATE_PROPS) {
      let value = tmpl6[prop];
      defineProperty(tmpl6, prop, {
        enumerable: true,
        configurable: true,
        get() {
          return value;
        },
        set(newValue) {
          if (!mutationTrackingDisabled) {
            reportTemplateViolation(prop);
          }
          value = newValue;
        }
      });
    }
    const originalDescriptor = getOwnPropertyDescriptor$1(tmpl6, "stylesheetTokens");
    defineProperty(tmpl6, "stylesheetTokens", {
      enumerable: true,
      configurable: true,
      get: originalDescriptor.get,
      set(value) {
        reportTemplateViolation("stylesheetTokens");
        mutationTrackingDisabled = true;
        originalDescriptor.set.call(this, value);
        mutationTrackingDisabled = false;
      }
    });
  }
  function addLegacyStylesheetTokensShim(tmpl6) {
    defineProperty(tmpl6, "stylesheetTokens", {
      enumerable: true,
      configurable: true,
      get() {
        const { stylesheetToken } = this;
        if (isUndefined$1(stylesheetToken)) {
          return stylesheetToken;
        }
        return {
          hostAttribute: `${stylesheetToken}-host`,
          shadowAttribute: stylesheetToken
        };
      },
      set(value) {
        this.stylesheetToken = isUndefined$1(value) ? void 0 : value.shadowAttribute;
      }
    });
  }
  function freezeTemplate(tmpl6) {
    if (lwcRuntimeFlags.ENABLE_FROZEN_TEMPLATE) {
      freeze(tmpl6);
      if (!isUndefined$1(tmpl6.stylesheets)) {
        deepFreeze(tmpl6.stylesheets);
      }
    } else {
      addLegacyStylesheetTokensShim(tmpl6);
      if (false) {
        trackMutations(tmpl6);
      } else {
        onReportingEnabled(() => {
          trackMutations(tmpl6);
        });
      }
    }
  }
  if (false) {
    init();
  }
  var supportsConstructableStylesheets = isFunction$1(CSSStyleSheet.prototype.replaceSync) && isArray$1(document.adoptedStyleSheets);
  var stylesheetCache = /* @__PURE__ */ new Map();
  if (false) {
    window.__lwcResetGlobalStylesheets = () => {
      stylesheetCache.clear();
    };
  }
  function createFreshStyleElement(content) {
    const elm = document.createElement("style");
    elm.type = "text/css";
    elm.textContent = content;
    elm.setAttribute("data-rendered-by-lwc", "");
    return elm;
  }
  function createStyleElement(content, cacheData) {
    const { element, usedElement } = cacheData;
    if (usedElement) {
      return element.cloneNode(true);
    }
    cacheData.usedElement = true;
    return element;
  }
  function createConstructableStylesheet(content) {
    const stylesheet6 = new CSSStyleSheet();
    stylesheet6.replaceSync(content);
    return stylesheet6;
  }
  function insertConstructableStylesheet(content, target, cacheData, signal) {
    const { adoptedStyleSheets } = target;
    const { stylesheet: stylesheet6 } = cacheData;
    adoptedStyleSheets.push(stylesheet6);
    if (false) {
      if (isUndefined$1(signal)) {
        throw new Error("Expected AbortSignal to be defined in dev mode");
      }
      signal.addEventListener("abort", () => {
        adoptedStyleSheets.splice(adoptedStyleSheets.indexOf(stylesheet6), 1);
        stylesheetCache.delete(content);
      });
    }
  }
  function insertStyleElement(content, target, cacheData, signal) {
    const elm = createStyleElement(content, cacheData);
    target.appendChild(elm);
    if (false) {
      if (isUndefined$1(signal)) {
        throw new Error("Expected AbortSignal to be defined in dev mode");
      }
      signal.addEventListener("abort", () => {
        target.removeChild(elm);
        stylesheetCache.delete(content);
      });
    }
  }
  function getCacheData(content, useConstructableStylesheet) {
    let cacheData = stylesheetCache.get(content);
    if (isUndefined$1(cacheData)) {
      cacheData = {
        stylesheet: void 0,
        element: void 0,
        roots: void 0,
        global: false,
        usedElement: false
      };
      stylesheetCache.set(content, cacheData);
    }
    if (useConstructableStylesheet && isUndefined$1(cacheData.stylesheet)) {
      cacheData.stylesheet = createConstructableStylesheet(content);
    } else if (!useConstructableStylesheet && isUndefined$1(cacheData.element)) {
      cacheData.element = createFreshStyleElement(content);
    }
    return cacheData;
  }
  function insertGlobalStylesheet(content, signal) {
    const cacheData = getCacheData(content, false);
    if (cacheData.global) {
      return;
    }
    cacheData.global = true;
    insertStyleElement(content, document.head, cacheData, signal);
  }
  function insertLocalStylesheet(content, target, signal) {
    const cacheData = getCacheData(content, supportsConstructableStylesheets);
    let { roots } = cacheData;
    if (isUndefined$1(roots)) {
      roots = cacheData.roots = /* @__PURE__ */ new WeakSet();
    } else if (roots.has(target)) {
      return;
    }
    roots.add(target);
    if (supportsConstructableStylesheets) {
      insertConstructableStylesheet(content, target, cacheData, signal);
    } else {
      insertStyleElement(content, target, cacheData, signal);
    }
  }
  function insertStylesheet(content, target, signal) {
    if (isUndefined$1(target)) {
      insertGlobalStylesheet(content, signal);
    } else {
      insertLocalStylesheet(content, target, signal);
    }
  }
  var cachedConstructors = /* @__PURE__ */ new Map();
  var nativeLifecycleElementsToUpgradedByLWC = /* @__PURE__ */ new WeakMap();
  var elementBeingUpgradedByLWC = false;
  var BaseUpgradableConstructor;
  var BaseHTMLElement;
  function createBaseUpgradableConstructor() {
    BaseUpgradableConstructor = class TheBaseUpgradableConstructor extends HTMLElement {
      constructor(upgradeCallback, useNativeLifecycle) {
        super();
        if (useNativeLifecycle) {
          nativeLifecycleElementsToUpgradedByLWC.set(this, elementBeingUpgradedByLWC);
        }
        if (elementBeingUpgradedByLWC) {
          upgradeCallback(this);
        }
      }
      connectedCallback() {
        if (isTrue(nativeLifecycleElementsToUpgradedByLWC.get(this))) {
          connectRootElement(this);
        }
      }
      disconnectedCallback() {
        if (isTrue(nativeLifecycleElementsToUpgradedByLWC.get(this))) {
          disconnectRootElement(this);
        }
      }
      formAssociatedCallback(form) {
        runFormAssociatedCallback(this, form);
      }
      formDisabledCallback(disabled) {
        runFormDisabledCallback(this, disabled);
      }
      formResetCallback() {
        runFormResetCallback(this);
      }
      formStateRestoreCallback(state, reason) {
        runFormStateRestoreCallback(this, state, reason);
      }
    };
    BaseHTMLElement = HTMLElement;
  }
  var createUpgradableConstructor = (isFormAssociated) => {
    if (HTMLElement !== BaseHTMLElement) {
      createBaseUpgradableConstructor();
    }
    class UpgradableConstructor extends BaseUpgradableConstructor {
    }
    if (isFormAssociated) {
      UpgradableConstructor.formAssociated = isFormAssociated;
    }
    return UpgradableConstructor;
  };
  function getUpgradableConstructor(tagName, isFormAssociated) {
    let UpgradableConstructor = cachedConstructors.get(tagName);
    if (isUndefined$1(UpgradableConstructor)) {
      if (!isUndefined$1(customElements.get(tagName))) {
        throw new Error(`Unexpected tag name "${tagName}". This name is a registered custom element, preventing LWC to upgrade the element.`);
      }
      UpgradableConstructor = createUpgradableConstructor(isFormAssociated);
      customElements.define(tagName, UpgradableConstructor);
      cachedConstructors.set(tagName, UpgradableConstructor);
    }
    return UpgradableConstructor;
  }
  var createCustomElement = (tagName, upgradeCallback, useNativeLifecycle, isFormAssociated) => {
    const UpgradableConstructor = getUpgradableConstructor(tagName, isFormAssociated);
    if (Boolean(UpgradableConstructor.formAssociated) !== isFormAssociated) {
      throw new Error(`<${tagName}> was already registered with formAssociated=${UpgradableConstructor.formAssociated}. It cannot be re-registered with formAssociated=${isFormAssociated}. Please rename your component to have a different name than <${tagName}>`);
    }
    elementBeingUpgradedByLWC = true;
    try {
      return new UpgradableConstructor(upgradeCallback, useNativeLifecycle);
    } finally {
      elementBeingUpgradedByLWC = false;
    }
  };
  function rendererFactory(baseRenderer) {
    const renderer2 = (function(exports$1) {
      function invariant2(value, msg) {
        if (!value) {
          throw new Error(`Invariant Violation: ${msg}`);
        }
      }
      function isTrue$12(value, msg) {
        if (!value) {
          throw new Error(`Assert Violation: ${msg}`);
        }
      }
      function isFalse$12(value, msg) {
        if (value) {
          throw new Error(`Assert Violation: ${msg}`);
        }
      }
      function fail2(msg) {
        throw new Error(msg);
      }
      var assert2 = /* @__PURE__ */ Object.freeze({
        __proto__: null,
        fail: fail2,
        invariant: invariant2,
        isFalse: isFalse$12,
        isTrue: isTrue$12
      });
      const {
        /** Detached {@linkcode Object.getOwnPropertyDescriptors}; see {@link https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Object/getOwnPropertyDescriptors MDN Reference}. */
        getOwnPropertyDescriptors: getOwnPropertyDescriptors2
      } = Object;
      function isUndefined2(obj) {
        return obj === void 0;
      }
      function isNull2(obj) {
        return obj === null;
      }
      const ElementDescriptors2 = getOwnPropertyDescriptors2(Element.prototype);
      const ElementAttachShadow = ElementDescriptors2.attachShadow.value;
      const ElementShadowRootGetter = ElementDescriptors2.shadowRoot.get;
      class WireContextSubscriptionEvent extends CustomEvent {
        constructor(adapterToken, { setNewContext, setDisconnectedCallback }) {
          super(adapterToken, {
            bubbles: true,
            composed: true
          });
          this.setNewContext = setNewContext;
          this.setDisconnectedCallback = setDisconnectedCallback;
        }
      }
      function registerContextConsumer(elm, adapterContextToken, subscriptionPayload) {
        dispatchEvent(elm, new WireContextSubscriptionEvent(adapterContextToken, subscriptionPayload));
      }
      function registerContextProvider(elm, adapterContextToken, onContextSubscription) {
        addEventListener(elm, adapterContextToken, ((evt) => {
          const { setNewContext, setDisconnectedCallback } = evt;
          if (onContextSubscription({
            setNewContext,
            setDisconnectedCallback
          })) {
            evt.stopImmediatePropagation();
          }
        }));
      }
      function cloneNode(node, deep) {
        return node.cloneNode(deep);
      }
      function createElement2(tagName, namespace) {
        return isUndefined2(namespace) ? document.createElement(tagName) : document.createElementNS(namespace, tagName);
      }
      function createText(content) {
        return document.createTextNode(content);
      }
      function createComment(content) {
        return document.createComment(content);
      }
      function createFragment(html) {
        const template = document.createElement("template");
        template.innerHTML = html;
        return template.content.firstChild;
      }
      function insert(node, parent, anchor) {
        parent.insertBefore(node, anchor);
      }
      function remove(node, parent) {
        parent.removeChild(node);
      }
      function nextSibling(node) {
        return node.nextSibling;
      }
      function previousSibling(node) {
        return node.previousSibling;
      }
      function getParentNode(node) {
        return node.parentNode;
      }
      function attachShadow(element, options) {
        const shadowRoot = ElementShadowRootGetter.call(element);
        if (!isNull2(shadowRoot)) {
          return shadowRoot;
        }
        return ElementAttachShadow.call(element, options);
      }
      function setText(node, content) {
        node.nodeValue = content;
      }
      function getProperty(node, key) {
        return node[key];
      }
      function setProperty(node, key, value) {
        node[key] = value;
      }
      function getAttribute(element, name, namespace) {
        return isUndefined2(namespace) ? element.getAttribute(name) : element.getAttributeNS(namespace, name);
      }
      function setAttribute(element, name, value, namespace) {
        return isUndefined2(namespace) ? element.setAttribute(name, value) : element.setAttributeNS(namespace, name, value);
      }
      function removeAttribute(element, name, namespace) {
        if (isUndefined2(namespace)) {
          element.removeAttribute(name);
        } else {
          element.removeAttributeNS(namespace, name);
        }
      }
      function addEventListener(target, type, callback, options) {
        target.addEventListener(type, callback, options);
      }
      function removeEventListener(target, type, callback, options) {
        target.removeEventListener(type, callback, options);
      }
      function dispatchEvent(target, event) {
        return target.dispatchEvent(event);
      }
      function getClassList(element) {
        return element.classList;
      }
      function setCSSStyleProperty(element, name, value, important) {
        element.style.setProperty(name, value, important ? "important" : "");
      }
      function getBoundingClientRect(element) {
        return element.getBoundingClientRect();
      }
      function querySelector(element, selectors) {
        return element.querySelector(selectors);
      }
      function querySelectorAll2(element, selectors) {
        return element.querySelectorAll(selectors);
      }
      function getElementsByTagName(element, tagNameOrWildCard) {
        return element.getElementsByTagName(tagNameOrWildCard);
      }
      function getElementsByClassName(element, names) {
        return element.getElementsByClassName(names);
      }
      function getChildren(element) {
        return element.children;
      }
      function getChildNodes(element) {
        return element.childNodes;
      }
      function getFirstChild(element) {
        return element.firstChild;
      }
      function getFirstElementChild(element) {
        return element.firstElementChild;
      }
      function getLastChild(element) {
        return element.lastChild;
      }
      function getLastElementChild(element) {
        return element.lastElementChild;
      }
      function isConnected(node) {
        return node.isConnected;
      }
      function assertInstanceOfHTMLElement(elm, msg) {
        assert2.invariant(elm instanceof HTMLElement, msg);
      }
      function ownerDocument(element) {
        return element.ownerDocument;
      }
      function getTagName(elm) {
        return elm.tagName;
      }
      function getStyle(elm) {
        return elm.style;
      }
      function attachInternals(elm) {
        return attachInternalsFunc.call(elm);
      }
      const attachInternalsFunc = typeof ElementInternals !== "undefined" ? HTMLElement.prototype.attachInternals : () => {
        throw new Error("attachInternals API is not supported in this browser environment.");
      };
      exports$1.addEventListener = addEventListener;
      exports$1.assertInstanceOfHTMLElement = assertInstanceOfHTMLElement;
      exports$1.attachInternals = attachInternals;
      exports$1.attachShadow = attachShadow;
      exports$1.cloneNode = cloneNode;
      exports$1.createComment = createComment;
      exports$1.createElement = createElement2;
      exports$1.createFragment = createFragment;
      exports$1.createText = createText;
      exports$1.dispatchEvent = dispatchEvent;
      exports$1.getAttribute = getAttribute;
      exports$1.getBoundingClientRect = getBoundingClientRect;
      exports$1.getChildNodes = getChildNodes;
      exports$1.getChildren = getChildren;
      exports$1.getClassList = getClassList;
      exports$1.getElementsByClassName = getElementsByClassName;
      exports$1.getElementsByTagName = getElementsByTagName;
      exports$1.getFirstChild = getFirstChild;
      exports$1.getFirstElementChild = getFirstElementChild;
      exports$1.getLastChild = getLastChild;
      exports$1.getLastElementChild = getLastElementChild;
      exports$1.getParentNode = getParentNode;
      exports$1.getProperty = getProperty;
      exports$1.getStyle = getStyle;
      exports$1.getTagName = getTagName;
      exports$1.insert = insert;
      exports$1.isConnected = isConnected;
      exports$1.nextSibling = nextSibling;
      exports$1.ownerDocument = ownerDocument;
      exports$1.previousSibling = previousSibling;
      exports$1.querySelector = querySelector;
      exports$1.querySelectorAll = querySelectorAll2;
      exports$1.registerContextConsumer = registerContextConsumer;
      exports$1.registerContextProvider = registerContextProvider;
      exports$1.remove = remove;
      exports$1.removeAttribute = removeAttribute;
      exports$1.removeEventListener = removeEventListener;
      exports$1.setAttribute = setAttribute;
      exports$1.setCSSStyleProperty = setCSSStyleProperty;
      exports$1.setProperty = setProperty;
      exports$1.setText = setText;
      return exports$1;
    })({});
    Object.setPrototypeOf(renderer2, baseRenderer);
    return renderer2;
  }
  var startTrackingMutations = noop;
  var stopTrackingMutations = noop;
  var renderer = assign(
    // The base renderer will invoke the factory with null and assign additional properties that are
    // shared across renderers
    rendererFactory(null),
    // Properties that are either not required to be sandboxed or rely on a globally shared information
    {
      // insertStyleSheet implementation shares a global cache of stylesheet data
      insertStylesheet,
      // relies on a shared global cache
      createCustomElement,
      defineCustomElement: getUpgradableConstructor,
      isSyntheticShadowDefined: hasOwnProperty$1.call(Element.prototype, KEY__SHADOW_TOKEN),
      startTrackingMutations,
      stopTrackingMutations
    }
  );
  function clearNode(node) {
    const childNodes = renderer.getChildNodes(node);
    for (let i2 = childNodes.length - 1; i2 >= 0; i2--) {
      renderer.remove(childNodes[i2], node);
    }
  }
  function buildCustomElementConstructor(Ctor) {
    var _a;
    const HtmlPrototype = getComponentHtmlPrototype(Ctor);
    const { observedAttributes } = HtmlPrototype;
    const { attributeChangedCallback } = HtmlPrototype.prototype;
    return _a = class extends HTMLElement {
      constructor() {
        super();
        if (!isNull(this.shadowRoot)) {
          if (false) {
            console.warn(`Found an existing shadow root for the custom element "${Ctor.name}". Call \`hydrateComponent\` instead.`);
          }
          clearNode(this.shadowRoot);
        }
        const { shadowMode, renderMode } = computeShadowAndRenderMode(Ctor, renderer);
        const isNativeShadow = renderMode === 1 && shadowMode === 0;
        if (!isNativeShadow && this.childNodes.length > 0) {
          if (false) {
            console.warn(`Light DOM and synthetic shadow custom elements cannot have child nodes. Ensure the element is empty, including whitespace.`);
          }
          clearNode(this);
        }
        createVM(this, Ctor, renderer, {
          mode: "open",
          owner: null,
          tagName: this.tagName
        });
      }
      connectedCallback() {
        connectRootElement(this);
      }
      disconnectedCallback() {
        disconnectRootElement(this);
      }
      attributeChangedCallback(name, oldValue, newValue) {
        if (this instanceof BaseBridgeElement) {
          attributeChangedCallback.call(this, name, oldValue, newValue);
        }
      }
      formAssociatedCallback(form) {
        runFormAssociatedCallback(this, form);
      }
      formDisabledCallback(disabled) {
        runFormDisabledCallback(this, disabled);
      }
      formResetCallback() {
        runFormResetCallback(this);
      }
      formStateRestoreCallback(state, reason) {
        runFormStateRestoreCallback(this, state, reason);
      }
    }, _a.observedAttributes = observedAttributes, // Note CustomElementConstructor is not upgraded by LWC and inherits directly from HTMLElement which means it calls the native
    // attachInternals API.
    _a.formAssociated = Boolean(Ctor.formAssociated), _a;
  }
  var _Node$1 = Node;
  var ConnectingSlot = /* @__PURE__ */ new WeakMap();
  var DisconnectingSlot = /* @__PURE__ */ new WeakMap();
  function callNodeSlot(node, slot) {
    if (false) {
      assert.isTrue(node, `callNodeSlot() should not be called for a non-object`);
    }
    const fn = slot.get(node);
    if (!isUndefined$1(fn)) {
      fn(node);
    }
    return node;
  }
  var monkeyPatched = false;
  function monkeyPatchDomAPIs() {
    if (monkeyPatched) {
      return;
    }
    monkeyPatched = true;
    const { appendChild, insertBefore, removeChild, replaceChild } = _Node$1.prototype;
    assign(_Node$1.prototype, {
      appendChild(newChild) {
        const appendedNode = appendChild.call(this, newChild);
        return callNodeSlot(appendedNode, ConnectingSlot);
      },
      insertBefore(newChild, referenceNode) {
        if (false) {
          console.warn("insertBefore should be called with 2 arguments. Calling with only 1 argument is not supported.");
        }
        const insertedNode = insertBefore.call(this, newChild, referenceNode);
        return callNodeSlot(insertedNode, ConnectingSlot);
      },
      removeChild(oldChild) {
        const removedNode = removeChild.call(this, oldChild);
        return callNodeSlot(removedNode, DisconnectingSlot);
      },
      replaceChild(newChild, oldChild) {
        const replacedNode = replaceChild.call(this, newChild, oldChild);
        callNodeSlot(replacedNode, DisconnectingSlot);
        callNodeSlot(newChild, ConnectingSlot);
        return replacedNode;
      }
    });
  }
  if (false) {
    monkeyPatchDomAPIs();
  }
  function createElement(sel, options) {
    if (!isObject(options) || isNull(options)) {
      throw new TypeError(`"createElement" function expects an object as second parameter but received "${toString(options)}".`);
    }
    const Ctor = options.is;
    if (!isFunction$1(Ctor)) {
      throw new TypeError(`"createElement" function expects an "is" option with a valid component constructor.`);
    }
    const { createCustomElement: createCustomElement2 } = renderer;
    const tagName = StringToLowerCase.call(sel);
    const useNativeCustomElementLifecycle = !lwcRuntimeFlags.DISABLE_NATIVE_CUSTOM_ELEMENT_LIFECYCLE;
    const isFormAssociated = shouldBeFormAssociated(Ctor);
    const upgradeCallback = (elm) => {
      createVM(elm, Ctor, renderer, {
        tagName,
        mode: options.mode !== "closed" ? "open" : "closed",
        owner: null
      });
      if (!useNativeCustomElementLifecycle) {
        monkeyPatchDomAPIs();
        ConnectingSlot.set(elm, connectRootElement);
        DisconnectingSlot.set(elm, disconnectRootElement);
      }
    };
    return createCustomElement2(tagName, upgradeCallback, useNativeCustomElementLifecycle, isFormAssociated);
  }
  var ComponentConstructorToCustomElementConstructorMap = /* @__PURE__ */ new Map();
  function getCustomElementConstructor(Ctor) {
    if (Ctor === LightningElement) {
      throw new TypeError(`Invalid Constructor. LightningElement base class can't be claimed as a custom element.`);
    }
    let ce = ComponentConstructorToCustomElementConstructorMap.get(Ctor);
    if (isUndefined$1(ce)) {
      ce = buildCustomElementConstructor(Ctor);
      ComponentConstructorToCustomElementConstructorMap.set(Ctor, ce);
    }
    return ce;
  }
  defineProperty(LightningElement, "CustomElementConstructor", {
    get() {
      return getCustomElementConstructor(this);
    }
  });
  freeze(LightningElement);
  seal(LightningElement.prototype);
  var ElementDescriptors = getOwnPropertyDescriptors(Element.prototype);
  ElementDescriptors.attachShadow.value;
  ElementDescriptors.shadowRoot.get;

  // Holly_Production_Candidate/force-app/main/default/lwc/productCarouselWidget/productCarouselWidget.css
  function stylesheet(token, useActualHostSelector, useNativeDirPseudoclass) {
    var shadowSelector = token ? "[" + token + "]" : "";
    var hostSelector = token ? "[" + token + "-host]" : "";
    var suffixToken = token ? "-" + token : "";
    return [useActualHostSelector ? ":host {" : hostSelector + " {", "display: block;}.widget", shadowSelector, " {--purple: #604099;--purple-dark: #4a2f7c;--wash: #f4f0fb;--ink: #241a3a;--muted: #6b6480;--line: #ddd6ea;--promo: #b3261e;color: var(--ink);font-family: inherit;font-size: 0.8125rem;line-height: 1.35;}.notice", shadowSelector, " {background: var(--wash);border-radius: 10px;margin: 0;padding: 0.6rem 0.75rem;}.carousel", shadowSelector, " {position: relative;}.track", shadowSelector, " {display: flex;gap: 0.6rem;overflow-x: auto;padding: 0.15rem 0.15rem 0.5rem;scroll-snap-type: x proximity;scrollbar-width: thin;}.card", shadowSelector, " {background: #fff;border: 1px solid var(--line);border-radius: 12px;display: flex;flex: 0 0 9.75rem;flex-direction: column;gap: 0.3rem;padding: 0.55rem;scroll-snap-align: start;}.card--selected", shadowSelector, " {border-color: var(--purple);box-shadow: 0 0 0 2px var(--purple);}.card__media", shadowSelector, " {align-items: center;aspect-ratio: 1 / 1;background: var(--wash);border-radius: 8px;display: flex;justify-content: center;overflow: hidden;position: relative;}.card__img", shadowSelector, " {height: 100%;object-fit: contain;width: 100%;}.card__placeholder", shadowSelector, ",.compare__placeholder", shadowSelector, " {align-items: center;background: linear-gradient(145deg, #e6dcf7, #cdbdea);color: var(--purple-dark);display: flex;font-size: 1.4rem;font-weight: 700;height: 100%;justify-content: center;width: 100%;}.card__check", shadowSelector, " {accent-color: var(--purple);cursor: pointer;height: 1.15rem;left: 0.4rem;position: absolute;top: 0.4rem;width: 1.15rem;z-index: 1;}.card__title", shadowSelector, " {color: var(--ink);display: -webkit-box;font-size: 0.78rem;font-weight: 600;-webkit-box-orient: vertical;-webkit-line-clamp: 2;overflow: hidden;text-decoration: underline;text-underline-offset: 2px;}.card__title:hover", shadowSelector, ",.card__title:focus", shadowSelector, " {color: var(--purple);}.card__promo", shadowSelector, " {color: var(--promo);font-size: 0.7rem;font-weight: 600;margin: 0;}.card__rating", shadowSelector, ",.card__desc", shadowSelector, " {color: var(--muted);font-size: 0.72rem;margin: 0;}.card__foot", shadowSelector, " {align-items: center;display: flex;justify-content: space-between;margin-top: auto;padding-top: 0.25rem;}.card__price", shadowSelector, " {font-size: 0.9rem;font-weight: 700;}.menu", shadowSelector, " {position: relative;}.menu__btn", shadowSelector, " {background: #fff;border: 1px solid var(--line);border-radius: 6px;color: var(--ink);cursor: pointer;font-size: 0.6rem;height: 1.7rem;letter-spacing: 1px;width: 2rem;}.menu__btn:hover", shadowSelector, ",.menu__btn:focus-visible", shadowSelector, " {border-color: var(--purple);outline: none;}.menu__list", shadowSelector, " {background: #fff;border: 1px solid var(--line);border-radius: 10px;bottom: 2.1rem;box-shadow: 0 8px 24px rgba(36, 26, 58, 0.18);list-style: none;margin: 0;min-width: 10.5rem;padding: 0.3rem;position: absolute;right: 0;z-index: 5;}.menu__item", shadowSelector, " {background: transparent;border: 0;border-radius: 6px;color: var(--ink);cursor: pointer;display: block;font: inherit;padding: 0.5rem 0.6rem;text-align: left;text-decoration: none;width: 100%;}.menu__item:hover", shadowSelector, ",.menu__item:focus-visible", shadowSelector, " {background: var(--wash);outline: none;}.carousel__next", shadowSelector, " {align-items: center;background: #fff;border: 1px solid var(--line);border-radius: 50%;box-shadow: 0 2px 8px rgba(36, 26, 58, 0.2);color: var(--ink);cursor: pointer;display: flex;font-size: 1.2rem;height: 1.9rem;justify-content: center;position: absolute;right: -0.25rem;top: 38%;width: 1.9rem;}.carousel__next:hover", shadowSelector, ",.carousel__next:focus-visible", shadowSelector, " {border-color: var(--purple);outline: none;}.selectbar", shadowSelector, " {align-items: center;background: var(--wash);border-radius: 10px;display: flex;gap: 0.6rem;margin-top: 0.4rem;padding: 0.5rem 0.7rem;}.selectbar__label", shadowSelector, " {flex: 1;font-size: 0.78rem;}.selectbar__compare", shadowSelector, " {background: #fff;border: 1px solid var(--purple);border-radius: 6px;color: var(--purple-dark);cursor: pointer;font: inherit;font-weight: 600;padding: 0.3rem 0.8rem;}.selectbar__compare[disabled]", shadowSelector, " {border-color: var(--line);color: var(--muted);cursor: not-allowed;}.selectbar__close", shadowSelector, " {background: transparent;border: 0;color: var(--muted);cursor: pointer;font-size: 1.2rem;line-height: 1;}.compare__scroll", shadowSelector, " {overflow-x: auto;}.compare__table", shadowSelector, " {border-collapse: collapse;min-width: 100%;}.compare__head", shadowSelector, " {padding: 0.3rem 0.4rem 0.6rem;text-align: left;vertical-align: top;width: 8rem;}.compare__img", shadowSelector, ",.compare__placeholder", shadowSelector, " {aspect-ratio: 1 / 1;background: var(--wash);border-radius: 8px;display: block;height: auto;margin-bottom: 0.3rem;object-fit: contain;width: 100%;}.compare__name", shadowSelector, " {color: var(--ink);font-size: 0.75rem;font-weight: 600;text-decoration: underline;text-underline-offset: 2px;}.compare__label", shadowSelector, " {background: var(--wash);color: var(--muted);font-weight: 600;padding: 0.45rem 0.5rem;text-align: left;vertical-align: top;white-space: nowrap;}.compare__cell", shadowSelector, " {border-bottom: 1px solid var(--line);padding: 0.45rem 0.5rem;vertical-align: top;}.chips", shadowSelector, " {display: flex;flex-wrap: wrap;gap: 0.4rem;margin-top: 0.4rem;}.chip", shadowSelector, " {background: #fff;border: 1px solid var(--purple);border-radius: 6px;color: var(--purple-dark);cursor: pointer;font: inherit;padding: 0.35rem 0.65rem;}.chip:hover", shadowSelector, ",.chip:focus-visible", shadowSelector, " {background: var(--wash);outline: none;}.sr-only", shadowSelector, " {border: 0;clip: rect(0, 0, 0, 0);height: 1px;margin: -1px;overflow: hidden;padding: 0;position: absolute;width: 1px;}@media (prefers-reduced-motion: no-preference) {.track", shadowSelector, " {scroll-behavior: smooth;}}.catalog-note", shadowSelector, "{font-size:11px;line-height:1.4;color:#6b6480;margin:0 0 8px;padding:0;background:none}.carousel__previous", shadowSelector, "{left:2px;right:auto}.carousel__next", shadowSelector, "{right:2px;z-index:1;width:32px;height:32px}.carousel__next:disabled", shadowSelector, "{opacity:.35;cursor:default;box-shadow:none}.card", shadowSelector, "{border-radius:6px}.card__title", shadowSelector, "{font-size:14px;font-weight:500;line-height:1.3}.card__price", shadowSelector, "{font-size:14px;font-weight:500}.card__promo", shadowSelector, "{font-size:12px;font-weight:400}.track", shadowSelector, "{scroll-snap-type:x proximity}.card", shadowSelector, "{scroll-snap-align:start}.product-message", shadowSelector, "{margin:0;padding:14px 16px;background:#f3f3f3;color:#292e32;border-radius:18px;font:14px/1.5 Arial,sans-serif}.product-message", shadowSelector, "+.carousel", shadowSelector, "{margin-top:12px}.widget", shadowSelector, "{display:flex;flex-direction:column;gap:16px}.widget", shadowSelector, " > *", shadowSelector, "{min-width:0}.product-message", shadowSelector, "+.carousel", shadowSelector, "{margin-top:0}.chips", shadowSelector, "{margin:0;gap:8px}.widget", shadowSelector, "{--purple:#6748a0;--purple-dark:#503b74;--wash:#f0eaf7;--ink:#30353a;--line:#e0e3f3;--promo:#b62918;font:15px/1.5 Arial,sans-serif;gap:18px}.track", shadowSelector, "{gap:12px;padding:3px 0 12px}.card", shadowSelector, "{flex:0 0 210px;border-radius:8px;padding:14px;gap:12px}.card__media", shadowSelector, "{height:210px;aspect-ratio:auto;background:white}.card__title", shadowSelector, "{font-size:15px;font-weight:400;line-height:1.35;-webkit-line-clamp:3}.card__promo", shadowSelector, "{font-size:13px;font-weight:400}.card__price", shadowSelector, "{font-size:15px;font-weight:400}.product-message", shadowSelector, "{padding:16px 18px;border-radius:22px 22px 22px 0;font:16px/1.6 Arial,sans-serif;color:#30353a;background:#f3f3f3}.chips", shadowSelector, "{flex-wrap:nowrap;overflow-x:auto;padding-bottom:12px;gap:8px}.chip", shadowSelector, "{flex-shrink:0;border-color:#aaa6ae;color:#30353a;font:13px/1.5 Arial,sans-serif;padding:9px 12px}"].join("");
  }
  var productCarouselWidget_default = [stylesheet];

  // empty-style:empty
  var empty_default = void 0;

  // Holly_Production_Candidate/force-app/main/default/lwc/productCarouselWidget/productCarouselWidget.html
  var $fragment1 = parseFragment`<p class="product-message product-intro${0}"${2}>${"t1"}</p>`;
  var $fragment2 = parseFragment`<p class="notice${0}" role="alert"${2}>${"t1"}</p>`;
  var $fragment3 = parseFragment`<p class="notice${0}"${2}>The product results could not be displayed. Please ask again.</p>`;
  var $fragment4 = parseFragment`<img class="card__img${0}"${"a0:src"}${"a0:alt"}${"a0:data-sku"} loading="lazy"${2}>`;
  var $fragment5 = parseFragment`<div class="card__placeholder${0}" aria-hidden="true"${2}>${"t1"}</div>`;
  var $fragment6 = parseFragment`<a class="card__title${0}"${"a0:href"} target="_blank" rel="noopener noreferrer"${2}>${"t1"}</a>`;
  var $fragment7 = parseFragment`<p class="card__promo${0}"${2}>${"t1"}</p>`;
  var $fragment8 = parseFragment`<p class="card__rating${0}"${2}>${"t1"}</p>`;
  var $fragment9 = parseFragment`<p class="card__desc${0}"${2}>${"t1"}</p>`;
  var $fragment10 = parseFragment`<span class="card__price${0}"${2}>${"t1"}</span>`;
  var $fragment11 = parseFragment`<button type="button" class="menu__btn${0}"${"a0:data-sku"} aria-haspopup="true"${"a0:aria-expanded"}${"a0:aria-label"}${2}><span aria-hidden="true"${3}>•••</span></button>`;
  var $fragment12 = parseFragment`<ul class="menu__list${0}" role="menu"${2}><li role="none"${3}><button type="button" role="menuitem" class="menu__item${0}"${"a2:data-sku"}${2}>Ask follow up</button></li><li role="none"${3}><button type="button" role="menuitem" class="menu__item${0}"${"a5:data-sku"}${2}>Find similar</button></li><li role="none"${3}><a role="menuitem" class="menu__item${0}"${"a8:href"} target="_blank" rel="noopener noreferrer"${2}>Go to product page</a></li></ul>`;
  var $fragment13 = parseFragment`<div class="selectbar${0}" role="status"${2}><span class="selectbar__label${0}"${2}>${"t2"}</span><button type="button" class="selectbar__compare${0}"${"a3:disabled"}${2}>Compare</button><button type="button" class="selectbar__close${0}" aria-label="Cancel compare"${2}>×</button></div>`;
  var $fragment14 = parseFragment`<th scope="col" class="compare__corner${0}"${2}><span class="sr-only${0}"${2}>Feature</span></th>`;
  var $fragment15 = parseFragment`<img class="compare__img${0}"${"a0:src"}${"a0:alt"}${"a0:data-sku"}${2}>`;
  var $fragment16 = parseFragment`<div class="compare__placeholder${0}" aria-hidden="true"${2}>${"t1"}</div>`;
  var $fragment17 = parseFragment`<a class="compare__name${0}"${"a0:href"} target="_blank" rel="noopener noreferrer"${2}>${"t1"}</a>`;
  var $fragment18 = parseFragment`<th scope="row" class="compare__label${0}"${2}>${"t1"}</th>`;
  var $fragment19 = parseFragment`<td class="compare__cell${0}"${2}>${"t1"}</td>`;
  var $fragment20 = parseFragment`<p class="product-message${0}"${2}>${"t1"}</p>`;
  var $fragment21 = parseFragment`<button type="button" class="chip${0}"${"a0:data-index"}${2}>${"t1"}</button>`;
  var stc0 = {
    classMap: {
      "widget": true
    },
    key: 0
  };
  var stc1 = {
    classMap: {
      "carousel": true
    },
    key: 11
  };
  var stc2 = {
    classMap: {
      "track": true
    },
    attrs: {
      "role": "list",
      "tabindex": "0",
      "aria-label": "Products: scroll horizontally to explore"
    },
    key: 12
  };
  var stc3 = {
    "role": "listitem"
  };
  var stc4 = {
    classMap: {
      "card__media": true
    },
    key: 14
  };
  var stc5 = {
    "card__check": true
  };
  var stc6 = {
    classMap: {
      "card__foot": true
    },
    key: 33
  };
  var stc7 = {
    classMap: {
      "menu": true
    },
    key: 36
  };
  var stc8 = {
    classMap: {
      "compare": true
    },
    attrs: {
      "role": "table",
      "aria-label": "Product comparison"
    },
    key: 46
  };
  var stc9 = {
    classMap: {
      "compare__scroll": true
    },
    key: 47
  };
  var stc10 = {
    classMap: {
      "compare__table": true
    },
    key: 48
  };
  var stc11 = {
    key: 49
  };
  var stc12 = {
    key: 50
  };
  var stc13 = {
    "compare__head": true
  };
  var stc14 = {
    "scope": "col"
  };
  var stc15 = {
    key: 61
  };
  var stc16 = {
    classMap: {
      "chips": true
    },
    attrs: {
      "role": "group",
      "aria-label": "Suggested replies"
    },
    key: 71
  };
  function tmpl($api, $cmp, $slotset, $ctx) {
    const { d: api_dynamic_text, sp: api_static_part, st: api_static_fragment, fr: api_fragment, ncls: api_normalize_class_name, k: api_key, b: api_bind, h: api_element, i: api_iterator, f: api_flatten } = $api;
    const { _m0, _m1, _m2, _m3, _m4, _m5, _m6, _m7, _m8, _m9, _m10, _m11, _m12, _m13 } = $ctx;
    return [api_element("section", stc0, [$cmp.introMessage ? api_fragment(1, [api_static_fragment($fragment1, 3, [api_static_part(1, null, api_dynamic_text($cmp.introMessage))])], 0) : null, $cmp.sendError ? api_fragment(4, [api_static_fragment($fragment2, 6, [api_static_part(1, null, api_dynamic_text($cmp.sendError))])], 0) : null, $cmp.hasError ? api_fragment(7, [api_static_fragment($fragment3, 9)], 0) : null, $cmp.showCards ? api_fragment(10, [api_element("div", stc1, [api_element("div", stc2, api_iterator($cmp.products, function(p) {
      return api_element("article", {
        className: api_normalize_class_name(p.cardClass),
        attrs: stc3,
        key: api_key(13, p.key)
      }, [api_element("div", stc4, [p.showCheckbox ? api_fragment(15, [api_element("input", {
        classMap: stc5,
        attrs: {
          "type": "checkbox",
          "data-sku": p.sku,
          "disabled": p.checkboxDisabled ? "" : null,
          "aria-label": p.checkboxLabel
        },
        props: {
          "checked": p.isSelected
        },
        key: 16,
        on: _m0 || ($ctx._m0 = {
          "change": api_bind($cmp.handleSelect)
        })
      })], 0) : null, p.showImage ? api_fragment(17, [api_static_fragment($fragment4, 19, [api_static_part(0, {
        on: _m2 || ($ctx._m2 = {
          "error": api_bind($cmp.handleImageError)
        }),
        attrs: {
          "src": p.imageUrl,
          "alt": p.imageAlt,
          "data-sku": p.sku
        }
      }, null)])], 0) : api_fragment(17, [api_static_fragment($fragment5, 21, [api_static_part(1, null, api_dynamic_text(p.initials))])], 0)]), api_static_fragment($fragment6, 23, [api_static_part(0, {
        attrs: {
          "href": p.productUrl
        }
      }, null), api_static_part(1, null, api_dynamic_text(p.name))]), p.hasPromo ? api_fragment(24, [api_static_fragment($fragment7, 26, [api_static_part(1, null, api_dynamic_text(p.promoText))])], 0) : null, p.hasRating ? api_fragment(27, [api_static_fragment($fragment8, 29, [api_static_part(1, null, api_dynamic_text(p.ratingText))])], 0) : null, p.showDescription ? api_fragment(30, [api_static_fragment($fragment9, 32, [api_static_part(1, null, api_dynamic_text(p.shortDescription))])], 0) : null, api_element("div", stc6, [api_static_fragment($fragment10, 35, [api_static_part(1, null, api_dynamic_text(p.priceDisplay))]), api_element("div", stc7, [api_static_fragment($fragment11, 38, [api_static_part(0, {
        on: _m4 || ($ctx._m4 = {
          "click": api_bind($cmp.handleToggleMenu)
        }),
        attrs: {
          "data-sku": p.sku,
          "aria-expanded": p.menuExpanded,
          "aria-label": p.menuLabel
        }
      }, null)]), p.menuOpen ? api_fragment(39, [api_static_fragment($fragment12, 41, [api_static_part(2, {
        on: _m5 || ($ctx._m5 = {
          "click": api_bind($cmp.handleAskFollowUp)
        }),
        attrs: {
          "data-sku": p.sku
        }
      }, null), api_static_part(5, {
        on: _m6 || ($ctx._m6 = {
          "click": api_bind($cmp.handleFindSimilar)
        }),
        attrs: {
          "data-sku": p.sku
        }
      }, null), api_static_part(8, {
        on: _m7 || ($ctx._m7 = {
          "click": api_bind($cmp.handleMenuLinkClick)
        }),
        attrs: {
          "href": p.productUrl
        }
      }, null)])], 0) : null])])]);
    }))]), $cmp.showSelectBar ? api_fragment(42, [api_static_fragment($fragment13, 44, [api_static_part(2, null, api_dynamic_text($cmp.selectBarLabel)), api_static_part(3, {
      on: _m8 || ($ctx._m8 = {
        "click": api_bind($cmp.handleCompare)
      }),
      attrs: {
        "disabled": $cmp.compareDisabled ? "" : null
      }
    }, null), api_static_part(5, {
      on: _m9 || ($ctx._m9 = {
        "click": api_bind($cmp.handleCancelSelection)
      })
    }, null)])], 0) : null], 0) : null, $cmp.isCompare ? api_fragment(45, [api_element("div", stc8, [api_element("div", stc9, [api_element("table", stc10, [api_element("thead", stc11, [api_element("tr", stc12, api_flatten([api_static_fragment($fragment14, 52), api_iterator($cmp.compareColumns, function(col) {
      return api_element("th", {
        classMap: stc13,
        attrs: stc14,
        key: api_key(53, col.key)
      }, [col.showImage ? api_fragment(54, [api_static_fragment($fragment15, 56, [api_static_part(0, {
        on: _m11 || ($ctx._m11 = {
          "error": api_bind($cmp.handleImageError)
        }),
        attrs: {
          "src": col.imageUrl,
          "alt": col.imageAlt,
          "data-sku": col.sku
        }
      }, null)])], 0) : api_fragment(54, [api_static_fragment($fragment16, 58, [api_static_part(1, null, api_dynamic_text(col.initials))])], 0), api_static_fragment($fragment17, 60, [api_static_part(0, {
        attrs: {
          "href": col.productUrl
        }
      }, null), api_static_part(1, null, api_dynamic_text(col.name))])]);
    })]))]), api_element("tbody", stc15, api_iterator($cmp.compareRows, function(row) {
      return api_element("tr", {
        key: api_key(62, row.key)
      }, api_flatten([api_static_fragment($fragment18, 64, [api_static_part(1, null, api_dynamic_text(row.label))]), api_iterator(row.cells, function(cell) {
        return api_static_fragment($fragment19, api_key(66, cell.key), [api_static_part(1, null, api_dynamic_text(cell.value))]);
      })]));
    }))])])])], 0) : null, $cmp.followUpMessage ? api_fragment(67, [api_static_fragment($fragment20, 69, [api_static_part(1, null, api_dynamic_text($cmp.followUpMessage))])], 0) : null, $cmp.hasSuggestedReplies ? api_fragment(70, [api_element("div", stc16, api_iterator($cmp.suggestedReplies, function(reply, index) {
      return api_static_fragment($fragment21, api_key(73, reply.key), [api_static_part(0, {
        on: _m13 || ($ctx._m13 = {
          "click": api_bind($cmp.handleReply)
        }),
        attrs: {
          "data-index": index
        }
      }, null), api_static_part(1, null, api_dynamic_text(reply.label))]);
    }))], 0) : null])];
  }
  var productCarouselWidget_default2 = registerTemplate(tmpl);
  tmpl.stylesheets = [];
  tmpl.stylesheetToken = "lwc-19e98k9dept";
  tmpl.legacyStylesheetToken = "c-productCarouselWidget_productCarouselWidget";
  if (productCarouselWidget_default) {
    tmpl.stylesheets.push.apply(tmpl.stylesheets, productCarouselWidget_default);
  }
  if (empty_default) {
    tmpl.stylesheets.push.apply(tmpl.stylesheets, empty_default);
  }
  freezeTemplate(tmpl);

  // Holly_Production_Candidate/force-app/main/default/lwc/hollyUi/hollyUi.js
  function unwrapResponse(value) {
    let source = typeof value === "string" ? JSON.parse(value) : value;
    if (Array.isArray(source)) source = source[0];
    if (source?.renderedResponse != null) source = source.renderedResponse;
    if (typeof source === "string") source = JSON.parse(source);
    if (source == null) return {};
    if (typeof source !== "object" || Array.isArray(source)) throw new Error("Invalid typed response");
    return source;
  }
  function parseEnvelope(value, fallback) {
    const typed = unwrapResponse(value);
    const raw = typed.responsePayload ?? fallback;
    if (!raw) return null;
    const payload = typeof raw === "string" ? JSON.parse(raw) : raw;
    if (!payload || typeof payload !== "object" || Array.isArray(payload)) throw new Error("Invalid response");
    return payload;
  }
  function safeHttps(value, hosts = []) {
    try {
      const url = new URL(value);
      if (url.protocol !== "https:" || url.username || url.password) return "";
      if (hosts.length && !hosts.some((host) => url.hostname === host || url.hostname.endsWith("." + host))) return "";
      return url.href;
    } catch {
      return "";
    }
  }
  async function sendMessage(configuration2, text) {
    if (typeof configuration2?.util?.sendTextMessage !== "function") throw new Error("Chat unavailable");
    await configuration2.util.sendTextMessage(text);
  }

  // Holly_Production_Candidate/force-app/main/default/lwc/productCarouselWidget/productCarouselWidget.js
  var DEFAULT_MAX_COMPARE = 3;
  var ProductCarouselWidget = class extends LightningElement {
    constructor(...args) {
      super(...args);
      this.summaryMessage = "";
      this.responsePayload = "";
      this.value = void 0;
      this.configuration = void 0;
      this.sendError = "";
      this.sending = false;
      this.parsedPayload = void 0;
      this.selectedSkus = [];
      this.selectionMode = false;
      this.openMenuSku = null;
      this.failedImageSkus = [];
      this._lastStateKey = void 0;
    }
    get typedResponse() {
      try {
        return unwrapResponse(this.value);
      } catch {
        return {};
      }
    }
    get introMessage() {
      return this.hasError ? "" : this.typedResponse.summaryMessage || this.summaryMessage || "";
    }
    get followUpMessage() {
      return this.hasError ? "" : this.typedResponse.followUpQuestion || "";
    }
    connectedCallback() {
      this.parsePayload();
    }
    renderedCallback() {
      const stateKey = JSON.stringify(this.value || {}) + "|" + (this.responsePayload || "");
      if (this._lastStateKey !== stateKey) {
        this.parsePayload();
      }
    }
    // ------------------------------------------------------------------
    // Payload
    // ------------------------------------------------------------------
    parsePayload() {
      const rawValue = Array.isArray(this.value) ? this.value[0] : this.value;
      const sourceValue = rawValue && typeof rawValue === "object" ? rawValue : {};
      const typedValue = sourceValue.renderedResponse && typeof sourceValue.renderedResponse === "object" ? sourceValue.renderedResponse : sourceValue;
      const incoming = typedValue.responsePayload !== void 0 ? typedValue.responsePayload : this.responsePayload;
      this._lastStateKey = JSON.stringify(this.value || {}) + "|" + (this.responsePayload || "");
      this.parsedPayload = null;
      this.selectedSkus = [];
      this.selectionMode = false;
      this.openMenuSku = null;
      this.failedImageSkus = [];
      if (!incoming) {
        return;
      }
      try {
        const payload = parseEnvelope(this.value, this.responsePayload);
        if (!["productCarousel", "productCompare", "productDetail"].includes(payload.view) || !Array.isArray(payload.products)) throw new Error("Invalid response");
        const seen = /* @__PURE__ */ new Set();
        payload.products = payload.products.filter((p) => p && typeof p.sku === "string" && !seen.has(p.sku) && seen.add(p.sku)).map((p) => ({
          ...p,
          imageUrl: safeHttps(p.imageUrl, ["hallmark.com"]),
          productUrl: safeHttps(p.productUrl, ["hallmark.com"])
        }));
        if (payload.rows != null && (!Array.isArray(payload.rows) || payload.rows.some((row) => !row || !Array.isArray(row.values)))) throw new Error("Invalid comparison");
        if (payload.suggestedReplies != null && (!Array.isArray(payload.suggestedReplies) || payload.suggestedReplies.some((reply) => !reply || typeof reply.label !== "string"))) throw new Error("Invalid replies");
        this.parsedPayload = payload;
      } catch (error) {
        this.parsedPayload = {
          view: "error"
        };
      }
    }
    get hasPayload() {
      return !!this.parsedPayload && this.parsedPayload.view !== "error";
    }
    get hasError() {
      return !!this.parsedPayload && this.parsedPayload.view === "error";
    }
    get maxCompare() {
      return Math.max(2, Math.min(DEFAULT_MAX_COMPARE, Number(this.parsedPayload?.maxCompare) || DEFAULT_MAX_COMPARE));
    }
    get isCarousel() {
      return this.hasPayload && this.parsedPayload.view === "productCarousel";
    }
    get isDetail() {
      return this.hasPayload && this.parsedPayload.view === "productDetail";
    }
    get isCompare() {
      return this.hasPayload && this.parsedPayload.view === "productCompare";
    }
    get showCards() {
      return this.isCarousel || this.isDetail;
    }
    // ------------------------------------------------------------------
    // Cards
    // ------------------------------------------------------------------
    get rawProducts() {
      return this.parsedPayload && this.parsedPayload.products || [];
    }
    get products() {
      const atLimit = this.selectedSkus.length >= this.maxCompare;
      return this.rawProducts.map((product2) => {
        const isSelected = this.selectedSkus.includes(product2.sku);
        const menuOpen = this.openMenuSku === product2.sku;
        const showImage = !!product2.imageUrl && !this.failedImageSkus.includes(product2.sku);
        return {
          ...product2,
          key: product2.sku,
          showImage,
          initials: this.initialsFor(product2.name),
          hasPromo: !!product2.promoText,
          isSelected,
          menuOpen,
          menuExpanded: menuOpen ? "true" : "false",
          showCheckbox: this.selectionMode,
          checkboxDisabled: atLimit && !isSelected,
          checkboxLabel: "Select " + product2.name + " to compare",
          menuLabel: "More options for " + product2.name,
          hasRating: product2.rating !== null && product2.rating !== void 0,
          ratingText: product2.rating ? product2.rating + " (" + (product2.reviewCount || 0) + ")" : "",
          showDescription: this.isDetail && !!product2.shortDescription,
          cardClass: "card" + (isSelected ? " card--selected" : "")
        };
      });
    }
    initialsFor(name) {
      return (name || "").split(" ").filter((part) => part.length > 2).slice(0, 2).map((part) => part.charAt(0).toUpperCase()).join("");
    }
    // ------------------------------------------------------------------
    // Selection / compare bar
    // ------------------------------------------------------------------
    get showSelectBar() {
      return this.isCarousel && this.selectionMode;
    }
    get selectBarLabel() {
      return "Select products " + this.selectedSkus.length + "/" + this.maxCompare;
    }
    get compareDisabled() {
      return this.sending || this.selectedSkus.length < 2;
    }
    // ------------------------------------------------------------------
    // Suggested replies
    // ------------------------------------------------------------------
    get suggestedReplies() {
      const replies = this.parsedPayload && this.parsedPayload.suggestedReplies || [];
      return replies.map((reply, index) => ({
        ...reply,
        key: "reply-" + index
      }));
    }
    get hasSuggestedReplies() {
      return this.suggestedReplies.length > 0 && !this.selectionMode;
    }
    // ------------------------------------------------------------------
    // Compare table
    // ------------------------------------------------------------------
    get compareColumns() {
      return this.rawProducts.map((product2) => ({
        ...product2,
        key: "col-" + product2.sku,
        showImage: !!product2.imageUrl && !this.failedImageSkus.includes(product2.sku),
        initials: this.initialsFor(product2.name)
      }));
    }
    get compareRows() {
      const rows = this.parsedPayload && this.parsedPayload.rows || [];
      return rows.map((row) => ({
        key: "row-" + row.label,
        label: row.label,
        cells: (row.values || []).map((value, index) => ({
          key: "cell-" + row.label + "-" + index,
          value
        }))
      }));
    }
    // ------------------------------------------------------------------
    // Handlers
    // ------------------------------------------------------------------
    handleImageError(event) {
      const sku = event.target.dataset.sku;
      if (sku && !this.failedImageSkus.includes(sku)) {
        this.failedImageSkus = [...this.failedImageSkus, sku];
      }
    }
    handleToggleMenu(event) {
      const sku = event.currentTarget.dataset.sku;
      this.openMenuSku = this.openMenuSku === sku ? null : sku;
    }
    handleAskFollowUp(event) {
      const product2 = this.productFor(event.currentTarget.dataset.sku);
      this.openMenuSku = null;
      if (product2) {
        this.sendToAgent("Tell me more about " + product2.name + " (item " + product2.sku + ")");
      }
    }
    handleFindSimilar(event) {
      const product2 = this.productFor(event.currentTarget.dataset.sku);
      this.openMenuSku = null;
      if (product2) {
        this.sendToAgent("Show me products similar to " + product2.name + " (item " + product2.sku + ")");
      }
    }
    handleMenuLinkClick() {
      this.openMenuSku = null;
    }
    handleSelect(event) {
      const sku = event.target.dataset.sku;
      if (event.target.checked) {
        if (!this.selectedSkus.includes(sku) && this.selectedSkus.length < this.maxCompare) {
          this.selectedSkus = [...this.selectedSkus, sku];
        }
      } else {
        this.selectedSkus = this.selectedSkus.filter((item) => item !== sku);
      }
    }
    handleCancelSelection() {
      this.selectionMode = false;
      this.selectedSkus = [];
    }
    async handleCompare() {
      if (this.selectedSkus.length < 2) {
        return;
      }
      const chosen = this.selectedSkus.map((sku) => this.productFor(sku)).filter((p) => !!p);
      const names = chosen.map((product2) => product2.name).join(" and ");
      const skus = chosen.map((product2) => product2.sku).join(",");
      const sent = await this.sendToAgent("Compare " + names + " (items " + skus + ")");
      if (sent) {
        this.selectionMode = false;
        this.selectedSkus = [];
      }
    }
    handleReply(event) {
      const index = Number(event.currentTarget.dataset.index);
      const reply = this.suggestedReplies[index];
      if (!reply) {
        return;
      }
      if (reply.action === "compareMode") {
        this.selectionMode = true;
        return;
      }
      this.sendToAgent(reply.text || reply.label);
    }
    productFor(sku) {
      return this.rawProducts.find((product2) => product2.sku === sku);
    }
    // Enhanced Chat v2 injects the supported message API into this component.
    async sendToAgent(text) {
      if (this.sending) return false;
      this.sendError = "";
      const util = this.configuration?.util;
      if (typeof util?.sendTextMessage !== "function") {
        this.sendError = "Please type this in the chat: " + text;
        return false;
      }
      this.sending = true;
      try {
        await util.sendTextMessage(text);
        return true;
      } catch (error) {
        this.sendError = "Your message could not be sent. Please try again or type it in the chat.";
        return false;
      } finally {
        this.sending = false;
      }
    }
    /*LWC compiler v9.2.0*/
  };
  registerDecorators(ProductCarouselWidget, {
    publicProps: {
      summaryMessage: {
        config: 0
      },
      responsePayload: {
        config: 0
      },
      value: {
        config: 0
      },
      configuration: {
        config: 0
      }
    },
    fields: ["sendError", "sending", "parsedPayload", "selectedSkus", "selectionMode", "openMenuSku", "failedImageSkus", "_lastStateKey"]
  });
  var __lwc_component_class_internal = registerComponent(ProductCarouselWidget, {
    tmpl: productCarouselWidget_default2,
    sel: "c-product-carousel-widget",
    apiVersion: 66
  });
  var productCarouselWidget_default3 = __lwc_component_class_internal;

  // Holly_Production_Candidate/force-app/main/default/lwc/orderSearchWidget/orderSearchWidget.css
  function stylesheet2(token, useActualHostSelector, useNativeDirPseudoclass) {
    var shadowSelector = token ? "[" + token + "]" : "";
    var hostSelector = token ? "[" + token + "-host]" : "";
    var suffixToken = token ? "-" + token : "";
    return [".widget", shadowSelector, " {background: transparent;border: 0;border-radius: 0;color: #241a3a;font-family: inherit;font-size: 0.84rem;line-height: 1.4;padding: 0;}.file-input", shadowSelector, " {display: none;}.empty-state", shadowSelector, " {align-items: flex-start;background: linear-gradient(180deg, #fff8ee, #fff1db);border: 1px solid #f0cb8f;border-radius: 16px;box-shadow: 0 10px 24px rgba(173, 116, 31, 0.1);display: grid;gap: 0.55rem;grid-template-columns: auto 1fr;margin-bottom: 0.7rem;padding: 0.8rem 0.9rem;}.empty-state__icon", shadowSelector, " {align-items: center;background: linear-gradient(135deg, #f1a63e, #d9861c);border-radius: 999px;color: #fff;display: inline-flex;font-size: 0.78rem;font-weight: 700;height: 1.45rem;justify-content: center;width: 1.45rem;}.empty-state__title", shadowSelector, ",.empty-state__message", shadowSelector, " {margin: 0;}.empty-state__title", shadowSelector, " {color: #664019;font-size: 0.82rem;font-weight: 700;}.empty-state__message", shadowSelector, " {color: #7b5227;margin-top: 0.1rem;}.order-list", shadowSelector, " {display: grid;gap: 0.75rem;}.summary-card", shadowSelector, " {background: #fff;border: 1px solid #ddd6ea;border-radius: 16px;box-shadow: none;margin-bottom: 0.7rem;padding: 0.82rem 0.9rem;}.summary-card__text", shadowSelector, " {color: #241a3a;font-size: 0.84rem;line-height: 1.5;margin: 0;}.summary-card__text", shadowSelector, " strong", shadowSelector, " {font-weight: 700;}.order-entry", shadowSelector, " {display: grid;gap: 0.5rem;}.order-button", shadowSelector, " {align-items: center;background: #fff;border: 1px solid #ddd6ea;border-radius: 16px;box-shadow: none;color: inherit;cursor: pointer;display: flex;font: inherit;justify-content: space-between;padding: 0.8rem 0.88rem;text-align: left;transition: transform 120ms ease, box-shadow 120ms ease, border-color 120ms ease, background 120ms ease;}.order-button:hover", shadowSelector, " {border-color: #604099;box-shadow: 0 12px 24px rgba(72, 104, 173, 0.16);transform: translateY(-1px);}.order-button--selected", shadowSelector, " {background: #604099;border-color: #604099;box-shadow: 0 12px 26px rgba(87, 97, 207, 0.24);color: #fff;}.order-button__primary", shadowSelector, ",.order-summary-row__primary", shadowSelector, " {align-items: flex-start;display: flex;flex-direction: column;gap: 0.12rem;min-width: 0;overflow: hidden;}.order-button__eyebrow", shadowSelector, " {color: #6b6480;font-size: 0.63rem;font-weight: 700;letter-spacing: 0.08em;text-transform: uppercase;}.order-button--selected", shadowSelector, " .order-button__eyebrow", shadowSelector, ",.order-button--selected", shadowSelector, " .order-button__date", shadowSelector, " {color: rgba(255, 255, 255, 0.82);}.order-button__number", shadowSelector, " {font-size: 0.92rem;font-weight: 700;}.order-button", shadowSelector, " .pill", shadowSelector, " {margin-left: 0.7rem;}.order-button__date", shadowSelector, " {color: #6b6480;font-size: 0.72rem;white-space: nowrap;}.detail-card", shadowSelector, " {background: #fff;border: 1px solid #ddd6ea;border-radius: 18px;box-shadow: none;padding: 0.85rem;}.detail-card--inline", shadowSelector, " {margin-left: 0.15rem;}.detail-card--single", shadowSelector, " {display: grid;gap: 0.75rem;}.order-summary-row", shadowSelector, " {align-items: center;display: flex;gap: 0.7rem;justify-content: space-between;padding-bottom: 0.7rem;}.action-panel", shadowSelector, " {border-top: 1px solid #ddd6ea;margin-top: 0.15rem;padding-top: 0.75rem;}.action-panel__header", shadowSelector, " {align-items: center;display: flex;flex-wrap: wrap;gap: 0.55rem;justify-content: space-between;}.action-panel__title", shadowSelector, " {color: #604099;font-size: 0.8rem;font-weight: 700;margin: 0;}.action-panel__buttons", shadowSelector, " {display: flex;gap: 0.42rem;justify-content: flex-end;}.notice-card", shadowSelector, " {align-items: flex-start;background: #fff;border: 1px solid #ddd6ea;border-radius: 16px;box-shadow: none;display: flex;flex-direction: column;gap: 0.55rem;margin-top: 0.75rem;padding: 0.8rem 0.86rem;}.notice-card__message", shadowSelector, " {color: #241a3a;margin: 0;}.notice-card__eyebrow", shadowSelector, " {color: #6b6480;font-size: 0.63rem;font-weight: 700;letter-spacing: 0.08em;margin: 0;text-transform: uppercase;}.notice-card__actions", shadowSelector, " {display: flex;flex-wrap: wrap;gap: 0.5rem;}.shipment-card", shadowSelector, " {background: #fff;border: 1px solid #ddd6ea;border-radius: 16px;box-shadow: none;margin-top: 0.7rem;padding: 0.8rem;}.shipment-card__header", shadowSelector, ",.item-row", shadowSelector, " {align-items: flex-start;display: flex;gap: 0.7rem;justify-content: space-between;}.shipment-card__header", shadowSelector, " {border-bottom: 1px solid #ddd6ea;margin-bottom: 0.75rem;padding-bottom: 0.65rem;}.shipment-card", shadowSelector, " h3", shadowSelector, " {color: #241a3a;font-size: 0.88rem;margin: 0;}.multi-ship", shadowSelector, ",.info", shadowSelector, " {color: #6b6480;font-size: 0.76rem;margin: 0.24rem 0 0;}.detail-grid", shadowSelector, " {display: grid;gap: 0.75rem;grid-template-columns: repeat(auto-fit, minmax(124px, 1fr));margin: 0.85rem 0;}.label", shadowSelector, " {color: #6b6480;font-size: 0.63rem;font-weight: 700;letter-spacing: 0.06em;margin: 0 0 0.12rem;text-transform: uppercase;}.label--subtle", shadowSelector, " {margin-top: 0.4rem;}.carrier-value", shadowSelector, " {color: #241a3a;margin: 0 0 0.35rem;}.tracking-block", shadowSelector, " {margin-top: 0.4rem;}.tracking-link", shadowSelector, " {color: #604099;display: inline-block;max-width: 100%;overflow-wrap: normal;white-space: nowrap;word-break: normal;}.tracking-link--text", shadowSelector, " {margin: 0;}.pill", shadowSelector, " {background: #604099;border-radius: 999px;color: #ffffff;display: inline-block;font-size: 0.64rem;padding: 0.2rem 0.5rem;}.pill-success", shadowSelector, " {background: linear-gradient(135deg, #2fbf71, #1da769);}.pill-info", shadowSelector, " {background: #604099;}.pill-warning", shadowSelector, " {background: linear-gradient(135deg, #ffb24a, #ff8f1f);}.pill-error", shadowSelector, " {background: linear-gradient(135deg, #ef5a5a, #d43c3c);}.pill-neutral", shadowSelector, " {background: linear-gradient(135deg, #8d98b0, #6f7c97);}.items", shadowSelector, " {margin-top: 0.65rem;}.items__label", shadowSelector, " {margin-bottom: 0.5rem;}.item-row", shadowSelector, " {border-top: 1px solid #ddd6ea;padding: 0.65rem 0;}.item-row__details", shadowSelector, " {flex: 1 1 auto;min-width: 0;}.item-row__details", shadowSelector, " p", shadowSelector, ",.detail-grid", shadowSelector, " p", shadowSelector, " {margin: 0;}.item-row__details", shadowSelector, " p", shadowSelector, " {color: #241a3a;font-weight: 400;line-height: 1.36;}.item-row__qty", shadowSelector, " {color: #6b6480;display: flex;flex-direction: column;font-size: 0.72rem;gap: 0.22rem;min-width: 78px;text-align: right;}.action-button", shadowSelector, " {border: 0;border-radius: 999px;cursor: pointer;font: inherit;font-size: 0.72rem;font-weight: 700;min-width: 70px;padding: 0.38rem 0.66rem;transition: transform 120ms ease, box-shadow 120ms ease, opacity 120ms ease;white-space: nowrap;}.action-button:hover:not(:disabled)", shadowSelector, " {box-shadow: 0 6px 14px rgba(87, 65, 124, 0.12);transform: translateY(-1px);}.action-button:disabled", shadowSelector, " {cursor: not-allowed;opacity: 1;}.action-button--return", shadowSelector, " {background: #604099;color: #fff;}.action-button--cancel", shadowSelector, " {background: linear-gradient(135deg, #ff9f43, #ff7a22);color: #fff;}.action-button--secondary", shadowSelector, " {background: linear-gradient(180deg, #f1f2f7, #e8ebf2);color: #49576a;}.action-button--disabled", shadowSelector, " {background: #d7dde4;color: #7a8796;}.show-more-button", shadowSelector, " {background: #fff;border: 1px solid #ddd6ea;border-radius: 999px;box-shadow: none;color: #604099;cursor: pointer;font: inherit;font-weight: 700;margin-top: 0.2rem;padding: 0.5rem 0.82rem;text-decoration: none;}a", shadowSelector, " {color: #604099;}@media (max-width: 420px) {.order-button", shadowSelector, ", .detail-card", shadowSelector, ", .notice-card", shadowSelector, ", .shipment-card", shadowSelector, ", .empty-state", shadowSelector, " {border-radius: 14px;}.order-button", shadowSelector, ", .detail-card", shadowSelector, " {padding-left: 0.8rem;padding-right: 0.8rem;}.order-summary-row", shadowSelector, ", .shipment-card__header", shadowSelector, " {gap: 0.5rem;}.detail-grid", shadowSelector, " {grid-template-columns: 1fr;}.item-row", shadowSelector, " {gap: 0.5rem;}.item-row__qty", shadowSelector, " {min-width: 68px;}}.order-button__eyebrow", shadowSelector, "{color:#604099;font-size:14px;letter-spacing:normal;text-transform:none}.label", shadowSelector, ",.notice-card__eyebrow", shadowSelector, "{color:#6b6480;font-size:13px;font-weight:400;letter-spacing:normal;text-transform:none}.shipment-card", shadowSelector, " h3", shadowSelector, "{color:#604099}.carrier-value", shadowSelector, ",.tracking-link--text", shadowSelector, "{color:#241a3a}.tracking-link", shadowSelector, "{color:#604099;text-decoration:underline;white-space:normal;overflow-wrap:anywhere}.order-button:focus-visible", shadowSelector, ",.show-more-button:focus-visible", shadowSelector, ",a:focus-visible", shadowSelector, "{outline:3px solid #a68bd4;outline-offset:3px}"].join("");
  }
  var orderSearchWidget_default = [stylesheet2];

  // Holly_Production_Candidate/force-app/main/default/lwc/orderSearchWidget/orderSearchWidget.html
  var $fragment110 = parseFragment`<p role="alert"${3}>Your order details could not be displayed. Please ask Holly to try again.</p>`;
  var $fragment22 = parseFragment`<section class="notice-card notice-card--after-details${0}"${2}><p class="notice-card__message${0}"${2}>${"t2"}</p></section>`;
  var $fragment32 = parseFragment`<span class="order-button__eyebrow${0}"${2}>Order</span>`;
  var $fragment42 = parseFragment`<span class="order-button__number${0}"${2}>${"t1"}</span>`;
  var $fragment52 = parseFragment`<span class="order-button__date${0}"${2}>${"t1"}</span>`;
  var $fragment62 = parseFragment`<span${"c0"}${2}>${"t1"}</span>`;
  var $fragment72 = parseFragment`<p class="multi-ship${0}"${2}>${"t1"}</p>`;
  var $fragment82 = parseFragment`<h3${3}>${"t1"}</h3>`;
  var $fragment92 = parseFragment`<span${"c0"}${2}>${"t1"}</span>`;
  var $fragment102 = parseFragment`<p class="label${0}"${2}>Carrier</p>`;
  var $fragment112 = parseFragment`<p class="carrier-value${0}"${2}>${"t1"}</p>`;
  var $fragment122 = parseFragment`<p class="label label--subtle${0}"${2}>Tracking Number</p>`;
  var $fragment132 = parseFragment`<a class="tracking-link${0}"${"a0:href"} target="_blank" rel="noopener noreferrer"${2}>${"t1"}</a>`;
  var $fragment142 = parseFragment`<p class="tracking-link tracking-link--text${0}"${2}>${"t1"}</p>`;
  var $fragment152 = parseFragment`<div${3}><p class="label${0}"${2}>Shipped Date</p><p${3}>${"t4"}</p></div>`;
  var $fragment162 = parseFragment`<div${3}><p class="label${0}"${2}>Arrival Date Range</p><p${3}>${"t4"}</p></div>`;
  var $fragment172 = parseFragment`<div${3}><p class="label${0}"${2}>Estimated Arrival</p><p${3}>${"t4"}</p></div>`;
  var $fragment182 = parseFragment`<div${3}><p class="label${0}"${2}>Delivered</p><p${3}>${"t4"}</p></div>`;
  var $fragment192 = parseFragment`<div${3}><p class="label${0}"${2}>Ship Method</p><p${3}>${"t4"}</p></div>`;
  var $fragment202 = parseFragment`<p class="info${0}"${2}>${"t1"}</p>`;
  var $fragment212 = parseFragment`<p class="label items__label${0}"${2}>Items</p>`;
  var $fragment222 = parseFragment`<div class="item-row__details${0}"${2}><p${3}>${"t2"}</p></div>`;
  var $fragment23 = parseFragment`<span${3}>${"t1"}</span>`;
  var $fragment24 = parseFragment`<h3${3}>Pickup Items</h3>`;
  var $fragment25 = parseFragment`<span${"c0"}${2}>${"t1"}</span>`;
  var $fragment26 = parseFragment`<div${3}><p class="label${0}"${2}>Store</p><p${3}>${"t4"}</p></div>`;
  var $fragment27 = parseFragment`<div${3}><p class="label${0}"${2}>Store Address</p><p${3}>${"t4"}</p></div>`;
  var $fragment28 = parseFragment`<div${3}><p class="label${0}"${2}>Store Phone</p><p${3}>${"t4"}</p></div>`;
  var $fragment29 = parseFragment`<p class="label${0}"${2}>Items</p>`;
  var $fragment30 = parseFragment`<div class="item-row__details${0}"${2}><p${3}>${"t2"}</p></div>`;
  var $fragment31 = parseFragment`<span${3}>${"t1"}</span>`;
  var $fragment322 = parseFragment`<p class="info${0}"${2}>Shipment details are not available yet for this order.</p>`;
  var $fragment33 = parseFragment`<section class="notice-card notice-card--after-details${0}"${2}><p${3}>Please continue this request with Holly in the chat.</p></section>`;
  var $fragment34 = parseFragment`<section class="notice-card notice-card--after-details${0}"${2}><p class="notice-card__message${0}"${2}>${"t2"}</p></section>`;
  var $fragment35 = parseFragment`<section class="notice-card notice-card--after-details${0}"${2}><p class="notice-card__message${0}"${2}>${"t2"}</p></section>`;
  var $fragment36 = parseFragment`<button class="show-more-button${0}"${2}>${"t1"}</button>`;
  var $fragment37 = parseFragment`<span class="order-button__eyebrow${0}"${2}>Order</span>`;
  var $fragment38 = parseFragment`<span class="order-button__number${0}"${2}>${"t1"}</span>`;
  var $fragment39 = parseFragment`<span class="order-button__date${0}"${2}>${"t1"}</span>`;
  var $fragment40 = parseFragment`<p class="multi-ship${0}"${2}>${"t1"}</p>`;
  var $fragment41 = parseFragment`<h3${3}>${"t1"}</h3>`;
  var $fragment422 = parseFragment`<span${"c0"}${2}>${"t1"}</span>`;
  var $fragment43 = parseFragment`<p class="label${0}"${2}>Carrier</p>`;
  var $fragment44 = parseFragment`<p class="carrier-value${0}"${2}>${"t1"}</p>`;
  var $fragment45 = parseFragment`<p class="label label--subtle${0}"${2}>Tracking Number</p>`;
  var $fragment46 = parseFragment`<a class="tracking-link${0}"${"a0:href"} target="_blank" rel="noopener noreferrer"${2}>${"t1"}</a>`;
  var $fragment47 = parseFragment`<p class="tracking-link tracking-link--text${0}"${2}>${"t1"}</p>`;
  var $fragment48 = parseFragment`<div${3}><p class="label${0}"${2}>Shipped Date</p><p${3}>${"t4"}</p></div>`;
  var $fragment49 = parseFragment`<div${3}><p class="label${0}"${2}>Arrival Date Range</p><p${3}>${"t4"}</p></div>`;
  var $fragment50 = parseFragment`<div${3}><p class="label${0}"${2}>Estimated Arrival</p><p${3}>${"t4"}</p></div>`;
  var $fragment51 = parseFragment`<div${3}><p class="label${0}"${2}>Delivered</p><p${3}>${"t4"}</p></div>`;
  var $fragment522 = parseFragment`<div${3}><p class="label${0}"${2}>Ship Method</p><p${3}>${"t4"}</p></div>`;
  var $fragment53 = parseFragment`<p class="info${0}"${2}>${"t1"}</p>`;
  var $fragment54 = parseFragment`<p class="label items__label${0}"${2}>Items</p>`;
  var $fragment55 = parseFragment`<div class="item-row__details${0}"${2}><p${3}>${"t2"}</p></div>`;
  var $fragment56 = parseFragment`<span${3}>${"t1"}</span>`;
  var $fragment57 = parseFragment`<h3${3}>Pickup Items</h3>`;
  var $fragment58 = parseFragment`<span${"c0"}${2}>${"t1"}</span>`;
  var $fragment59 = parseFragment`<div${3}><p class="label${0}"${2}>Store</p><p${3}>${"t4"}</p></div>`;
  var $fragment60 = parseFragment`<div${3}><p class="label${0}"${2}>Store Address</p><p${3}>${"t4"}</p></div>`;
  var $fragment61 = parseFragment`<div${3}><p class="label${0}"${2}>Store Phone</p><p${3}>${"t4"}</p></div>`;
  var $fragment622 = parseFragment`<p class="label items__label${0}"${2}>Items</p>`;
  var $fragment63 = parseFragment`<div class="item-row__details${0}"${2}><p${3}>${"t2"}</p></div>`;
  var $fragment64 = parseFragment`<span${3}>${"t1"}</span>`;
  var $fragment65 = parseFragment`<p class="info${0}"${2}>Shipment details are not available yet for this order.</p>`;
  var $fragment66 = parseFragment`<section class="notice-card notice-card--after-details${0}"${2}><p${3}>Please continue this request with Holly in the chat.</p></section>`;
  var $fragment67 = parseFragment`<section class="notice-card notice-card--after-details${0}"${2}><p class="notice-card__message${0}"${2}>${"t2"}</p></section>`;
  var $fragment68 = parseFragment`<section class="notice-card notice-card--after-details${0}"${2}><p class="notice-card__message${0}"${2}>${"t2"}</p></section>`;
  var stc02 = {
    classMap: {
      "widget": true
    },
    key: 3
  };
  var stc17 = {
    classMap: {
      "order-list": true
    },
    key: 6
  };
  var stc22 = {
    "order-entry": true
  };
  var stc32 = {
    classMap: {
      "order-button__primary": true
    },
    key: 12
  };
  var stc42 = {
    classMap: {
      "detail-card": true,
      "detail-card--inline": true
    },
    key: 24
  };
  var stc52 = {
    "shipment-card": true
  };
  var stc62 = {
    classMap: {
      "shipment-card__header": true
    },
    key: 30
  };
  var stc72 = {
    classMap: {
      "detail-grid": true
    },
    key: 36
  };
  var stc82 = {
    key: 38
  };
  var stc92 = {
    classMap: {
      "tracking-block": true
    },
    key: 44
  };
  var stc102 = {
    classMap: {
      "items": true
    },
    key: 71
  };
  var stc112 = {
    "item-row": true
  };
  var stc122 = {
    classMap: {
      "item-row__qty": true
    },
    key: 77
  };
  var stc132 = {
    classMap: {
      "shipment-card": true
    },
    key: 82
  };
  var stc142 = {
    classMap: {
      "shipment-card__header": true
    },
    key: 83
  };
  var stc152 = {
    classMap: {
      "detail-grid": true
    },
    key: 90
  };
  var stc162 = {
    classMap: {
      "items": true
    },
    key: 100
  };
  var stc172 = {
    classMap: {
      "item-row__qty": true
    },
    key: 106
  };
  var stc18 = {
    classMap: {
      "detail-card": true,
      "detail-card--single": true
    },
    key: 126
  };
  var stc19 = {
    classMap: {
      "order-summary-row": true
    },
    key: 127
  };
  var stc20 = {
    classMap: {
      "order-summary-row__primary": true
    },
    key: 128
  };
  var stc21 = {
    classMap: {
      "shipment-card__header": true
    },
    key: 141
  };
  var stc222 = {
    classMap: {
      "detail-grid": true
    },
    key: 147
  };
  var stc23 = {
    key: 149
  };
  var stc24 = {
    classMap: {
      "tracking-block": true
    },
    key: 155
  };
  var stc25 = {
    classMap: {
      "items": true
    },
    key: 182
  };
  var stc26 = {
    classMap: {
      "item-row__qty": true
    },
    key: 188
  };
  var stc27 = {
    classMap: {
      "shipment-card": true
    },
    key: 193
  };
  var stc28 = {
    classMap: {
      "shipment-card__header": true
    },
    key: 194
  };
  var stc29 = {
    classMap: {
      "detail-grid": true
    },
    key: 201
  };
  var stc30 = {
    classMap: {
      "items": true
    },
    key: 211
  };
  var stc31 = {
    classMap: {
      "item-row__qty": true
    },
    key: 217
  };
  function tmpl2($api, $cmp, $slotset, $ctx) {
    const { st: api_static_fragment, fr: api_fragment, d: api_dynamic_text, sp: api_static_part, k: api_key, ncls: api_normalize_class_name, b: api_bind, h: api_element, i: api_iterator, f: api_flatten } = $api;
    const { _m0, _m1, _m2 } = $ctx;
    return [$cmp.isErrorView ? api_fragment(0, [api_static_fragment($fragment110, 2)], 0) : null, api_element("section", stc02, [$cmp.hasPayload ? api_fragment(4, [$cmp.showOrderList ? api_fragment(5, [api_element("div", stc17, api_flatten([$cmp.showMultiOrderPrompt ? api_fragment(7, [api_static_fragment($fragment22, 9, [api_static_part(2, null, api_dynamic_text($cmp.multiOrderPromptMessage))])], 0) : null, api_iterator($cmp.displayedOrders, function(order) {
      return api_element("article", {
        classMap: stc22,
        key: api_key(10, order.key)
      }, [api_element("button", {
        className: api_normalize_class_name(order.buttonClass),
        attrs: {
          "data-order-number": order.orderNumber
        },
        key: 11,
        on: _m0 || ($ctx._m0 = {
          "click": api_bind($cmp.handleSelectOrder)
        })
      }, [api_element("span", stc32, [api_static_fragment($fragment32, 14), api_static_fragment($fragment42, 16, [api_static_part(1, null, "#" + api_dynamic_text(order.orderNumber))]), order.orderDate ? api_fragment(17, [api_static_fragment($fragment52, 19, [api_static_part(1, null, api_dynamic_text(order.orderDate))])], 0) : null]), order.showHeaderStatus ? api_fragment(20, [api_static_fragment($fragment62, 22, [api_static_part(0, {
        className: api_normalize_class_name(order.statusClass)
      }, null), api_static_part(1, null, api_dynamic_text(order.displayStatusText))])], 0) : null]), order.isSelected ? api_fragment(23, [api_element("article", stc42, [order.multipleShipments ? api_fragment(25, [api_static_fragment($fragment72, 27, [api_static_part(1, null, "This order includes " + api_dynamic_text(order.shipmentCount) + " shipments.")])], 0) : null, order.hasShipments ? api_fragment(28, api_iterator(order.shipments, function(shipment) {
        return api_element("section", {
          classMap: stc52,
          key: api_key(29, shipment.key)
        }, [api_element("div", stc62, [api_static_fragment($fragment82, 32, [api_static_part(1, null, api_dynamic_text(shipment.shipmentLabel))]), shipment.status ? api_fragment(33, [api_static_fragment($fragment92, 35, [api_static_part(0, {
          className: api_normalize_class_name(shipment.statusClass)
        }, null), api_static_part(1, null, api_dynamic_text(shipment.status))])], 0) : null]), api_element("div", stc72, [shipment.carrier ? api_fragment(37, [api_element("div", stc82, [api_static_fragment($fragment102, 40), api_static_fragment($fragment112, 42, [api_static_part(1, null, api_dynamic_text(shipment.carrier))]), shipment.trackingNumber ? api_fragment(43, [api_element("div", stc92, [api_static_fragment($fragment122, 46), shipment.trackingUrl ? api_fragment(47, [api_static_fragment($fragment132, 49, [api_static_part(0, {
          attrs: {
            "href": shipment.trackingUrl
          }
        }, null), api_static_part(1, null, api_dynamic_text(shipment.trackingNumber))])], 0) : api_fragment(47, [api_static_fragment($fragment142, 51, [api_static_part(1, null, api_dynamic_text(shipment.trackingNumber))])], 0)])], 0) : null])], 0) : null, shipment.shippedDate ? api_fragment(52, [api_static_fragment($fragment152, 54, [api_static_part(4, null, api_dynamic_text(shipment.shippedDate))])], 0) : null, shipment.arrivalDateRange ? api_fragment(55, [api_static_fragment($fragment162, 57, [api_static_part(4, null, api_dynamic_text(shipment.arrivalDateRange))])], 0) : null, shipment.estimatedDelivery ? api_fragment(58, [api_static_fragment($fragment172, 60, [api_static_part(4, null, api_dynamic_text(shipment.estimatedDelivery))])], 0) : null, shipment.actualDelivery ? api_fragment(61, [api_static_fragment($fragment182, 63, [api_static_part(4, null, api_dynamic_text(shipment.actualDelivery))])], 0) : null, shipment.shipMethod ? api_fragment(64, [api_static_fragment($fragment192, 66, [api_static_part(4, null, api_dynamic_text(shipment.shipMethod))])], 0) : null]), shipment.noTrackingMessage ? api_fragment(67, [api_static_fragment($fragment202, 69, [api_static_part(1, null, api_dynamic_text(shipment.noTrackingMessage))])], 0) : null, shipment.items ? api_fragment(70, [api_element("div", stc102, api_flatten([api_static_fragment($fragment212, 73), api_iterator(shipment.items, function(item) {
          return api_element("div", {
            classMap: stc112,
            key: api_key(74, item.key)
          }, [api_static_fragment($fragment222, 76, [api_static_part(2, null, api_dynamic_text(item.description))]), api_element("div", stc122, [item.quantity ? api_fragment(78, [api_static_fragment($fragment23, 80, [api_static_part(1, null, "Quantity: " + api_dynamic_text(item.quantity))])], 0) : null])]);
        })]))], 0) : null]);
      }), 0) : null, order.hasPickupItems ? api_fragment(81, [api_element("section", stc132, [api_element("div", stc142, [api_static_fragment($fragment24, 85), order.bopisStatus ? api_fragment(86, [api_static_fragment($fragment25, 88, [api_static_part(0, {
        className: api_normalize_class_name(order.pickupStatusClass)
      }, null), api_static_part(1, null, api_dynamic_text(order.bopisStatus))])], 0) : null]), order.hasPickupStore ? api_fragment(89, [api_element("div", stc152, [order.pickupStore.storeInfo ? api_fragment(91, [api_static_fragment($fragment26, 93, [api_static_part(4, null, api_dynamic_text(order.pickupStore.storeInfo))])], 0) : null, order.pickupStore.storeAddress ? api_fragment(94, [api_static_fragment($fragment27, 96, [api_static_part(4, null, api_dynamic_text(order.pickupStore.storeAddress))])], 0) : null, order.pickupStore.storePhone ? api_fragment(97, [api_static_fragment($fragment28, 99, [api_static_part(4, null, api_dynamic_text(order.pickupStore.storePhone))])], 0) : null])], 0) : null, api_element("div", stc162, api_flatten([api_static_fragment($fragment29, 102), api_iterator(order.pickupItems, function(item) {
        return api_element("div", {
          classMap: stc112,
          key: api_key(103, item.key)
        }, [api_static_fragment($fragment30, 105, [api_static_part(2, null, api_dynamic_text(item.description))]), api_element("div", stc172, [item.quantity ? api_fragment(107, [api_static_fragment($fragment31, 109, [api_static_part(1, null, "Quantity: " + api_dynamic_text(item.quantity))])], 0) : null])]);
      })]))])], 0) : null, order.hasNoFulfillmentDetails ? api_fragment(110, [api_static_fragment($fragment322, 112)], 0) : null, $cmp.showOrderCaseForm ? api_fragment(113, [api_static_fragment($fragment33, 115)], 0) : null, $cmp.showSelectedOrderPrompt ? api_fragment(116, [api_static_fragment($fragment34, 118, [api_static_part(2, null, api_dynamic_text($cmp.singleOrderPromptMessage))])], 0) : null, $cmp.showReturnItemLimitMessage ? api_fragment(119, [api_static_fragment($fragment35, 121, [api_static_part(2, null, api_dynamic_text($cmp.returnItemLimitMessage))])], 0) : null])], 0) : null]);
    })])), $cmp.canShowMoreOrders ? api_fragment(122, [api_static_fragment($fragment36, 124, [api_static_part(0, {
      on: _m2 || ($ctx._m2 = {
        "click": api_bind($cmp.handleShowMore)
      })
    }, null), api_static_part(1, null, api_dynamic_text($cmp.showMoreLabel))])], 0) : null], 0) : null, $cmp.showSingleOrderDetail ? api_fragment(125, [api_element("article", stc18, [api_element("div", stc19, [api_element("div", stc20, [api_static_fragment($fragment37, 130), api_static_fragment($fragment38, 132, [api_static_part(1, null, "#" + api_dynamic_text($cmp.detailOrder.orderNumber))]), $cmp.detailOrder.orderDate ? api_fragment(133, [api_static_fragment($fragment39, 135, [api_static_part(1, null, api_dynamic_text($cmp.detailOrder.orderDate))])], 0) : null])]), $cmp.detailOrder.multipleShipments ? api_fragment(136, [api_static_fragment($fragment40, 138, [api_static_part(1, null, "This order includes " + api_dynamic_text($cmp.detailOrder.shipmentCount) + " shipments.")])], 0) : null, $cmp.detailOrder.hasShipments ? api_fragment(139, api_iterator($cmp.detailOrder.shipments, function(shipment) {
      return api_element("section", {
        classMap: stc52,
        key: api_key(140, shipment.key)
      }, [api_element("div", stc21, [api_static_fragment($fragment41, 143, [api_static_part(1, null, api_dynamic_text(shipment.shipmentLabel))]), shipment.status ? api_fragment(144, [api_static_fragment($fragment422, 146, [api_static_part(0, {
        className: api_normalize_class_name(shipment.statusClass)
      }, null), api_static_part(1, null, api_dynamic_text(shipment.status))])], 0) : null]), api_element("div", stc222, [shipment.carrier ? api_fragment(148, [api_element("div", stc23, [api_static_fragment($fragment43, 151), api_static_fragment($fragment44, 153, [api_static_part(1, null, api_dynamic_text(shipment.carrier))]), shipment.trackingNumber ? api_fragment(154, [api_element("div", stc24, [api_static_fragment($fragment45, 157), shipment.trackingUrl ? api_fragment(158, [api_static_fragment($fragment46, 160, [api_static_part(0, {
        attrs: {
          "href": shipment.trackingUrl
        }
      }, null), api_static_part(1, null, api_dynamic_text(shipment.trackingNumber))])], 0) : api_fragment(158, [api_static_fragment($fragment47, 162, [api_static_part(1, null, api_dynamic_text(shipment.trackingNumber))])], 0)])], 0) : null])], 0) : null, shipment.shippedDate ? api_fragment(163, [api_static_fragment($fragment48, 165, [api_static_part(4, null, api_dynamic_text(shipment.shippedDate))])], 0) : null, shipment.arrivalDateRange ? api_fragment(166, [api_static_fragment($fragment49, 168, [api_static_part(4, null, api_dynamic_text(shipment.arrivalDateRange))])], 0) : null, shipment.estimatedDelivery ? api_fragment(169, [api_static_fragment($fragment50, 171, [api_static_part(4, null, api_dynamic_text(shipment.estimatedDelivery))])], 0) : null, shipment.actualDelivery ? api_fragment(172, [api_static_fragment($fragment51, 174, [api_static_part(4, null, api_dynamic_text(shipment.actualDelivery))])], 0) : null, shipment.shipMethod ? api_fragment(175, [api_static_fragment($fragment522, 177, [api_static_part(4, null, api_dynamic_text(shipment.shipMethod))])], 0) : null]), shipment.noTrackingMessage ? api_fragment(178, [api_static_fragment($fragment53, 180, [api_static_part(1, null, api_dynamic_text(shipment.noTrackingMessage))])], 0) : null, shipment.items ? api_fragment(181, [api_element("div", stc25, api_flatten([api_static_fragment($fragment54, 184), api_iterator(shipment.items, function(item) {
        return api_element("div", {
          classMap: stc112,
          key: api_key(185, item.key)
        }, [api_static_fragment($fragment55, 187, [api_static_part(2, null, api_dynamic_text(item.description))]), api_element("div", stc26, [item.quantity ? api_fragment(189, [api_static_fragment($fragment56, 191, [api_static_part(1, null, "Quantity: " + api_dynamic_text(item.quantity))])], 0) : null])]);
      })]))], 0) : null]);
    }), 0) : null, $cmp.detailOrder.hasPickupItems ? api_fragment(192, [api_element("section", stc27, [api_element("div", stc28, [api_static_fragment($fragment57, 196), $cmp.detailOrder.bopisStatus ? api_fragment(197, [api_static_fragment($fragment58, 199, [api_static_part(0, {
      className: api_normalize_class_name($cmp.detailOrder.pickupStatusClass)
    }, null), api_static_part(1, null, api_dynamic_text($cmp.detailOrder.bopisStatus))])], 0) : null]), $cmp.detailOrder.hasPickupStore ? api_fragment(200, [api_element("div", stc29, [$cmp.detailOrder.pickupStore.storeInfo ? api_fragment(202, [api_static_fragment($fragment59, 204, [api_static_part(4, null, api_dynamic_text($cmp.detailOrder.pickupStore.storeInfo))])], 0) : null, $cmp.detailOrder.pickupStore.storeAddress ? api_fragment(205, [api_static_fragment($fragment60, 207, [api_static_part(4, null, api_dynamic_text($cmp.detailOrder.pickupStore.storeAddress))])], 0) : null, $cmp.detailOrder.pickupStore.storePhone ? api_fragment(208, [api_static_fragment($fragment61, 210, [api_static_part(4, null, api_dynamic_text($cmp.detailOrder.pickupStore.storePhone))])], 0) : null])], 0) : null, api_element("div", stc30, api_flatten([api_static_fragment($fragment622, 213), api_iterator($cmp.detailOrder.pickupItems, function(item) {
      return api_element("div", {
        classMap: stc112,
        key: api_key(214, item.key)
      }, [api_static_fragment($fragment63, 216, [api_static_part(2, null, api_dynamic_text(item.description))]), api_element("div", stc31, [item.quantity ? api_fragment(218, [api_static_fragment($fragment64, 220, [api_static_part(1, null, "Quantity: " + api_dynamic_text(item.quantity))])], 0) : null])]);
    })]))])], 0) : null, $cmp.detailOrder.hasNoFulfillmentDetails ? api_fragment(221, [api_static_fragment($fragment65, 223)], 0) : null, $cmp.showOrderCaseForm ? api_fragment(224, [api_static_fragment($fragment66, 226)], 0) : null, $cmp.showSingleOrderPrompt ? api_fragment(227, [api_static_fragment($fragment67, 229, [api_static_part(2, null, api_dynamic_text($cmp.singleOrderPromptMessage))])], 0) : null, $cmp.showReturnItemLimitMessage ? api_fragment(230, [api_static_fragment($fragment68, 232, [api_static_part(2, null, api_dynamic_text($cmp.returnItemLimitMessage))])], 0) : null])], 0) : null], 0) : null])];
  }
  var orderSearchWidget_default2 = registerTemplate(tmpl2);
  tmpl2.stylesheets = [];
  tmpl2.stylesheetToken = "lwc-250uubr3ivf";
  tmpl2.legacyStylesheetToken = "c-orderSearchWidget_orderSearchWidget";
  if (orderSearchWidget_default) {
    tmpl2.stylesheets.push.apply(tmpl2.stylesheets, orderSearchWidget_default);
  }
  if (empty_default) {
    tmpl2.stylesheets.push.apply(tmpl2.stylesheets, empty_default);
  }
  freezeTemplate(tmpl2);

  // Holly_Production_Candidate/force-app/main/default/lwc/orderSearchWidget/orderSearchWidget.js
  var OrderSearchWidget = class _OrderSearchWidget extends LightningElement {
    constructor(...args) {
      super(...args);
      this.summaryMessage = "";
      this.responsePayload = "";
      this.value = void 0;
      this.parsedPayload = void 0;
      this.requestContext = "search";
      this.selectedOrderNumber = void 0;
      this.visibleOrderCount = _OrderSearchWidget.PAGE_SIZE;
      this.responseActionTaken = "";
      this.responseNeedsCaseOption = false;
      this.responseShouldCreateCase = false;
      this.responseCaseSubject = "";
      this.responseCaseReason = "";
      this.responseQueueName = "";
      this.responseWithinBusinessHours = null;
      this.responseSummaryMessage = "";
      this.responseMessagingSessionId = "";
    }
    connectedCallback() {
      this.parsePayload();
    }
    renderedCallback() {
      const stateKey = JSON.stringify(this.value || {}) + "|" + (this.responsePayload || "");
      if (this._lastStateKey !== stateKey) {
        this.parsePayload();
      }
    }
    parsePayload() {
      const rawValue = Array.isArray(this.value) ? this.value[0] : this.value;
      const sourceValue = rawValue && typeof rawValue === "object" ? rawValue : {};
      const typedValue = sourceValue.renderedResponse && typeof sourceValue.renderedResponse === "object" ? sourceValue.renderedResponse : sourceValue;
      const incomingPayload = typedValue.responsePayload !== void 0 ? typedValue.responsePayload : this.responsePayload;
      const explicitRequestType = typedValue && typedValue.requestType ? String(typedValue.requestType).toLowerCase() : "";
      this._lastStateKey = JSON.stringify(this.value || {}) + "|" + (this.responsePayload || "");
      this.parsedPayload = null;
      this.selectedOrderNumber = null;
      this.visibleOrderCount = _OrderSearchWidget.PAGE_SIZE;
      this.responseActionTaken = typedValue && typedValue.actionTaken ? typedValue.actionTaken : "";
      this.responseNeedsCaseOption = typedValue && typedValue.needsCaseOption === true;
      this.responseShouldCreateCase = typedValue && typedValue.shouldCreateCase === true;
      this.responseCaseSubject = typedValue && typedValue.caseSubject ? typedValue.caseSubject : "";
      this.responseCaseReason = typedValue && typedValue.caseReason ? typedValue.caseReason : "";
      this.responseQueueName = typedValue && typedValue.queueName ? typedValue.queueName : "";
      this.responseWithinBusinessHours = typedValue ? typedValue.withinBusinessHours : null;
      this.responseSummaryMessage = typedValue && typedValue.summaryMessage ? typedValue.summaryMessage : "";
      this.responseMessagingSessionId = typedValue && typedValue.messagingSessionId ? typedValue.messagingSessionId : "";
      this.requestContext = explicitRequestType === "return" || explicitRequestType === "cancel" || explicitRequestType === "missingpoints" ? explicitRequestType : "search";
      if (!incomingPayload) {
        return;
      }
      try {
        const parsed = typeof incomingPayload === "object" ? incomingPayload : JSON.parse(incomingPayload);
        const orders = (parsed.orders || []).map((order2) => this.decorateOrder(order2));
        const order = parsed.order ? this.decorateOrder(parsed.order) : null;
        this.parsedPayload = {
          ...parsed,
          orders,
          order
        };
        if (parsed.view === "orderDetail" && order && order.orderNumber) {
          this.selectedOrderNumber = order.orderNumber;
        }
      } catch (error) {
        this.parsedPayload = {
          view: "error",
          errorMessage: "The order response could not be rendered."
        };
      }
    }
    decorateOrder(order) {
      const displayStatus = this.resolveCollapsedStatus(order);
      const pickupStatusClass = this.statusClass(this.normalizeMeaningfulText(order.bopisStatus) || "Status unavailable");
      const shipments = (order.shipments || []).map((shipment, index) => ({
        ...shipment,
        trackingUrl: safeHttps(shipment.trackingUrl),
        ...this.decorateShipmentStatus(order, shipment),
        key: `${order.orderNumber || "order"}-${index + 1}`,
        items: (shipment.items || []).map((item, itemIndex) => ({
          ...item,
          key: `${order.orderNumber || "order"}-${index + 1}-${itemIndex + 1}`
        }))
      }));
      const pickupItems = (order.pickupItems || []).map((item, itemIndex) => ({
        ...item,
        key: item.key || `${order.orderNumber || "order"}-pickup-${itemIndex + 1}`
      }));
      const pickupStore = this.firstPickupStore(pickupItems);
      const canCancel = order.canCancel === true || this.requestContext === "cancel" && order.canCancel !== false;
      const canReturn = order.canReturn === true || this.requestContext === "return" && order.canReturn !== false;
      return {
        ...order,
        key: order.orderNumber,
        shipments,
        pickupItems,
        pickupStore,
        hasShipments: shipments.length > 0,
        hasPickupItems: pickupItems.length > 0,
        hasPickupStore: !!pickupStore,
        hasNoFulfillmentDetails: shipments.length === 0 && pickupItems.length === 0,
        displayStatus,
        displayStatusText: displayStatus,
        statusClass: this.statusClass(displayStatus),
        pickupStatusClass,
        buttonClass: this.selectedOrderNumber === order.orderNumber ? "order-button order-button--selected" : "order-button",
        isSelected: this.selectedOrderNumber === order.orderNumber,
        cancelDisabled: !canCancel,
        returnDisabled: !canReturn,
        returnButtonClass: canReturn ? "action-button action-button--return" : "action-button action-button--disabled",
        cancelButtonClass: canCancel ? "action-button action-button--cancel" : "action-button action-button--disabled"
      };
    }
    decorateShipmentStatus(order, shipment) {
      const status = this.resolveExpandedShipmentStatus(order, shipment);
      return {
        status,
        statusClass: this.statusClass(status || "Status unavailable")
      };
    }
    resolveCollapsedStatus(order) {
      return this.firstMeaningful(order.listStatus, order.orderStatus, order.status, order.order_status, this.deriveDisplayStatusFromShipments(order), order.bopisStatus) || "Status unavailable";
    }
    resolveExpandedShipmentStatus(order, shipment) {
      return this.firstMeaningful(shipment && shipment.status, shipment && shipment.displayStatusText, shipment && shipment.statusText, order.orderStatus, order.status, order.order_status, this.deriveDisplayStatusFromShipments(order), order.bopisStatus);
    }
    deriveDisplayStatusFromShipments(order) {
      const shipments = Array.isArray(order && order.shipments) ? order.shipments : [];
      if (!shipments.length) {
        return null;
      }
      const statuses = shipments.map((shipment) => this.normalizeMeaningfulText(shipment && (shipment.status || shipment.displayStatusText || shipment.statusText))).filter(Boolean).map((status) => status.toLowerCase());
      if (!statuses.length) {
        return null;
      }
      if (statuses.every((status) => status === "cancelled" || status === "canceled")) {
        return "Cancelled";
      }
      if (statuses.every((status) => status === "delivered")) {
        return "Delivered";
      }
      if (statuses.every((status) => status === "shipped" || status === "delivered")) {
        return statuses.includes("shipped") && statuses.includes("delivered") ? "Partially Delivered" : "Shipped";
      }
      if (statuses.some((status) => status === "shipped" || status === "delivered")) {
        return "Partially Shipped";
      }
      return statuses[0];
    }
    firstMeaningful(...values) {
      for (const value of values) {
        const normalized = this.normalizeMeaningfulText(value);
        if (normalized) {
          return normalized;
        }
      }
      return null;
    }
    normalizeMeaningfulText(value) {
      if (value === null || value === void 0) {
        return null;
      }
      const trimmed = String(value).trim();
      if (!trimmed) {
        return null;
      }
      const lowered = trimmed.toLowerCase();
      if (lowered === "not available" || lowered === "n/a" || lowered === "null" || lowered === "none") {
        return null;
      }
      return trimmed;
    }
    firstPickupStore(pickupItems) {
      const storeItem = (pickupItems || []).find((item) => item.storeInfo || item.storeAddress || item.storePhone);
      if (!storeItem) {
        return null;
      }
      return {
        storeInfo: storeItem.storeInfo,
        storeAddress: storeItem.storeAddress,
        storePhone: storeItem.storePhone
      };
    }
    statusClass(status) {
      const normalized = (status || "").toLowerCase();
      if (normalized === "shipped" || normalized === "delivered" || normalized === "fulfilled") {
        return "pill pill-success";
      }
      if (normalized === "released") {
        return "pill pill-info";
      }
      if (normalized === "picked up" || normalized === "ready for pickup") {
        return "pill pill-success";
      }
      if (normalized === "open" || normalized === "allocated") {
        return "pill pill-info";
      }
      if (normalized === "processing" || normalized === "backordered" || normalized === "partially fulfilled") {
        return "pill pill-warning";
      }
      if (normalized === "in process" || normalized === "partially shipped" || normalized === "partially delivered" || normalized === "some items ready for pick up") {
        return "pill pill-warning";
      }
      if (normalized === "cancelled" || normalized === "canceled") {
        return "pill pill-error";
      }
      if (normalized === "not available" || normalized === "status unavailable") {
        return "pill pill-neutral";
      }
      return "pill";
    }
    get isOrderList() {
      return this.parsedPayload && this.parsedPayload.view === "orderList";
    }
    get isOrderDetail() {
      return this.parsedPayload && this.parsedPayload.view === "orderDetail";
    }
    get isErrorView() {
      return this.parsedPayload && this.parsedPayload.view === "error";
    }
    get orderCards() {
      if (!this.parsedPayload) {
        return [];
      }
      if (this.isOrderList) {
        return this.parsedPayload.orders || [];
      }
      if (this.isOrderDetail && this.parsedPayload.order) {
        return [this.parsedPayload.order];
      }
      return [];
    }
    get hasOrders() {
      return this.orderCards.length > 0;
    }
    get hasPayload() {
      return this.hasOrders;
    }
    get showOrderList() {
      return this.isOrderList && this.hasOrders;
    }
    get showSingleOrderDetail() {
      return this.isOrderDetail && !!(this.parsedPayload && this.parsedPayload.order);
    }
    get displayedOrders() {
      return this.orderCards.slice(0, this.visibleOrderCount).map((order) => ({
        ...order,
        isSelected: this.selectedOrderNumber === order.orderNumber,
        showHeaderStatus: this.selectedOrderNumber !== order.orderNumber,
        buttonClass: this.selectedOrderNumber === order.orderNumber ? "order-button order-button--selected" : "order-button"
      }));
    }
    get canShowMoreOrders() {
      return this.orderCards.length > _OrderSearchWidget.PAGE_SIZE;
    }
    get showMoreLabel() {
      const totalCount = this.orderCards.length;
      if (this.visibleOrderCount < totalCount) {
        const nextCount = Math.min(this.visibleOrderCount + _OrderSearchWidget.PAGE_SIZE, totalCount);
        return "Show more orders (" + nextCount + " of " + totalCount + ")";
      }
      return "Show fewer orders (" + _OrderSearchWidget.PAGE_SIZE + " of " + totalCount + ")";
    }
    get detailOrder() {
      if (this.isOrderDetail) {
        return this.parsedPayload.order;
      }
      return (this.parsedPayload.orders || []).find((order) => order.orderNumber === this.selectedOrderNumber);
    }
    get isEmailOrPhoneSearch() {
      if (!this.parsedPayload) {
        return false;
      }
      const searchType = (this.parsedPayload.searchType || "").toLowerCase();
      return searchType === "email" || searchType === "phone";
    }
    get isMultiOrderSearchFlow() {
      return this.isOrderList && this.isEmailOrPhoneSearch && this.orderCards.length > 1;
    }
    get showOrderCaseForm() {
      return false;
    }
    get showReturnAction() {
      return this.requestContext === "return";
    }
    get showCancelAction() {
      return this.requestContext === "cancel";
    }
    get isMissingPointsFlow() {
      return this.requestContext === "missingpoints";
    }
    get showSingleOrderPrompt() {
      return this.isOrderDetail && !!this.detailOrder && !this.showOrderCaseForm && !this.isMultiOrderSearchFlow && !this.showReturnItemLimitMessage && (this.isMissingPointsFlow || this.isCancelledHeaderStatus);
    }
    get showSelectedOrderPrompt() {
      return this.isMultiOrderSearchFlow && !!this.selectedOrderNumber && !this.showOrderCaseForm && !this.showReturnItemLimitMessage && false;
    }
    get actionNoticeMessage() {
      if (this.isMissingPointsFlow) {
        return this.missingPointsMessageForAction(this.responseActionTaken, true);
      }
      return this.isCancelFlow ? "Please provide First name, Last name, email, impacted items, and outcome below to initiate the cancellation process." : "Please provide First name, Last name, email, impacted items, and outcome below to initiate the return process.";
    }
    get showMultiOrderPrompt() {
      return this.isMultiOrderSearchFlow && !this.selectedOrderNumber && (this.showReturnAction || this.showCancelAction || this.isMissingPointsFlow);
    }
    get multiOrderPromptMessage() {
      if (this.isMissingPointsFlow) {
        return "Please enter the order number from the list below so we can look up the missing points associated with that order.";
      }
      return this.requestContext === "cancel" ? "Please enter the order number from the list below to start the cancellation process." : "Please enter the order number from the list below to start the return process.";
    }
    get singleOrderPromptMessage() {
      if (this.isCancelledHeaderStatus) {
        return this.requestContext === "cancel" ? "This order is already cancelled and cannot be cancelled again." : "This order is already cancelled and cannot be returned.";
      }
      if (this.isMissingPointsFlow) {
        return this.missingPointsMessageForAction(this.responseActionTaken, false);
      }
      return "";
    }
    missingPointsMessageForAction(actionTaken, forCaseForm) {
      switch (actionTaken) {
        case "missing_points_order_cancelled":
          return "The order you entered has been canceled, so no points will be deposited. Please let me know if there is anything else I can help you with.";
        case "missing_points_bopis_wait":
          return "I found the Hallmark.com in-store pickup order. Crown Rewards points are usually deposited 2-3 days after the purchase is charged.";
        case "missing_points_cancelled_items":
          return "Points will not be awarded for items that have been cancelled.";
        case "missing_points_wait_72_hours":
          return "I found the Hallmark.com order, and all items have shipped. Please allow at least 72 hours after shipment for Crown Rewards points to be deposited to the account.";
        case "missing_points_fully_shipped_live_chat_case":
          return forCaseForm ? "I found the Hallmark.com order and all items have shipped. Please collect the consumer first name, last name, and email so this can continue to live chat and case creation." : "I found the Hallmark.com order and all items have shipped. Please provide the consumer first name, last name, and email so I can continue with live chat and case creation.";
        case "missing_points_fully_shipped_case":
          return forCaseForm ? "I found the Hallmark.com order and all items have shipped. Please collect the consumer first name, last name, and email so a case can be created for missing Crown Rewards points." : "I found the Hallmark.com order and all items have shipped. Please provide the consumer first name, last name, and email so I can create a case for missing Crown Rewards points.";
        case "missing_points_wait_for_shipment":
          return "I found the Hallmark.com order, but all items must be shipped before Crown Rewards points can be deposited.";
        default:
          return "I found the Hallmark.com order. I will guide you through the next step for the missing Crown Rewards points.";
      }
    }
    get isCancelFlow() {
      return this.requestContext === "cancel";
    }
    get orderCaseTitle() {
      if (this.isMissingPointsFlow) {
        return "Create Missing Points Case";
      }
      return this.isCancelFlow ? "Create Cancellation Case" : "Create Return Case";
    }
    get orderCaseBroadGrouping() {
      if (this.isMissingPointsFlow) {
        return "Crown Rewards";
      }
      return this.isCancelFlow ? "Cancel" : "Return";
    }
    get orderCaseComponentKey() {
      if (this.isMissingPointsFlow) {
        return this.responseWithinBusinessHours === true ? "MISSING_POINTS_HALLMARK_ONLINE_IN_BUSINESS_HOURS" : "MISSING_POINTS_HALLMARK_ONLINE_OFF_BUSINESS_HOURS";
      }
      if (!this.isCancelFlow) {
        return "RETURN_CASE";
      }
      return "";
    }
    get orderCaseSubmitLabel() {
      return "Submit";
    }
    get orderCaseDescriptionLabel() {
      return this.isCancelFlow ? "Cancellation Reason" : "Return Reason";
    }
    get orderCaseInstructions() {
      return this.actionNoticeMessage;
    }
    get isCancelledHeaderStatus() {
      return !!(this.detailOrder && this.detailOrder.displayStatusText && String(this.detailOrder.displayStatusText).trim().toLowerCase() === "cancelled");
    }
    get impactedItemOptions() {
      const options = [{
        label: "All",
        value: "All"
      }];
      if (!this.detailOrder) {
        return options;
      }
      const seen = /* @__PURE__ */ new Set();
      const isCancelledStatus = (status) => {
        const normalized = status ? String(status).trim().toLowerCase() : "";
        return normalized === "cancelled" || normalized === "canceled";
      };
      const isCancelledShipment = (shipment) => isCancelledStatus(shipment && (shipment.status || shipment.displayStatusText || shipment.orderStatus || shipment.statusText));
      const pushItem = (description) => {
        const value = description ? String(description).trim() : "";
        if (!value || seen.has(value)) {
          return;
        }
        seen.add(value);
        options.push({
          label: value,
          value
        });
      };
      (this.detailOrder.shipments || []).forEach((shipment) => {
        if (isCancelledShipment(shipment)) {
          return;
        }
        (shipment.items || []).forEach((item) => pushItem(item.description));
      });
      if (!isCancelledStatus(this.detailOrder.bopisStatus)) {
        (this.detailOrder.pickupItems || []).forEach((item) => pushItem(item.description));
      }
      return options;
    }
    get itemizedReturnItemOptions() {
      if (!this.detailOrder) {
        return [];
      }
      const options = [];
      const pushItem = (item, fallbackKey) => {
        const description = item && item.description ? String(item.description).trim() : "";
        if (!description) {
          return;
        }
        options.push({
          label: description,
          value: item && item.key ? item.key : fallbackKey
        });
      };
      const isCancelledStatus = (status) => {
        const normalized = status ? String(status).trim().toLowerCase() : "";
        return normalized === "cancelled" || normalized === "canceled";
      };
      (this.detailOrder.shipments || []).forEach((shipment, shipmentIndex) => {
        const shipmentStatus = shipment && (shipment.status || shipment.displayStatusText || shipment.orderStatus || shipment.statusText);
        if (isCancelledStatus(shipmentStatus)) {
          return;
        }
        (shipment.items || []).forEach((item, itemIndex) => {
          pushItem(item, `shipment-${shipmentIndex + 1}-item-${itemIndex + 1}`);
        });
      });
      if (!isCancelledStatus(this.detailOrder.bopisStatus)) {
        (this.detailOrder.pickupItems || []).forEach((item, itemIndex) => {
          pushItem(item, `pickup-item-${itemIndex + 1}`);
        });
      }
      return options;
    }
    get eligibleReturnItemCount() {
      return this.itemizedReturnItemOptions.length;
    }
    get useItemizedReturnItems() {
      return this.showReturnAction && !this.isMissingPointsFlow;
    }
    get showReturnItemLimitMessage() {
      return this.useItemizedReturnItems && this.eligibleReturnItemCount > 5;
    }
    get returnItemLimitMessage() {
      return "This order has more than 5 returnable items. Please contact a Live Agent or come back during business hours for return assistance.";
    }
    get outcomeOptions() {
      return [{
        label: "Refund",
        value: "Refund"
      }, {
        label: "Exchange",
        value: "Exchange"
      }, {
        label: "Replacement",
        value: "Replacement"
      }, {
        label: "Store Credit",
        value: "Store Credit"
      }];
    }
    get orderCaseReason() {
      return this.responseCaseReason || "Account Assistance";
    }
    get orderCaseSubject() {
      if (this.responseCaseSubject) {
        return this.responseCaseSubject;
      }
      if (!this.detailOrder || !this.detailOrder.orderNumber) {
        return this.isCancelFlow ? "Consumer interacted with virtual assistant for order cancellation support." : "Consumer interacted with virtual assistant for order return support.";
      }
      return this.isCancelFlow ? "Consumer interacted with virtual assistant for cancellation request for order " + this.detailOrder.orderNumber + "." : "Consumer interacted with virtual assistant for return request for order " + this.detailOrder.orderNumber + ".";
    }
    get orderCaseSubmitMode() {
      return this.isMissingPointsFlow ? "shared" : "order";
    }
    get showOrderDescriptionField() {
      return !this.isMissingPointsFlow;
    }
    get showOrderImpactedItemsField() {
      return !this.isMissingPointsFlow;
    }
    get showOrderPreferredOutcomeField() {
      return !this.isMissingPointsFlow;
    }
    get emptyStateMessage() {
      return this.parsedPayload ? this.parsedPayload.errorMessage || this.summaryMessage || "No orders are available right now." : "";
    }
    handleSelectOrder(event) {
      const orderNumber = event.currentTarget.dataset.orderNumber;
      this.selectedOrderNumber = this.selectedOrderNumber === orderNumber ? null : orderNumber;
    }
    handleShowMore() {
      if (this.visibleOrderCount >= this.orderCards.length) {
        this.visibleOrderCount = _OrderSearchWidget.PAGE_SIZE;
        return;
      }
      this.visibleOrderCount = Math.min(this.visibleOrderCount + _OrderSearchWidget.PAGE_SIZE, this.orderCards.length);
    }
    get rawValue() {
      return Array.isArray(this.value) ? this.value[0] : this.value;
    }
    /*LWC compiler v9.2.0*/
  };
  OrderSearchWidget.PAGE_SIZE = 5;
  registerDecorators(OrderSearchWidget, {
    publicProps: {
      summaryMessage: {
        config: 0
      },
      responsePayload: {
        config: 0
      },
      value: {
        config: 0
      }
    },
    fields: ["parsedPayload", "requestContext", "selectedOrderNumber", "visibleOrderCount", "responseActionTaken", "responseNeedsCaseOption", "responseShouldCreateCase", "responseCaseSubject", "responseCaseReason", "responseQueueName", "responseWithinBusinessHours", "responseSummaryMessage", "responseMessagingSessionId"]
  });
  var __lwc_component_class_internal2 = registerComponent(OrderSearchWidget, {
    tmpl: orderSearchWidget_default2,
    sel: "c-order-search-widget",
    apiVersion: 66
  });
  var orderSearchWidget_default3 = __lwc_component_class_internal2;

  // Holly_Production_Candidate/force-app/main/default/lwc/rewardsSupportWidget/rewardsSupportWidget.css
  function stylesheet3(token, useActualHostSelector, useNativeDirPseudoclass) {
    var shadowSelector = token ? "[" + token + "]" : "";
    var hostSelector = token ? "[" + token + "-host]" : "";
    var suffixToken = token ? "-" + token : "";
    return [".widget", shadowSelector, " {background: transparent;border: 0;border-radius: 0;color: #251b3a;font-family: Arial, 'Salesforce Sans', Arial, sans-serif;font-size: 0.84rem;line-height: 1.4;padding: 0;}.file-input", shadowSelector, " {display: none;}.hero-card", shadowSelector, " {background: linear-gradient(145deg, #9b76ff, #7aa4ff);border: 1px solid #bba7ff;border-radius: 16px;box-shadow: 0 12px 26px rgba(92, 86, 201, 0.2);color: #ffffff;margin-bottom: 0.75rem;padding: 0.8rem 0.9rem;}.hero-card__header", shadowSelector, " {align-items: flex-start;display: flex;gap: 0.7rem;justify-content: space-between;margin-bottom: 0.35rem;}.hero-card__message", shadowSelector, ",.summary", shadowSelector, " {margin: 0;}.hero-card__message", shadowSelector, " {color: rgba(255, 255, 255, 0.96);font-size: 0.84rem;line-height: 1.42;}.summary", shadowSelector, " {color: #31405e;margin-bottom: 0.7rem;}.eyebrow", shadowSelector, ",.label", shadowSelector, " {font-size: 0.64rem;font-weight: 700;letter-spacing: 0.06em;margin: 0 0 0.2rem;text-transform: uppercase;}.eyebrow", shadowSelector, " {color: rgba(255, 255, 255, 0.82);}.label", shadowSelector, " {color: #6848de;}.label--subtle", shadowSelector, " {margin-top: 0;}.member-badge", shadowSelector, " {background: rgba(64, 45, 132, 0.96);border: 1px solid rgba(255, 255, 255, 0.34);border-radius: 999px;color: rgba(255, 255, 255, 0.96);display: inline-flex;font-size: 0.68rem;font-weight: 700;padding: 0.3rem 0.62rem;white-space: nowrap;}.stats-grid", shadowSelector, " {display: grid;gap: 0.65rem;grid-template-columns: repeat(2, minmax(0, 1fr));margin-bottom: 0.8rem;}.stats-grid", shadowSelector, " > :last-child:nth-child(odd)", shadowSelector, " {grid-column: 1 / -1;}.stat-card", shadowSelector, ",.detail-card", shadowSelector, ",.notice-card", shadowSelector, ",.empty-state", shadowSelector, " {border-radius: 14px;}.stat-card", shadowSelector, " {border: 1px solid #d3dff3;box-shadow: 0 10px 22px rgba(85, 103, 145, 0.1);overflow: hidden;padding: 0.78rem;position: relative;}.stat-card", shadowSelector, "::before {content: '';inset: 0 auto 0 0;position: absolute;width: 4px;}.stat-card--tier", shadowSelector, " {background: linear-gradient(180deg, #faf5ff, #efe6ff);}.stat-card--tier", shadowSelector, "::before {background: #8f63ff;}.stat-card--balance", shadowSelector, " {background: linear-gradient(180deg, #f1f7ff, #e3efff);}.stat-card--balance", shadowSelector, "::before {background: #4589ff;}.stat-card--current-year", shadowSelector, " {background: linear-gradient(180deg, #f3fbf7, #edf8f2);}.stat-card--current-year", shadowSelector, "::before {background: #7cad8e;}.stat-card--platinum", shadowSelector, " {background: linear-gradient(180deg, #fff7ea, #ffeed4);}.stat-card--platinum", shadowSelector, "::before {background: #ff9a2f;}.stat-card--count", shadowSelector, " {background: linear-gradient(180deg, #effcf6, #e0f8eb);}.stat-card--count", shadowSelector, "::before {background: #17b26a;}.stat-value", shadowSelector, " {color: #1d2942;font-size: 1.16rem;font-weight: 800;line-height: 1.1;margin: 0.1rem 0 0;}@media (max-width: 420px) {.stats-grid", shadowSelector, " {grid-template-columns: 1fr;}.stats-grid", shadowSelector, " > :last-child:nth-child(odd)", shadowSelector, " {grid-column: auto;}}.section-stack", shadowSelector, " {display: grid;gap: 0.65rem;}.detail-card", shadowSelector, " {background: linear-gradient(180deg, #ffffff, #f7f9fe);border: 1px solid #d8e0ef;box-shadow: inset 0 1px 0 rgba(255, 255, 255, 0.8), 0 10px 22px rgba(87, 104, 141, 0.09);padding: 0.82rem;}.detail-card--rewards", shadowSelector, " {background: linear-gradient(180deg, #fff9f2, #fff1dc);border-color: #f4d6a8;}.detail-card--bonus", shadowSelector, " {background: linear-gradient(180deg, #f1fff7, #e3faed);border-color: #bee9d0;}.section-heading", shadowSelector, " {margin-bottom: 0.45rem;}.detail-grid", shadowSelector, " {display: grid;gap: 0.7rem;grid-template-columns: repeat(auto-fit, minmax(145px, 1fr));}.detail-list", shadowSelector, " {margin: 0;padding-left: 1rem;}.detail-list--spaced", shadowSelector, " {margin-top: 0.7rem;}.detail-list--plain", shadowSelector, " {list-style: none;padding-left: 0;}.detail-list--ordered", shadowSelector, " {padding-left: 1.15rem;}.detail-list__item", shadowSelector, " {color: #31405e;margin: 0.24rem 0 0;}.detail-value", shadowSelector, " {color: #1d2942;margin: 0;}.detail-value--spaced", shadowSelector, " {margin-bottom: 0.7rem;}.form-grid", shadowSelector, " {display: grid;gap: 0.65rem;}.form-grid", shadowSelector, " lightning-input", shadowSelector, " {--slds-c-input-text-font-family: Arial, 'Salesforce Sans', Arial, sans-serif;--slds-c-file-selector-text-font-family: Arial, 'Salesforce Sans', Arial, sans-serif;font-family: Arial, 'Salesforce Sans', Arial, sans-serif;}.button-stack", shadowSelector, " {display: grid;gap: 0.6rem;}.button-stack--inline", shadowSelector, " {grid-template-columns: repeat(2, minmax(0, 1fr));margin-top: 0.75rem;}.choice-button", shadowSelector, ",.text-button", shadowSelector, " {appearance: none;cursor: pointer;font: inherit;}.choice-button", shadowSelector, " {border: 1.5px solid #604099;border-radius: 999px;box-shadow: 0 10px 18px rgba(96, 64, 153, 0.2);color: #ffffff;font-size: 0.82rem;font-weight: 700;min-height: 2.9rem;padding: 0.72rem 1.2rem;text-align: center;transition: transform 120ms ease, box-shadow 120ms ease, background-color 120ms ease, color 120ms ease;}.choice-button--light-submit", shadowSelector, " {background: #604099;color: #ffffff;}.choice-button:disabled", shadowSelector, " {cursor: default;opacity: 0.55;transform: none;box-shadow: none;}.choice-button--secondary", shadowSelector, " {background: #ffffff;color: #604099;box-shadow: none;}.choice-button:not(:disabled):hover", shadowSelector, " {transform: translateY(-1px);}.choice-button:focus-visible", shadowSelector, " {outline: 2px solid rgba(96, 64, 153, 0.28);outline-offset: 2px;}.text-button", shadowSelector, " {background: transparent;color: #6848de;font-size: 0.78rem;font-weight: 700;margin-top: 0.55rem;padding: 0;text-align: left;}.error-message", shadowSelector, " {color: #b42318;font-size: 0.76rem;font-weight: 600;margin: 0.6rem 0 0;}.file-name", shadowSelector, " {color: #31405e;font-size: 0.76rem;margin: 0.45rem 0 0;}.reward-choice-grid", shadowSelector, " {display: grid;gap: 0.5rem;grid-template-columns: repeat(4, minmax(0, 1fr));}.reward-choice-card", shadowSelector, " {border: 1px solid #d6deea;border-radius: 12px;box-shadow: 0 8px 18px rgba(87, 104, 141, 0.08);padding: 0.48rem 0.6rem;text-align: center;}.reward-choice-card__value", shadowSelector, " {color: #1d2942;font-size: 0.8rem;font-weight: 800;margin: 0;white-space: nowrap;}.reward-choice-card--violet", shadowSelector, " {background: linear-gradient(180deg, #f7f2ff, #efe5ff);border-color: #d8c3ff;}.reward-choice-card--blue", shadowSelector, " {background: linear-gradient(180deg, #eef6ff, #e2edff);border-color: #bfd6ff;}.reward-choice-card--amber", shadowSelector, " {background: linear-gradient(180deg, #fff7e8, #ffedd1);border-color: #f3d39b;}.reward-choice-card--rose", shadowSelector, " {background: linear-gradient(180deg, #fff1f6, #ffe2ec);border-color: #f2bfd2;}@media (max-width: 420px) {.reward-choice-grid", shadowSelector, " {grid-template-columns: repeat(2, minmax(0, 1fr));}}.notice-card", shadowSelector, " {background: linear-gradient(180deg, #ffffff, #f7f7fb);border: 1px solid #d6deea;box-shadow: 0 6px 16px rgba(81, 92, 108, 0.06);padding: 0.75rem 0.82rem;}.notice-card--muted", shadowSelector, " {background: linear-gradient(180deg, #fffaf3, #fcf4e7);border-color: #eadcc8;}.notice-card__message", shadowSelector, " {color: #364152;margin: 0;}.notice-card__message--error", shadowSelector, " {color: #b42318;margin-top: 0.7rem;}.notice-card__case", shadowSelector, " {color: #1f2937;font-weight: 700;margin: 0.5rem 0 0;}.empty-state", shadowSelector, " {align-items: flex-start;background: linear-gradient(180deg, #fff8f7, #fcf0ee);border: 1px solid #efc8c2;display: grid;gap: 0.6rem;grid-template-columns: auto 1fr;margin-top: 0.85rem;padding: 0.8rem 0.85rem;}.empty-state__icon", shadowSelector, " {align-items: center;background: #cf8e7e;border-radius: 999px;color: #ffffff;display: inline-flex;font-size: 0.82rem;font-weight: 700;height: 1.55rem;justify-content: center;width: 1.55rem;}.empty-state__title", shadowSelector, ",.empty-state__message", shadowSelector, " {margin: 0;}.empty-state__title", shadowSelector, " {color: #6e2d28;font-size: 0.8rem;font-weight: 700;}.empty-state__message", shadowSelector, " {color: #6e2d28;margin-top: 0.12rem;}.membership-card", shadowSelector, "{font:14px/1.5 Arial,sans-serif;color:#241a3a;border:1px solid #ddd6ea;border-radius:14px;padding:18px;background:white}.membership-card", shadowSelector, " h3", shadowSelector, "{margin:0 0 12px;color:#604099;font-size:1.17em}.membership-card", shadowSelector, " dl", shadowSelector, "{margin:0}.membership-card", shadowSelector, " dl", shadowSelector, " div", shadowSelector, "{display:grid;grid-template-columns:1fr 1fr;gap:12px;margin:10px 0}.membership-card", shadowSelector, " dt", shadowSelector, "{color:#6b6480}.membership-card", shadowSelector, " dd", shadowSelector, "{margin:0;font-weight:600;overflow-wrap:anywhere}"].join("");
  }
  var rewardsSupportWidget_default = [stylesheet3];

  // runtime-stub:lightning/input
  var UnavailableBaseComponent = class extends LightningElement {
  };

  // Holly_Production_Candidate/force-app/main/default/lwc/rewardsSupportWidget/rewardsSupportWidget.html
  var $fragment111 = parseFragment`<section class="widget${0}"${2}><p${3}>Holly can continue your missing-points request in this conversation.</p><button type="button"${"a3:disabled"}${3}>Continue in chat</button><p role="status"${3}>${"t6"}</p></section>`;
  var $fragment210 = parseFragment`<section class="hero-card${0}"${2}><div class="hero-card__header${0}"${2}><p class="eyebrow${0}"${2}>Missing Points</p></div><p class="hero-card__message${0}"${2}>${"t5"}</p></section>`;
  var $fragment310 = parseFragment`<section class="detail-card${0}"${2}><div class="button-stack button-stack--inline${0}"${2}><button class="choice-button${0}" data-path="inStore"${2}>${"t3"}</button><button class="choice-button choice-button--secondary${0}" data-path="hallmark"${2}>${"t5"}</button></div><button class="text-button${0}"${2}>${"t7"}</button></section>`;
  var $fragment410 = parseFragment`<section class="notice-card${0}"${2}><p class="notice-card__message${0}"${2}>${"t2"}</p><button class="text-button${0}"${2}>Back</button></section>`;
  var $fragment510 = parseFragment`<section class="detail-card${0}"${2}><p class="detail-value${0}"${2}>${"t2"}</p><div class="button-stack button-stack--inline${0}"${2}><button class="choice-button${0}" data-answer="yes"${2}>Yes</button><button class="choice-button${0}" data-answer="no"${2}>No</button></div></section>`;
  var $fragment69 = parseFragment`<section class="detail-card${0}"${2}><p class="detail-value${0}"${2}>${"t2"}</p><div class="button-stack button-stack--inline${0}"${2}><button class="choice-button${0}" data-answer="yes"${2}>Yes</button><button class="choice-button${0}" data-answer="no"${2}>No</button></div></section>`;
  var $fragment73 = parseFragment`<div class="section-heading${0}"${2}><p class="label${0}"${2}>${"t2"}</p></div>`;
  var $fragment83 = parseFragment`<p class="detail-value detail-value--spaced${0}"${2}>${"t1"}</p>`;
  var $fragment93 = parseFragment`<p class="error-message${0}"${2}>${"t1"}</p>`;
  var $fragment103 = parseFragment`<p class="supported-files-info${0}"${2}>We accept files smaller than 4.5MB in the following formats: .bmp, .csv, .doc, .docx, .gif, .jpg, .jpeg, .pdf, .png, .tiff, .txt, .xls, .xlsx, and .xml</p>`;
  var $fragment113 = parseFragment`<p class="file-name${0}"${2}>${"t1"}</p>`;
  var $fragment123 = parseFragment`<p class="error-message${0}"${2}>${"t1"}</p>`;
  var $fragment133 = parseFragment`<div class="button-stack button-stack--inline${0}"${2}><button class="choice-button choice-button--light-submit${0}"${"a1:disabled"}${2}>Submit</button><button class="choice-button choice-button--secondary${0}"${2}>Clear</button></div>`;
  var $fragment143 = parseFragment`<p class="label${0}"${2}>Case Created</p>`;
  var $fragment153 = parseFragment`<p class="notice-card__message${0}"${2}>Case number:<span class="notice-card__case${0}"${2}>${"t3"}</span> has been opened for you. Please allow us 24 to 48 hours to review and keep a look out for an email from Hallmark!</p>`;
  var $fragment163 = parseFragment`<p class="detail-list__item${0}"${2}><span class="label${0}"${2}>First Name</span>${"t3"}</p>`;
  var $fragment173 = parseFragment`<p class="detail-list__item${0}"${2}><span class="label${0}"${2}>Last Name</span>${"t3"}</p>`;
  var $fragment183 = parseFragment`<p class="detail-list__item${0}"${2}><span class="label${0}"${2}>Email</span>${"t3"}</p>`;
  var $fragment193 = parseFragment`<p class="detail-list__item${0}"${2}><span class="label${0}"${2}>Receipt</span>${"t3"}</p>`;
  var $fragment203 = parseFragment`<section class="notice-card${0}"${2}><p class="notice-card__message${0}"${2}>${"t2"}</p><button class="text-button${0}"${2}>Back</button></section>`;
  var $fragment213 = parseFragment`<h3${3}>Crown Rewards</h3>`;
  var $fragment223 = parseFragment`<div${3}><dt${3}>Crown Rewards Number</dt><dd${3}>${"t4"}</dd></div>`;
  var $fragment232 = parseFragment`<div${3}><dt${3}>Tier</dt><dd${3}>${"t4"}</dd></div>`;
  var $fragment242 = parseFragment`<div${3}><dt${3}>Points Balance</dt><dd${3}>${"t4"}</dd></div>`;
  var $fragment252 = parseFragment`<div${3}><dt${3}>Points to Platinum</dt><dd${3}>${"t4"}</dd></div>`;
  var $fragment262 = parseFragment`<p${3}>${"t1"}</p>`;
  var $fragment272 = parseFragment`<div class="section-heading${0}"${2}><p class="label${0}"${2}>Available Reward Values</p></div>`;
  var $fragment282 = parseFragment`<article${"c0"}${2}><p class="reward-choice-card__value${0}"${2}>${"t2"}</p></article>`;
  var stc03 = {
    classMap: {
      "widget": true
    },
    key: 4
  };
  var stc110 = {
    classMap: {
      "detail-card": true
    },
    key: 22
  };
  var stc210 = {
    classMap: {
      "form-grid": true
    },
    key: 27
  };
  var stc33 = {
    "data-field": "inStoreFirstName"
  };
  var stc43 = {
    "data-field": "inStoreLastName"
  };
  var stc53 = {
    "data-field": "inStoreEmail"
  };
  var stc63 = {
    "type": "file",
    "label": "Receipt Upload",
    "required": true,
    "messageWhenValueMissing": "Receipt upload is required.",
    "accept": ".bmp, .csv, .doc, .docx, .gif, .jpg, .jpeg, .pdf, .png, .tiff, .txt, .xls, .xlsx, .xml"
  };
  var stc73 = {
    classMap: {
      "notice-card": true
    },
    key: 46
  };
  var stc83 = {
    classMap: {
      "detail-list": true,
      "detail-list--spaced": true
    },
    key: 51
  };
  var stc93 = {
    classMap: {
      "membership-card": true
    },
    attrs: {
      "aria-label": "Crown Rewards membership"
    },
    key: 65
  };
  var stc103 = {
    key: 68
  };
  var stc113 = {
    classMap: {
      "detail-card": true
    },
    key: 85
  };
  var stc123 = {
    classMap: {
      "reward-choice-grid": true
    },
    key: 88
  };
  function tmpl3($api, $cmp, $slotset, $ctx) {
    const { b: api_bind, d: api_dynamic_text, sp: api_static_part, st: api_static_fragment, fr: api_fragment, c: api_custom_element, h: api_element, ncls: api_normalize_class_name, k: api_key, i: api_iterator } = $api;
    const { _m0, _m1, _m2, _m3, _m4, _m5, _m6, _m7, _m8, _m9, _m10, _m11, _m12, _m13, _m14, _m15 } = $ctx;
    return [$cmp.needsConversation ? api_fragment(0, [api_static_fragment($fragment111, 2, [api_static_part(3, {
      on: _m0 || ($ctx._m0 = {
        "click": api_bind($cmp.handleContinueInChat)
      }),
      attrs: {
        "disabled": $cmp.chatSending ? "" : null
      }
    }, null), api_static_part(6, null, api_dynamic_text($cmp.chatError))])], 0) : null, $cmp.hasPayload ? api_fragment(3, [api_element("section", stc03, [$cmp.isMissingPointsInteractive ? api_fragment(5, [$cmp.showMissingPointsHero ? api_fragment(6, [api_static_fragment($fragment210, 8, [api_static_part(5, null, api_dynamic_text($cmp.interactiveHeaderMessage))])], 0) : null, $cmp.showMissingPointsRootActions ? api_fragment(9, [api_static_fragment($fragment310, 11, [api_static_part(2, {
      on: _m1 || ($ctx._m1 = {
        "click": api_bind($cmp.handleMissingPointsPathClick)
      })
    }, null), api_static_part(3, null, api_dynamic_text($cmp.storeButtonLabel)), api_static_part(4, {
      on: _m2 || ($ctx._m2 = {
        "click": api_bind($cmp.handleMissingPointsPathClick)
      })
    }, null), api_static_part(5, null, api_dynamic_text($cmp.hallmarkButtonLabel)), api_static_part(6, {
      on: _m3 || ($ctx._m3 = {
        "click": api_bind($cmp.handleCancelMissingPointsFlow)
      })
    }, null), api_static_part(7, null, api_dynamic_text($cmp.cancelButtonLabel))])], 0) : null, $cmp.showMissingPointsCancelled ? api_fragment(12, [api_static_fragment($fragment410, 14, [api_static_part(2, null, api_dynamic_text($cmp.cancelledMessage)), api_static_part(3, {
      on: _m4 || ($ctx._m4 = {
        "click": api_bind($cmp.handleBackToMainInStoreQuestion)
      })
    }, null)])], 0) : null, $cmp.showInStoreQuestion ? api_fragment(15, [api_static_fragment($fragment510, 17, [api_static_part(2, null, api_dynamic_text($cmp.storePromptMessage)), api_static_part(4, {
      on: _m5 || ($ctx._m5 = {
        "click": api_bind($cmp.handleInStoreEligibilityClick)
      })
    }, null), api_static_part(6, {
      on: _m6 || ($ctx._m6 = {
        "click": api_bind($cmp.handleInStoreEligibilityClick)
      })
    }, null)])], 0) : null, $cmp.showInStoreReceiptQuestion ? api_fragment(18, [api_static_fragment($fragment69, 20, [api_static_part(2, null, api_dynamic_text($cmp.storeReceiptPromptMessage)), api_static_part(4, {
      on: _m7 || ($ctx._m7 = {
        "click": api_bind($cmp.handleInStoreReceiptClick)
      })
    }, null), api_static_part(6, {
      on: _m8 || ($ctx._m8 = {
        "click": api_bind($cmp.handleInStoreReceiptClick)
      })
    }, null)])], 0) : null, $cmp.showInStoreCaseForm ? api_fragment(21, [api_element("section", stc110, [api_static_fragment($fragment73, 24, [api_static_part(2, null, api_dynamic_text($cmp.storeFormTitle))]), api_static_fragment($fragment83, 26, [api_static_part(1, null, api_dynamic_text($cmp.storeFormMessage))]), api_element("div", stc210, [api_custom_element("lightning-input", UnavailableBaseComponent, {
      attrs: stc33,
      props: {
        "label": "First Name",
        "value": $cmp.inStoreFirstName,
        "required": true,
        "messageWhenValueMissing": "First name is required."
      },
      key: 28,
      on: _m9 || ($ctx._m9 = {
        "change": api_bind($cmp.handleStoreFormInput)
      })
    }), api_custom_element("lightning-input", UnavailableBaseComponent, {
      attrs: stc43,
      props: {
        "label": "Last Name",
        "value": $cmp.inStoreLastName,
        "required": true,
        "messageWhenValueMissing": "Last name is required."
      },
      key: 29,
      on: _m10 || ($ctx._m10 = {
        "change": api_bind($cmp.handleStoreFormInput)
      })
    }), api_custom_element("lightning-input", UnavailableBaseComponent, {
      attrs: stc53,
      props: {
        "type": "email",
        "label": "Email",
        "value": $cmp.inStoreEmail,
        "required": true,
        "messageWhenValueMissing": "Email is required."
      },
      key: 30,
      on: _m11 || ($ctx._m11 = {
        "change": api_bind($cmp.handleStoreFormInput)
      })
    }), api_custom_element("lightning-input", UnavailableBaseComponent, {
      props: stc63,
      key: 31,
      on: _m12 || ($ctx._m12 = {
        "change": api_bind($cmp.handleUploadFile)
      })
    }), $cmp.fileErrorMessage ? api_fragment(32, [api_static_fragment($fragment93, 34, [api_static_part(1, null, api_dynamic_text($cmp.fileErrorMessage))])], 0) : null, api_static_fragment($fragment103, 36)]), $cmp.uploadedFileName ? api_fragment(37, [api_static_fragment($fragment113, 39, [api_static_part(1, null, "Selected file: " + api_dynamic_text($cmp.uploadedFileName))])], 0) : null, $cmp.showInteractiveError ? api_fragment(40, [api_static_fragment($fragment123, 42, [api_static_part(1, null, api_dynamic_text($cmp.interactiveErrorMessage))])], 0) : null, api_static_fragment($fragment133, 44, [api_static_part(1, {
      on: _m13 || ($ctx._m13 = {
        "click": api_bind($cmp.handleSubmitInStoreCase)
      }),
      attrs: {
        "disabled": $cmp.isSubmittingInStoreCase ? "" : null
      }
    }, null), api_static_part(3, {
      on: _m14 || ($ctx._m14 = {
        "click": api_bind($cmp.handleClearInStoreCase)
      })
    }, null)])])], 0) : null, $cmp.showInStoreCaseCreated ? api_fragment(45, [api_element("section", stc73, [api_static_fragment($fragment143, 48), api_static_fragment($fragment153, 50, [api_static_part(3, null, " " + api_dynamic_text($cmp.inStoreCaseCreatedNumber))]), api_element("div", stc83, [api_static_fragment($fragment163, 53, [api_static_part(3, null, " " + api_dynamic_text($cmp.confirmationFirstName))]), api_static_fragment($fragment173, 55, [api_static_part(3, null, " " + api_dynamic_text($cmp.confirmationLastName))]), api_static_fragment($fragment183, 57, [api_static_part(3, null, " " + api_dynamic_text($cmp.confirmationEmail))]), $cmp.hasConfirmationReceipt ? api_fragment(58, [api_static_fragment($fragment193, 60, [api_static_part(3, null, " " + api_dynamic_text($cmp.confirmationReceiptFileName))])], 0) : null])])], 0) : null, $cmp.showInStoreWaitMessage ? api_fragment(61, [api_static_fragment($fragment203, 63, [api_static_part(2, null, api_dynamic_text($cmp.storeWaitMessage)), api_static_part(3, {
      on: _m15 || ($ctx._m15 = {
        "click": api_bind($cmp.handleBackToMainInStoreQuestion)
      })
    }, null)])], 0) : null], 0) : api_fragment(5, [$cmp.showOverview ? api_fragment(64, [api_element("section", stc93, [api_static_fragment($fragment213, 67), api_element("dl", stc103, [$cmp.hasMembershipNumber ? api_fragment(69, [api_static_fragment($fragment223, 71, [api_static_part(4, null, api_dynamic_text($cmp.formattedCrownRewardsNumber))])], 0) : null, $cmp.hasMembershipTier ? api_fragment(72, [api_static_fragment($fragment232, 74, [api_static_part(4, null, api_dynamic_text($cmp.membershipTier))])], 0) : null, $cmp.hasPointsBalance ? api_fragment(75, [api_static_fragment($fragment242, 77, [api_static_part(4, null, api_dynamic_text($cmp.pointsBalance))])], 0) : null, $cmp.hasPointsToPlatinum ? api_fragment(78, [api_static_fragment($fragment252, 80, [api_static_part(4, null, api_dynamic_text($cmp.pointsToPlatinum))])], 0) : null]), $cmp.heroMessage ? api_fragment(81, [api_static_fragment($fragment262, 83, [api_static_part(1, null, api_dynamic_text($cmp.heroMessage))])], 0) : null])], 0) : null, $cmp.showGuidance ? api_fragment(84, [api_element("section", stc113, [api_static_fragment($fragment272, 87), api_element("div", stc123, api_iterator($cmp.rewardChoiceCards, function(choice) {
      return api_static_fragment($fragment282, api_key(90, choice.key), [api_static_part(0, {
        className: api_normalize_class_name(choice.className)
      }, null), api_static_part(2, null, api_dynamic_text(choice.label))]);
    }))])], 0) : null], 0)])], 0) : null];
  }
  var rewardsSupportWidget_default2 = registerTemplate(tmpl3);
  tmpl3.stylesheets = [];
  tmpl3.stylesheetToken = "lwc-1088lu63iln";
  tmpl3.legacyStylesheetToken = "c-rewardsSupportWidget_rewardsSupportWidget";
  if (rewardsSupportWidget_default) {
    tmpl3.stylesheets.push.apply(tmpl3.stylesheets, rewardsSupportWidget_default);
  }
  if (empty_default) {
    tmpl3.stylesheets.push.apply(tmpl3.stylesheets, empty_default);
  }
  freezeTemplate(tmpl3);

  // Holly_Production_Candidate/force-app/main/default/lwc/rewardsSupportWidget/rewardsSupportWidget.js
  var MISSING_POINTS_VIEW = "missingPointsInteractive";
  var RewardsSupportWidget = class extends LightningElement {
    constructor(...args) {
      super(...args);
      this.configuration = void 0;
      this.chatError = "";
      this.chatSending = false;
      this._summaryMessage = "";
      this._responsePayload = "";
      this._value = void 0;
      this.parsedPayload = void 0;
      this.selectedMissingPointsPath = "";
      this.inStoreEligibility = "";
      this.inStoreReceiptAvailable = "";
      this.interactiveErrorMessage = "";
      this.inStoreCaseCreatedNumber = "";
      this.inStoreFirstName = "";
      this.inStoreLastName = "";
      this.inStoreEmail = "";
      this.submittedInStoreFirstName = "";
      this.submittedInStoreLastName = "";
      this.submittedInStoreEmail = "";
      this.submittedReceiptFileName = "";
      this.showInStoreCancelConfirmation = false;
      this.isSubmittingInStoreCase = false;
      this.uploadedFileName = "";
      this.uploadedFileContentType = "";
      this.uploadedFileBase64Data = "";
      this._interactiveStateKey = "";
      this.fileErrorMessage = "";
      this.MAX_FILE_SIZE = 4.5 * 1024 * 1024;
    }
    get needsConversation() {
      return this.viewName === MISSING_POINTS_VIEW;
    }
    async handleContinueInChat() {
      if (this.chatSending) return;
      this.chatSending = true;
      this.chatError = "";
      try {
        await sendMessage(this.configuration, "Please continue helping me with my missing Crown Rewards points in this chat.");
      } catch {
        this.chatError = "Please type your missing-points request in the chat.";
      } finally {
        this.chatSending = false;
      }
    }
    // 4.5 MB in bytes
    get summaryMessage() {
      return this._summaryMessage;
    }
    set summaryMessage(value) {
      this._summaryMessage = value || "";
    }
    get responsePayload() {
      return this._responsePayload;
    }
    set responsePayload(value) {
      this._responsePayload = value || "";
      this.parsePayload();
    }
    get value() {
      return this._value;
    }
    set value(newValue) {
      this._value = newValue;
      this.parsePayload();
    }
    connectedCallback() {
      this.resetInteractiveState();
    }
    parsePayload() {
      const rawValue = this.rawValue;
      const source = rawValue && typeof rawValue === "object" ? rawValue : {};
      const typed = source.renderedResponse && typeof source.renderedResponse === "object" ? source.renderedResponse : source;
      const incomingPayload = typed.responsePayload !== void 0 ? typed.responsePayload : this._responsePayload;
      this.parsedPayload = null;
      if (!incomingPayload) {
        if (typed.memberFound === true || typed.memberFound !== false && ["memberOverview", "membersOverview"].includes(typed.responseType)) this.parsedPayload = {
          ...typed,
          view: "memberOverview"
        };
        return;
      }
      try {
        this.parsedPayload = parseEnvelope(this._value, this._responsePayload);
      } catch (error) {
        this.parsedPayload = {
          view: "error",
          errorMessage: "The Rewards response could not be rendered."
        };
      }
      const nextStateKey = this.interactiveStateKey;
      if (this.isMissingPointsInteractive && this._interactiveStateKey !== nextStateKey) {
        this.resetInteractiveState();
        this.initializeMissingPointsEntryPath();
        this._interactiveStateKey = nextStateKey;
      } else if (this.isMissingPointsInteractive && !this.selectedMissingPointsPath) {
        this.initializeMissingPointsEntryPath();
      }
    }
    resetInteractiveState() {
      this.selectedMissingPointsPath = "";
      this.inStoreEligibility = "";
      this.inStoreReceiptAvailable = "";
      this.interactiveErrorMessage = "";
      this.inStoreCaseCreatedNumber = "";
      this.inStoreFirstName = "";
      this.inStoreLastName = "";
      this.inStoreEmail = "";
      this.submittedInStoreFirstName = "";
      this.submittedInStoreLastName = "";
      this.submittedInStoreEmail = "";
      this.submittedReceiptFileName = "";
      this.showInStoreCancelConfirmation = false;
      this.isSubmittingInStoreCase = false;
      this.uploadedFileName = "";
      this.uploadedFileContentType = "";
      this.uploadedFileBase64Data = "";
    }
    initializeMissingPointsEntryPath() {
      if (!this.isMissingPointsInteractive || !this.parsedPayload) {
        return;
      }
      const entryPath = this.parsedPayload.entryPath;
      if (entryPath === "instore_form") {
        this.selectedMissingPointsPath = "inStore";
        if (this.shouldRenderDirectInStoreCaseForm) {
          this.inStoreEligibility = "yes";
          this.inStoreReceiptAvailable = "yes";
        }
      } else if (entryPath === "hallmark") {
        this.selectedMissingPointsPath = "hallmark";
      }
    }
    get rawValue() {
      try {
        return unwrapResponse(this._value);
      } catch {
        return {};
      }
    }
    get interactiveStateKey() {
      return JSON.stringify({
        view: this.viewName,
        entryPath: this.parsedPayload ? this.parsedPayload.entryPath : null,
        showStoreCaseForm: this.shouldRenderDirectInStoreCaseForm,
        withinBusinessHours: this.interactiveWithinBusinessHours,
        messagingSessionId: this.interactiveMessagingSessionId,
        crownRewardsNumber: this.interactiveCrownRewardsNumber
      });
    }
    get effectiveSummaryMessage() {
      const typed = this.rawValue && this.rawValue.renderedResponse && typeof this.rawValue.renderedResponse === "object" ? this.rawValue.renderedResponse : this.rawValue;
      return typed && typed.summaryMessage || this._summaryMessage;
    }
    get externalErrorMessage() {
      const source = this.rawValue && typeof this.rawValue === "object" ? this.rawValue : {};
      const rendered = source.renderedResponse && typeof source.renderedResponse === "object" ? source.renderedResponse : {};
      return source.errorMessage || rendered.errorMessage || null;
    }
    get hasExternalNarrative() {
      return !!(this.effectiveSummaryMessage || this.externalErrorMessage);
    }
    get hasPayload() {
      return this.isMissingPointsInteractive || !!this.parsedPayload || !!this.effectiveSummaryMessage;
    }
    get viewName() {
      const view = this.parsedPayload?.view || this.parsedPayload?.responseType || this.rawValue?.responseType;
      return view === "membersOverview" ? "memberOverview" : view || null;
    }
    get isMissingPointsInteractive() {
      return false;
    }
    get rewardChoices() {
      return this.parsedPayload && this.parsedPayload.rewardChoices || [];
    }
    get hasRewardChoices() {
      return this.viewName === "rewardConversion" && this.rewardChoices.length > 0;
    }
    get showOverview() {
      return this.parsedPayload && ["memberOverview", "rewardConversion"].includes(this.viewName);
    }
    get hasMembershipTier() {
      return this.parsedPayload && this.parsedPayload.membershipTier != null && this.parsedPayload.membershipTier !== "";
    }
    get hasPointsBalance() {
      return this.parsedPayload && this.parsedPayload.pointsBalance != null;
    }
    get hasPointsToPlatinum() {
      return this.parsedPayload && this.parsedPayload.pointsToPlatinum != null && Number(this.parsedPayload.pointsToPlatinum) > 0;
    }
    get membershipTier() {
      return this.parsedPayload ? this.parsedPayload.membershipTier : null;
    }
    get pointsBalance() {
      return this.parsedPayload ? this.parsedPayload.pointsBalance : null;
    }
    get pointsToPlatinum() {
      return this.parsedPayload ? this.parsedPayload.pointsToPlatinum : null;
    }
    get showGuidance() {
      return this.parsedPayload && this.viewName === "rewardConversion" && this.rewardChoices.length > 0;
    }
    get hasStructuredHero() {
      return this.showOverview || this.showGuidance;
    }
    get heroTitle() {
      switch (this.viewName) {
        case "memberOverview":
          return "Crown Rewards Snapshot";
        case "rewardConversion":
          return "Reward Conversion Guidance";
        default:
          return "Crown Rewards";
      }
    }
    get heroMessage() {
      if (this.viewName === "rewardConversion") {
        return "Rewards start with minimum 600 points.";
      }
      return null;
    }
    get formattedCrownRewardsNumber() {
      return this.parsedPayload ? this.parsedPayload.crownRewardsNumber : null;
    }
    get hasMembershipNumber() {
      return !!this.formattedCrownRewardsNumber;
    }
    get rewardChoiceCards() {
      const colorClasses = ["reward-choice-card--violet", "reward-choice-card--blue", "reward-choice-card--amber", "reward-choice-card--rose"];
      return this.rewardChoices.map((choice, index) => ({
        key: String(choice),
        label: `$${choice}`,
        className: `reward-choice-card ${colorClasses[index % colorClasses.length]}`
      }));
    }
    get interactiveHeaderMessage() {
      if (this.shouldRenderDirectInStoreCaseForm) {
        return "Let\u2019s proceed with creating a case for your missing points. Please follow the instructions provided.";
      }
      return this.parsedPayload && this.parsedPayload.headerMessage || "Choose how the missing Crown Rewards points should be researched.";
    }
    get showMissingPointsHero() {
      return this.isMissingPointsInteractive && this.currentMissingPointsPath !== "inStore";
    }
    get interactiveWithinBusinessHours() {
      return !!(this.parsedPayload && this.parsedPayload.withinBusinessHours);
    }
    get interactiveMessagingSessionId() {
      return this.parsedPayload && this.parsedPayload.messagingSessionId || "";
    }
    get interactiveCrownRewardsNumber() {
      return this.parsedPayload && this.parsedPayload.crownRewardsNumber || "";
    }
    get currentMissingPointsPath() {
      if (this.selectedMissingPointsPath) {
        return this.selectedMissingPointsPath;
      }
      if (!this.isMissingPointsInteractive || !this.parsedPayload) {
        return "";
      }
      if (this.parsedPayload.entryPath === "instore_form") {
        return "inStore";
      }
      if (this.parsedPayload.entryPath === "hallmark") {
        return "hallmark";
      }
      return "";
    }
    get showMissingPointsRootActions() {
      return this.isMissingPointsInteractive && !this.currentMissingPointsPath;
    }
    get showMissingPointsCancelled() {
      return this.isMissingPointsInteractive && this.currentMissingPointsPath === "cancelled";
    }
    get showInStoreQuestion() {
      return this.isMissingPointsInteractive && this.currentMissingPointsPath === "inStore" && !this.shouldRenderDirectInStoreCaseForm && !this.inStoreEligibility && !this.showInStoreWaitMessage;
    }
    get storePromptMessage() {
      return this.parsedPayload && this.parsedPayload.storePromptMessage || "Was the purchase made at least 72 hours ago?";
    }
    get showInStoreReceiptQuestion() {
      return this.isMissingPointsInteractive && this.currentMissingPointsPath === "inStore" && !this.shouldRenderDirectInStoreCaseForm && this.inStoreEligibility === "yes" && !this.inStoreReceiptAvailable && !this.showInStoreWaitMessage;
    }
    get storeReceiptPromptMessage() {
      return this.parsedPayload && this.parsedPayload.storeReceiptPromptMessage || "Do you have the receipt available to upload?";
    }
    get showInStoreCaseForm() {
      if (this.shouldRenderDirectInStoreCaseForm) {
        return this.isMissingPointsInteractive && this.currentMissingPointsPath === "inStore" && !this.inStoreCaseCreatedNumber;
      }
      return this.isMissingPointsInteractive && this.currentMissingPointsPath === "inStore" && this.inStoreEligibility === "yes" && this.inStoreReceiptAvailable === "yes" && !this.inStoreCaseCreatedNumber && !this.showInStoreWaitMessage;
    }
    get showInStoreWaitMessage() {
      if (this.shouldRenderDirectInStoreCaseForm) {
        return false;
      }
      return this.isMissingPointsInteractive && this.currentMissingPointsPath === "inStore" && (this.inStoreEligibility === "no" || this.inStoreReceiptAvailable === "no");
    }
    get storeWaitMessage() {
      return this.parsedPayload && this.parsedPayload.storeWaitMessage || "Crown Rewards points can only be researched after 72 hours have passed, and proof of purchase is required. Please come back once 72 hours have passed and you have the receipt available.";
    }
    get showHallmarkLookupForm() {
      return false;
    }
    get hallmarkPromptMessage() {
      return this.parsedPayload && this.parsedPayload.hallmarkPromptMessage || "Please enter the order number, email address, or phone number in the chat to continue checking missing points for a Hallmark.com order.";
    }
    get shouldRenderDirectInStoreCaseForm() {
      return !!(this.parsedPayload && this.parsedPayload.showStoreCaseForm);
    }
    get storeButtonLabel() {
      return this.parsedPayload && this.parsedPayload.storeButtonLabel || "In-Store purchase";
    }
    get hallmarkButtonLabel() {
      return this.parsedPayload && this.parsedPayload.hallmarkButtonLabel || "Hallmark.com order";
    }
    get cancelButtonLabel() {
      return this.parsedPayload && this.parsedPayload.cancelButtonLabel || "Cancel";
    }
    get cancelledMessage() {
      return this.parsedPayload && this.parsedPayload.cancelledMessage || "If you need further assistance, feel free to ask. Thank you for reaching out!";
    }
    get storeFormTitle() {
      return this.parsedPayload && this.parsedPayload.storeFormTitle || "Create Missing Points Case";
    }
    get storeFormMessage() {
      return this.parsedPayload && this.parsedPayload.storeFormMessage || "Please provide your first name, last name, email address, and upload the receipt so a missing-points case can be created.";
    }
    get showInteractiveError() {
      return !!this.interactiveErrorMessage;
    }
    get showInStoreCaseCreated() {
      return !!this.inStoreCaseCreatedNumber;
    }
    get confirmationFirstName() {
      return this.submittedInStoreFirstName || this.inStoreFirstName || "";
    }
    get confirmationLastName() {
      return this.submittedInStoreLastName || this.inStoreLastName || "";
    }
    get confirmationEmail() {
      return this.submittedInStoreEmail || this.inStoreEmail || "";
    }
    get confirmationReceiptFileName() {
      return this.submittedReceiptFileName || this.uploadedFileName || "";
    }
    get hasConfirmationReceipt() {
      return !!this.confirmationReceiptFileName;
    }
    get hasFileError() {
      return !!this.fileErrorMessage;
    }
    handleMissingPointsPathClick(event) {
      this.interactiveErrorMessage = "";
      this.selectedMissingPointsPath = event.currentTarget.dataset.path;
      this.showInStoreCancelConfirmation = false;
    }
    handleInStoreEligibilityClick(event) {
      this.interactiveErrorMessage = "";
      this.showInStoreCancelConfirmation = false;
      this.inStoreEligibility = event.currentTarget.dataset.answer;
      if (this.inStoreEligibility !== "yes") {
        this.inStoreReceiptAvailable = "";
      }
    }
    handleInStoreReceiptClick(event) {
      this.interactiveErrorMessage = "";
      this.showInStoreCancelConfirmation = false;
      this.inStoreReceiptAvailable = event.currentTarget.dataset.answer;
    }
    handleResetMissingPointsFlow() {
      this.resetInteractiveState();
      this.initializeMissingPointsEntryPath();
      this._interactiveStateKey = this.interactiveStateKey;
    }
    handleBackToInStoreQuestion() {
      this.interactiveErrorMessage = "";
      this.inStoreEligibility = "";
      this.inStoreReceiptAvailable = "";
      this.inStoreCaseCreatedNumber = "";
      this.showInStoreCancelConfirmation = false;
      this.uploadedFileName = "";
      this.uploadedFileContentType = "";
      this.uploadedFileBase64Data = "";
      this.fileErrorMessage = "";
      this.selectedMissingPointsPath = "";
    }
    handleBackToMainInStoreQuestion() {
      this.handleBackToInStoreQuestion();
    }
    handleCancelMissingPointsFlow() {
      this.resetInteractiveState();
      this.selectedMissingPointsPath = "cancelled";
      this._interactiveStateKey = this.interactiveStateKey;
    }
    handleStoreFormInput(event) {
      const fieldName = event.target.dataset.field;
      if (!fieldName) {
        return;
      }
      this[fieldName] = event.target.value;
    }
    handleClearInStoreCase() {
      this.interactiveErrorMessage = "";
      this.fileErrorMessage = "";
      this.inStoreFirstName = "";
      this.inStoreLastName = "";
      this.inStoreEmail = "";
      this.uploadedFileName = "";
      this.uploadedFileContentType = "";
      this.uploadedFileBase64Data = "";
      const fileInput = this.template.querySelector('lightning-input[type="file"]');
      if (fileInput) {
        fileInput.value = null;
      }
    }
    async handleUploadFile(event) {
      const file = event.target.files && event.target.files[0];
      this.interactiveErrorMessage = "";
      if (!file) {
        this.uploadedFileName = "";
        this.uploadedFileContentType = "";
        this.uploadedFileBase64Data = "";
        return;
      }
      if (file.size > this.MAX_FILE_SIZE) {
        const fileSizeMB = (file.size / (1024 * 1024)).toFixed(2);
        this.fileErrorMessage = `File size exceeds the maximum limit of 4.5 MB. Selected file is ${fileSizeMB} MB.`;
        this.uploadedFileName = "";
        this.uploadedFileContentType = "";
        this.uploadedFileBase64Data = "";
        event.target.value = "";
        return;
      }
      try {
        const base64Data = await this.readFileAsBase64(file);
        this.uploadedFileName = file.name;
        this.uploadedFileContentType = file.type || "application/octet-stream";
        this.uploadedFileBase64Data = base64Data;
        this.fileErrorMessage = "";
      } catch (error) {
        this.interactiveErrorMessage = "The receipt could not be read. Please try again.";
      }
    }
    async handleSubmitInStoreCase() {
      await this.handleContinueInChat();
    }
    readFileAsBase64(file) {
      return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = () => {
          const result = reader.result;
          if (typeof result !== "string" || result.indexOf(",") === -1) {
            reject(new Error("Invalid file data."));
            return;
          }
          resolve(result.split(",")[1]);
        };
        reader.onerror = () => reject(reader.error || new Error("File read failed."));
        reader.readAsDataURL(file);
      });
    }
    resolveErrorMessage() {
      return "Your request could not be completed. Please continue in the chat.";
    }
    /*LWC compiler v9.2.0*/
  };
  registerDecorators(RewardsSupportWidget, {
    publicProps: {
      configuration: {
        config: 0
      },
      summaryMessage: {
        config: 3
      },
      responsePayload: {
        config: 3
      },
      value: {
        config: 3
      }
    },
    fields: ["chatError", "chatSending", "_summaryMessage", "_responsePayload", "_value", "parsedPayload", "selectedMissingPointsPath", "inStoreEligibility", "inStoreReceiptAvailable", "interactiveErrorMessage", "inStoreCaseCreatedNumber", "inStoreFirstName", "inStoreLastName", "inStoreEmail", "submittedInStoreFirstName", "submittedInStoreLastName", "submittedInStoreEmail", "submittedReceiptFileName", "showInStoreCancelConfirmation", "isSubmittingInStoreCase", "uploadedFileName", "uploadedFileContentType", "uploadedFileBase64Data", "_interactiveStateKey", "fileErrorMessage", "MAX_FILE_SIZE"]
  });
  var __lwc_component_class_internal3 = registerComponent(RewardsSupportWidget, {
    tmpl: rewardsSupportWidget_default2,
    sel: "c-rewards-support-widget",
    apiVersion: 66
  });
  var rewardsSupportWidget_default3 = __lwc_component_class_internal3;

  // Holly_Production_Candidate/force-app/main/default/lwc/hallmarkPlusWidget/hallmarkPlusWidget.css
  function stylesheet4(token, useActualHostSelector, useNativeDirPseudoclass) {
    var shadowSelector = token ? "[" + token + "]" : "";
    var hostSelector = token ? "[" + token + "-host]" : "";
    var suffixToken = token ? "-" + token : "";
    return (useActualHostSelector ? ":host{" : hostSelector + "{") + "display:block;font:14px/1.5 Arial,sans-serif;color:#241a3a}.card" + shadowSelector + "{border:1px solid #ddd6ea;border-radius:14px;padding:18px;background:white}h3" + shadowSelector + "{margin:0 0 12px;color:#604099}dl" + shadowSelector + "{margin:0}dl" + shadowSelector + " div" + shadowSelector + "{display:grid;grid-template-columns:1fr 1fr;gap:12px;margin:10px 0}dt" + shadowSelector + "{color:#6b6480}dd" + shadowSelector + "{margin:0;font-weight:600;overflow-wrap:anywhere}";
  }
  var hallmarkPlusWidget_default = [stylesheet4];

  // Holly_Production_Candidate/force-app/main/default/lwc/hallmarkPlusWidget/hallmarkPlusWidget.html
  var $fragment114 = parseFragment`<h3${3}>Hallmark+</h3>`;
  var $fragment211 = parseFragment`<dl${3}><div${3}><dt${3}>Membership source</dt><dd${3}>${"t5"}</dd></div><div${3}><dt${3}>Auto-renew</dt><dd${3}>${"t10"}</dd></div><div${3}><dt${3}>Next payment</dt><dd${3}>${"t15"}</dd></div><div${3}><dt${3}>Membership end date</dt><dd${3}>${"t20"}</dd></div></dl>`;
  var $fragment311 = parseFragment`<p${3}>${"t1"}</p>`;
  var stc04 = {
    classMap: {
      "card": true
    },
    attrs: {
      "aria-label": "Hallmark Plus membership"
    },
    key: 0
  };
  function tmpl4($api, $cmp, $slotset, $ctx) {
    const { st: api_static_fragment, d: api_dynamic_text, sp: api_static_part, fr: api_fragment, h: api_element } = $api;
    return [api_element("section", stc04, [api_static_fragment($fragment114, 2), $cmp.found ? api_fragment(3, [api_static_fragment($fragment211, 5, [api_static_part(5, null, api_dynamic_text($cmp.source)), api_static_part(10, null, api_dynamic_text($cmp.renewal)), api_static_part(15, null, api_dynamic_text($cmp.nextPayment)), api_static_part(20, null, api_dynamic_text($cmp.endDate))])], 0) : api_fragment(3, [api_static_fragment($fragment311, 7, [api_static_part(1, null, api_dynamic_text($cmp.message))])], 0)])];
  }
  var hallmarkPlusWidget_default2 = registerTemplate(tmpl4);
  tmpl4.stylesheets = [];
  tmpl4.stylesheetToken = "lwc-kvtgfabt2t";
  tmpl4.legacyStylesheetToken = "c-hallmarkPlusWidget_hallmarkPlusWidget";
  if (hallmarkPlusWidget_default) {
    tmpl4.stylesheets.push.apply(tmpl4.stylesheets, hallmarkPlusWidget_default);
  }
  if (empty_default) {
    tmpl4.stylesheets.push.apply(tmpl4.stylesheets, empty_default);
  }
  freezeTemplate(tmpl4);

  // Holly_Production_Candidate/force-app/main/default/lwc/hallmarkPlusWidget/hallmarkPlusWidget.js
  var HallmarkPlusWidget = class extends LightningElement {
    constructor(...args) {
      super(...args);
      this.value = void 0;
    }
    get response() {
      try {
        return unwrapResponse(this.value);
      } catch {
        return {};
      }
    }
    get found() {
      return this.response.membershipFound === true;
    }
    get source() {
      return this.response.membershipSource || "Not available";
    }
    get renewal() {
      return this.response.autoRenewEnabled === true ? "On" : this.response.autoRenewEnabled === false ? "Off" : "Not available";
    }
    get nextPayment() {
      return this.response.nextPaymentDate || "Not available";
    }
    get endDate() {
      return this.response.membershipEndDate || "Not available";
    }
    get message() {
      return this.response.summaryMessage || "Membership details are not available. Please continue in the chat.";
    }
    /*LWC compiler v9.2.0*/
  };
  registerDecorators(HallmarkPlusWidget, {
    publicProps: {
      value: {
        config: 0
      }
    }
  });
  var __lwc_component_class_internal4 = registerComponent(HallmarkPlusWidget, {
    tmpl: hallmarkPlusWidget_default2,
    sel: "c-hallmark-plus-widget",
    apiVersion: 66
  });
  var hallmarkPlusWidget_default3 = __lwc_component_class_internal4;

  // Holly_Production_Candidate/force-app/main/default/lwc/hollyCareHeader/hollyCareHeader.css
  function stylesheet5(token, useActualHostSelector, useNativeDirPseudoclass) {
    var shadowSelector = token ? "[" + token + "]" : "";
    var hostSelector = token ? "[" + token + "-host]" : "";
    var suffixToken = token ? "-" + token : "";
    return (useActualHostSelector ? ":host{" : hostSelector + "{") + "display:block;background:white;font:15px/1.5 Arial,sans-serif;color:#30353a}*" + shadowSelector + "{box-sizing:border-box}.chat-header" + shadowSelector + "{display:flex;align-items:center;gap:8px;background:white;color:#30353a;padding:22px 20px;border-bottom:1px solid #f5f3f7;position:relative;z-index:2}.chat-header" + shadowSelector + " h2" + shadowSelector + "{flex:1;min-width:0;font:700 21px/1.2 Arial,sans-serif;margin:0}.chat-logo" + shadowSelector + "{width:32px;height:32px;margin-right:6px;object-fit:contain;background:#604099;border-radius:50%;flex-shrink:0}.header-control" + shadowSelector + "{display:flex;align-items:center;justify-content:center;background:white;border:1px solid #6748a0;border-radius:50%;color:#6748a0;width:35px;height:35px;flex-shrink:0;font:21px Arial,sans-serif;cursor:pointer}.header-control:hover" + shadowSelector + "{background:#f0eaf7}.menu-anchor" + shadowSelector + "{position:relative}.header-menu" + shadowSelector + "{position:absolute;right:0;top:42px;width:216px;background:white;border:1px solid #ded6ea;border-radius:8px;padding:6px;box-shadow:0 5px 18px #0002;z-index:3}.header-menu" + shadowSelector + " button" + shadowSelector + "{display:block;width:100%;border:0;padding:10px;background:white;color:#503b74;text-align:left;font:15px/1.5 Arial,sans-serif;cursor:pointer}.header-menu" + shadowSelector + " button:hover" + shadowSelector + "{background:#f0eaf7}.minimize" + shadowSelector + " span" + shadowSelector + "{display:block;position:relative;width:16px;height:16px}.minimize" + shadowSelector + " span" + shadowSelector + "::before,.minimize" + shadowSelector + " span" + shadowSelector + '::after{content:"";position:absolute;top:7px;left:0;width:16px;height:2px;background:currentColor;transform:rotate(45deg)}.minimize' + shadowSelector + " span" + shadowSelector + "::after{transform:rotate(-45deg)}.banner" + shadowSelector + "{margin:16px 20px 22px;display:flex;align-items:center;justify-content:space-between;gap:18px;background:#f0eaf7;padding:20px;min-height:135px}.banner" + shadowSelector + " strong" + shadowSelector + "{font-size:19px;line-height:1.4}.banner" + shadowSelector + " img" + shadowSelector + "{width:90px;height:100px;object-fit:contain;flex-shrink:0}.welcome-choices" + shadowSelector + "{padding:0 20px 24px}.welcome-choices" + shadowSelector + " p" + shadowSelector + "{margin:0 0 22px}.choice-list" + shadowSelector + "{display:flex;flex-direction:column;align-items:flex-start;gap:9px}.welcome-choice" + shadowSelector + "{display:block;width:auto;max-width:100%;white-space:normal;overflow-wrap:anywhere;background:white;border:1px solid #aaa6ae;border-radius:6px;padding:9px 12px;font:inherit;text-align:left;color:inherit;min-height:36px;cursor:pointer}.welcome-choice:hover" + shadowSelector + "{background:#f0eaf7}.welcome-choice:disabled" + shadowSelector + "{opacity:.55;cursor:default}.welcome-choices" + shadowSelector + " .choice-list" + shadowSelector + "+p" + shadowSelector + "{margin:20px 0 0;color:#696473;font-size:13px}.error" + shadowSelector + "{padding:12px;color:#8b1d22}button:focus-visible" + shadowSelector + "{outline:3px solid #a68bd4;outline-offset:2px}@media(max-width:420px){.chat-header" + shadowSelector + " h2" + shadowSelector + "{font-size:18px}.header-control" + shadowSelector + "{width:30px;height:30px}.chat-header" + shadowSelector + "{padding:18px 14px}.banner" + shadowSelector + "{margin-left:14px;margin-right:14px;padding:16px}.banner" + shadowSelector + " img" + shadowSelector + "{width:70px}.welcome-choices" + shadowSelector + "{padding-left:14px;padding-right:14px}}";
  }
  var hollyCareHeader_default = [stylesheet5];

  // Holly_Production_Candidate/force-app/main/default/lwc/hollyCareHeader/hollyCareHeader.html
  var $fragment115 = parseFragment`<img class="chat-logo${0}" src="https://care.hallmark.com/resource/chat_Logo" alt aria-hidden="true"${2}>`;
  var $fragment214 = parseFragment`<h2${3}>Hallmark AI Assistent</h2>`;
  var $fragment312 = parseFragment`<button type="button" class="header-control${0}" data-menu aria-label="Conversation options"${"a0:aria-expanded"}${2}>⋮</button>`;
  var $fragment411 = parseFragment`<div class="header-menu${0}" aria-label="Conversation actions"${2}><button type="button"${3}>Request Chat Transcript</button><button type="button"${"a3:disabled"}${3}>End chat</button></div>`;
  var $fragment511 = parseFragment`<button type="button" class="header-control minimize${0}" aria-label="Minimize chat"${2}><span aria-hidden="true"${3}></span></button>`;
  var $fragment610 = parseFragment`<div${3}><strong${3}>Your personal card and gift inspiration expert</strong></div>`;
  var $fragment74 = parseFragment`<img${"a0:src"} alt="Hallmark romantic greeting card"${3}>`;
  var $fragment84 = parseFragment`<p${3}>Hi, I’m Holly! How can I help you today? I can help with cards and gifts, orders, Crown Rewards, and Hallmark+.</p>`;
  var $fragment94 = parseFragment`<button type="button" class="welcome-choice${0}"${"a0:data-choice"}${"a0:disabled"}${2}>${"t1"}</button>`;
  var $fragment104 = parseFragment`<p${3}>Choose an option to get started, or type your question in the chat.</p>`;
  var $fragment116 = parseFragment`<p class="error${0}" role="alert"${2}>${"t1"}</p>`;
  var stc05 = {
    classMap: {
      "chat-header": true
    },
    key: 1
  };
  var stc111 = {
    classMap: {
      "menu-anchor": true
    },
    key: 6
  };
  var stc211 = {
    classMap: {
      "banner": true
    },
    attrs: {
      "aria-label": "Welcome to Holly"
    },
    key: 15
  };
  var stc34 = {
    classMap: {
      "welcome-choices": true
    },
    attrs: {
      "aria-label": "Choose how Holly can help"
    },
    key: 22
  };
  var stc44 = {
    classMap: {
      "choice-list": true
    },
    key: 25
  };
  function tmpl5($api, $cmp, $slotset, $ctx) {
    const { b: api_bind, st: api_static_fragment, sp: api_static_part, fr: api_fragment, h: api_element, k: api_key, d: api_dynamic_text, i: api_iterator } = $api;
    const { _m0, _m1, _m2, _m3, _m4, _m5, _m6, _m7, _m8, _m9, _m10 } = $ctx;
    return [api_element("section", {
      key: 0,
      on: _m0 || ($ctx._m0 = {
        "keydown": api_bind($cmp.handleKeydown)
      })
    }, [api_element("header", stc05, [api_static_fragment($fragment115, 3), api_static_fragment($fragment214, 5), api_element("div", stc111, [api_static_fragment($fragment312, 8, [api_static_part(0, {
      on: _m2 || ($ctx._m2 = {
        "click": api_bind($cmp.toggleMenu)
      }),
      attrs: {
        "aria-expanded": $cmp.menuExpanded
      }
    }, null)]), $cmp.menuOpen ? api_fragment(9, [api_static_fragment($fragment411, 11, [api_static_part(1, {
      on: _m3 || ($ctx._m3 = {
        "click": api_bind($cmp.requestTranscript)
      })
    }, null), api_static_part(3, {
      on: _m4 || ($ctx._m4 = {
        "click": api_bind($cmp.endConversation)
      }),
      attrs: {
        "disabled": $cmp.ending ? "" : null
      }
    }, null)])], 0) : null]), api_static_fragment($fragment511, 13, [api_static_part(0, {
      on: _m6 || ($ctx._m6 = {
        "click": api_bind($cmp.minimize)
      })
    }, null)])]), $cmp.showBanner ? api_fragment(14, [api_element("section", stc211, [api_static_fragment($fragment610, 17), $cmp.showImage ? api_fragment(18, [api_static_fragment($fragment74, 20, [api_static_part(0, {
      on: _m8 || ($ctx._m8 = {
        "error": api_bind($cmp.imageError)
      }),
      attrs: {
        "src": $cmp.imageUrl
      }
    }, null)])], 0) : null])], 0) : null, $cmp.showBanner ? api_fragment(21, [api_element("section", stc34, [api_static_fragment($fragment84, 24), api_element("div", stc44, api_iterator($cmp.choices, function(choice) {
      return api_static_fragment($fragment94, api_key(27, choice), [api_static_part(0, {
        on: _m10 || ($ctx._m10 = {
          "click": api_bind($cmp.selectChoice)
        }),
        attrs: {
          "data-choice": choice,
          "disabled": $cmp.choiceDisabled ? "" : null
        }
      }, null), api_static_part(1, null, api_dynamic_text(choice))]);
    })), api_static_fragment($fragment104, 29)])], 0) : null, $cmp.errorMessage ? api_fragment(30, [api_static_fragment($fragment116, 32, [api_static_part(1, null, api_dynamic_text($cmp.errorMessage))])], 0) : null])];
  }
  var hollyCareHeader_default2 = registerTemplate(tmpl5);
  tmpl5.stylesheets = [];
  tmpl5.stylesheetToken = "lwc-6te3rdio31j";
  tmpl5.legacyStylesheetToken = "c-hollyCareHeader_hollyCareHeader";
  if (hollyCareHeader_default) {
    tmpl5.stylesheets.push.apply(tmpl5.stylesheets, hollyCareHeader_default);
  }
  if (empty_default) {
    tmpl5.stylesheets.push.apply(tmpl5.stylesheets, empty_default);
  }
  freezeTemplate(tmpl5);

  // runtime-stub:lightningsnapin/eventStore
  var MESSAGING_EVENT = { MINIMIZE_BUTTON_CLICK: "minimize", CLOSE_CONVERSATION: "end", REQUEST_TRANSCRIPT: "transcript" };
  function dispatchMessagingEvent(name) {
    document.dispatchEvent(new CustomEvent("previewheader", { detail: name }));
  }

  // Holly_Production_Candidate/force-app/main/default/lwc/hollyCareHeader/hollyCareHeader.js
  var HollyCareHeader = class extends LightningElement {
    constructor(...args) {
      super(...args);
      this.configuration = void 0;
      this.menuOpen = false;
      this.ending = false;
      this._conversationStatus = void 0;
      this._welcomeLoaded = false;
      this.dismissed = false;
      this.errorMessage = "";
      this.imageFailed = false;
      this.sendingChoice = false;
    }
    get menuExpanded() {
      return String(this.menuOpen);
    }
    toggleMenu() {
      this.menuOpen = !this.menuOpen;
    }
    handleKeydown(event) {
      if (event.key === "Escape") {
        this.menuOpen = false;
        this.template.querySelector("[data-menu]")?.focus();
      }
    }
    minimize() {
      dispatchMessagingEvent(MESSAGING_EVENT.MINIMIZE_BUTTON_CLICK, {});
    }
    requestTranscript() {
      this.menuOpen = false;
      this.errorMessage = "";
      try {
        if (!MESSAGING_EVENT.REQUEST_TRANSCRIPT) throw new Error("Unavailable");
        dispatchMessagingEvent(MESSAGING_EVENT.REQUEST_TRANSCRIPT, {});
      } catch {
        this.errorMessage = "The transcript request could not be opened. Please try again.";
      }
    }
    async endConversation() {
      if (this.ending) return;
      this.ending = true;
      this.menuOpen = false;
      this.errorMessage = "";
      try {
        const auth = this.configuration?.embeddedServiceMessagingChannel?.authMode;
        if (auth === "Auth") {
          if (typeof this.configuration?.util?.endSession !== "function") throw new Error("Unavailable");
          await this.configuration.util.endSession();
        } else if (auth === "UnAuth") dispatchMessagingEvent(MESSAGING_EVENT.CLOSE_CONVERSATION, {});
        else throw new Error("Unknown authentication mode");
      } catch {
        this.errorMessage = "The chat could not be ended. Please try again.";
      } finally {
        this.ending = false;
      }
    }
    // A presentation-only marker; never stores transcript or customer information.
    get welcomeStorageKey() {
      return "holly.welcome.dismissed.v2:" + (typeof window !== "undefined" ? window.location.pathname : "default");
    }
    loadWelcomeState() {
      if (this._welcomeLoaded) return;
      this._welcomeLoaded = true;
      try {
        this.dismissed = window.sessionStorage.getItem(this.welcomeStorageKey) === "1";
      } catch {
      }
    }
    connectedCallback() {
      this.loadWelcomeState();
    }
    get conversationStatus() {
      return this._conversationStatus;
    }
    set conversationStatus(value) {
      const previous = this._conversationStatus;
      this._conversationStatus = value;
      this.loadWelcomeState();
      if (value === "CLOSED" || previous === "CLOSED" && value !== "CLOSED" || value === "NOT_STARTED" && previous === "OPEN") {
        this.resetWelcome();
      }
    }
    resetWelcome() {
      this.dismissed = false;
      this.imageFailed = false;
      this.errorMessage = "";
      this.menuOpen = false;
      this.sendingChoice = false;
      try {
        window.sessionStorage.removeItem(this.welcomeStorageKey);
      } catch {
      }
    }
    get choices() {
      return ["I need a card for someone special", "Help me find a birthday gift", "What\u2019s popular for Halloween?", "Where is my order?", "Check my Crown Rewards points", "Hallmark+ membership help", "Ask a question about returns or shipping"];
    }
    get choiceDisabled() {
      return this.sendingChoice || !this.isOpen;
    }
    async selectChoice(event) {
      const text = event.currentTarget.dataset.choice;
      if (this.choiceDisabled || !this.choices.includes(text)) return;
      this.sendingChoice = true;
      this.errorMessage = "";
      try {
        if (typeof this.configuration?.util?.sendTextMessage !== "function") throw new Error("Unavailable");
        await this.configuration.util.sendTextMessage(text);
        this.dismissed = true;
        try {
          window.sessionStorage.setItem(this.welcomeStorageKey, "1");
        } catch {
        }
      } catch {
        this.errorMessage = "Your selection could not be sent. Try again or type it in the chat.";
      } finally {
        this.sendingChoice = false;
      }
    }
    get showBanner() {
      return !this.dismissed && (this.conversationStatus === "OPEN" || this.conversationStatus === "NOT_STARTED");
    }
    get showImage() {
      return !this.imageFailed;
    }
    get isOpen() {
      return this.conversationStatus === "OPEN";
    }
    get imageUrl() {
      return "https://www.hallmark.com/dw/image/v2/AALB_PRD/on/demandware.static/-/Sites-hallmark-master/default/dw25cc2ffc/images/finished-goods/products/499LOV1465/Copper-Heart-on-Blue-Romantic-Love-Card_499499LOV1465_01.jpg?sw=160&sh=160&sm=fit";
    }
    imageError() {
      this.imageFailed = true;
    }
    /*LWC compiler v9.2.0*/
  };
  registerDecorators(HollyCareHeader, {
    publicProps: {
      configuration: {
        config: 0
      },
      conversationStatus: {
        config: 3
      }
    },
    fields: ["menuOpen", "ending", "_conversationStatus", "_welcomeLoaded", "dismissed", "errorMessage", "imageFailed", "sendingChoice"]
  });
  var __lwc_component_class_internal5 = registerComponent(HollyCareHeader, {
    tmpl: hollyCareHeader_default2,
    sel: "c-holly-care-header",
    apiVersion: 66
  });
  var hollyCareHeader_default3 = __lwc_component_class_internal5;

  // Holly_Production_Candidate/component-preview/main.js
  var log2 = document.querySelector("#events");
  var configuration = { embeddedServiceMessagingChannel: { authMode: "UnAuth" }, util: { sendTextMessage: async (text) => {
    log2.textContent = text;
    document.dispatchEvent(new CustomEvent("previewmessage", { detail: text }));
  } } };
  function mount2(id, name, ctor, value) {
    const el = createElement(name, { is: ctor });
    el.value = value;
    el.configuration = configuration;
    document.querySelector("#" + id).appendChild(el);
    return el;
  }
  var header = mount2("header", "c-holly-care-header", hollyCareHeader_default3);
  header.conversationStatus = "OPEN";
  var products = [
    { sku: "499LOV1465", name: "My Partner, My Love, My Friend Romantic Love Card", price: 4.99, priceDisplay: "$4.99", category: "Cards", imageUrl: "https://www.hallmark.com/dw/image/v2/AALB_PRD/on/demandware.static/-/Sites-hallmark-master/default/dw25cc2ffc/images/finished-goods/products/499LOV1465/Copper-Heart-on-Blue-Romantic-Love-Card_499499LOV1465_01.jpg?sw=300&sh=300&sm=fit", productUrl: "https://www.hallmark.com/cards/greeting-cards/my-partner-my-love-my-friend-romantic-love-card-499LOV1465.html" },
    { sku: "599LOV1420", name: "Your Are the Best Thing Romantic Love Card", price: 5.99, priceDisplay: "$5.99", category: "Cards", imageUrl: "https://www.hallmark.com/dw/image/v2/AALB_PRD/on/demandware.static/-/Sites-hallmark-master/default/dw56c3c4d1/images/finished-goods/products/599LOV1420/Gold-Heart-on-Red-Romantic-Love-Card_599LOV1420_01.jpg?sw=300&sh=300&sm=fit", productUrl: "https://www.hallmark.com/cards/greeting-cards/your-are-the-best-thing-romantic-love-card-599LOV1420.html" }
  ];
  var product = mount2("products", "c-product-carousel-widget", productCarouselWidget_default3, { summaryMessage: "Finding a card for someone special is a thoughtful way to show you care. Here are a few heartfelt ideas.", followUpQuestion: "What is the occasion? I would love to help you find the perfect match.", responsePayload: JSON.stringify({ view: "productCarousel", products, maxCompare: 3, suggestedReplies: [{ label: "Compare products", action: "compareMode" }, { label: "Birthday ideas", text: "Show me birthday gifts" }] }) });
  mount2("orders", "c-order-search-widget", orderSearchWidget_default3, { requestType: "search", responsePayload: JSON.stringify({ view: "orderDetail", order: { orderNumber: "DEMO-1029384", orderStatus: "Shipped", status: "Shipped", orderDate: "2026-09-18", totalAmount: 24.98, shipments: [{ shipmentLabel: "Shipment 1", carrier: "UPS", shippedDate: "2026-09-19", arrivalDateRange: "2026-09-23 \u2013 2026-09-25", status: "Shipped", trackingUrl: "https://www.ups.com/track", trackingNumber: "DEMO-TRACKING", items: [{ name: "Greeting card", productName: "Greeting card", description: "Greeting card", productDescription: "Greeting card", quantity: 2 }] }] } }) });
  mount2("rewards", "c-rewards-support-widget", rewardsSupportWidget_default3, { responsePayload: JSON.stringify({ view: "memberOverview", crownRewardsNumber: "99888989", membershipTier: "Platinum", pointsBalance: 1250, pointsToPlatinum: 0 }), summaryMessage: "Your Crown Rewards membership" });
  mount2("plus", "c-hallmark-plus-widget", hallmarkPlusWidget_default3, { membershipFound: true, membershipSource: "Hallmark.com", autoRenewEnabled: true, nextPaymentDate: "2026-12-05" });
  document.addEventListener("previewheader", (e) => {
    log2.textContent = "Header event: " + e.detail;
  });
  document.addEventListener("previewmessage", (e) => {
    if (e.detail.startsWith("Compare ")) {
      product.value = { responsePayload: JSON.stringify({ view: "productCompare", products, rows: [{ label: "Price", values: ["$4.99", "$5.99"] }, { label: "Type", values: ["Greeting card", "Greeting card"] }], suggestedReplies: [] }) };
    }
  });
})();

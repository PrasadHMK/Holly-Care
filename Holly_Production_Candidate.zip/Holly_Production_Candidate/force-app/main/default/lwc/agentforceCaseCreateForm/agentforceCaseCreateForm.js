import { LightningElement, api } from 'lwc';
import createCaseFromWidget from '@salesforce/apex/Agentforce_Action_CreateCase.createCaseFromWidget';
import createOrderCaseFromWidget from '@salesforce/apex/Agentforce_Action_CreateOrderManagementCase.createCaseFromWidget';

export default class AgentforceCaseCreateForm extends LightningElement {
    @api title = 'Create Case';
    @api instructions = '';
    @api submitLabel = 'Create Case';
    @api componentKey = '';
    @api broadGrouping = '';
    @api queueName = '';
    @api caseReason = '';
    @api caseSubject = '';
    @api orderNumber = '';
    @api purchaseLocation = '';
    @api customerPostalCode = '';
    @api withinBusinessHours;
    @api messagingSessionId = '';
    @api descriptionPrefix = '';
    @api descriptionLabel = 'Additional Details';
    @api impactedItemsLabel = 'Items';
    @api preferredOutcomeLabel = 'Preferred Outcome';
    @api recipientInformationLabel = 'Recipient Information';
    @api showDescriptionField = false;
    @api useSingleLineDescription = false;
    @api showImpactedItemsField = false;
    @api showPreferredOutcomeField = false;
    @api showRecipientInformationField = false;
    @api useImpactedItemsSelect = false;
    @api usePreferredOutcomeSelect = false;
    @api useItemizedReturnItems = false;
    @api impactedItemOptions = [];
    @api itemizedReturnItemOptions = [];
    @api preferredOutcomeOptions = [];
    @api submitMode = 'shared';
    @api prefillFirstName = '';
    @api prefillLastName = '';
    @api prefillContactEmail = '';
    @api prefillDescription = '';
    @api prefillImpactedItems = '';
    @api prefillPreferredOutcome = '';
    @api prefillRecipientInformation = '';

    form = {};
    returnItemEntries = [];
    errorMessage = '';
    isSubmitting = false;
    successCaseNumber = '';

    connectedCallback() {
        this.resetFormState();
    }

    get showHeader() {
        return !this.successCaseNumber && !!(this.title || this.instructions);
    }

    handleInput(event) {
        const fieldName = event.target.dataset.field;
        this.form = {
            ...this.form,
            [fieldName]: event.target.value
        };
    }

    handleToggleAllItems(event) {
        this.form = {
            ...this.form,
            selectAllItems: event.target.checked
        };
    }

    handleImpactedItemsChange(event) {
        const values = Array.from(event.target.selectedOptions || []).map((option) => option.value);
        this.form = {
            ...this.form,
            impactedItems: values
        };
    }

    handleReturnItemSelection(event) {
        const itemValue = event.target.dataset.itemValue;
        const checked = event.target.checked;
        this.returnItemEntries = this.returnItemEntries.map((entry) => (
            entry.value === itemValue
                ? { ...entry, selected: checked }
                : entry
        ));
    }

    handleReturnItemReasonInput(event) {
        const itemValue = event.target.dataset.itemValue;
        const reason = event.target.value;
        this.returnItemEntries = this.returnItemEntries.map((entry) => (
            entry.value === itemValue
                ? { ...entry, reason }
                : entry
        ));
    }

    handleReturnItemOutcomeChange(event) {
        const itemValue = event.target.dataset.itemValue;
        const outcome = event.target.value;
        this.returnItemEntries = this.returnItemEntries.map((entry) => (
            entry.value === itemValue
                ? {
                    ...entry,
                    outcome,
                    outcomeOptions: this.normalizeOptions(this.preferredOutcomeOptions, outcome)
                }
                : entry
        ));
    }

    handleClear() {
        if (this.isSubmitting) {
            return;
        }
        this.errorMessage = '';
        this.successCaseNumber = '';
        this.resetFormState();
    }

    async handleSubmit() {
        this.errorMessage = '';
        if (!this.form.firstName || !this.form.lastName || !this.form.contactEmail) {
            this.errorMessage = 'First name, last name, and email are required.';
            return;
        }
        if (this.useItemizedReturnItems) {
            if (this.form.selectAllItems) {
                if (!this.form.description || !this.form.description.trim()) {
                    this.errorMessage = 'Return reason is required.';
                    return;
                }
                if (!this.form.preferredOutcome) {
                    this.errorMessage = 'Outcome is required.';
                    return;
                }
            } else {
                const selectedEntries = this.selectedReturnItems;
                if (selectedEntries.length === 0) {
                    this.errorMessage = 'Please select at least one impacted item.';
                    return;
                }
                const invalidEntry = selectedEntries.find((entry) => !entry.reason || !entry.reason.trim() || !entry.outcome);
                if (invalidEntry) {
                    this.errorMessage = 'Each selected item requires a return reason and outcome.';
                    return;
                }
            }
        }
        this.isSubmitting = true;
        try {
            const createAction = this.submitMode === 'order'
                ? createOrderCaseFromWidget
                : createCaseFromWidget;
            const response = await createAction({
                requestJson: JSON.stringify(this.buildRequest())
            });
            if (!response || response.caseCreated !== true) {
                throw new Error(response && response.errorMessage ? response.errorMessage : 'Case creation failed.');
            }
            this.successCaseNumber = response.caseNumber || '';
            this.dispatchEvent(new CustomEvent('casecreated', {
                detail: {
                    caseId: response.caseId,
                    caseNumber: response.caseNumber,
                    subject: response.subject
                }
            }));
        } catch (error) {
            this.errorMessage = this.resolveErrorMessage(error);
        } finally {
            this.isSubmitting = false;
        }
    }

    buildRequest() {
        const descriptionParts = [];
        if (this.descriptionPrefix && !this.useItemizedReturnItems) {
            descriptionParts.push(this.descriptionPrefix.trim());
        }
        if (this.showDescriptionField && this.form.description) {
            descriptionParts.push(this.form.description.trim());
        }
        const itemizedDescription = this.useItemizedReturnItems && !this.form.selectAllItems
            ? this.buildItemizedReturnDescription()
            : null;
        return {
            caseComponentKey: this.componentKey,
            broadGrouping: this.broadGrouping,
            queueName: this.queueName,
            caseReason: this.caseReason,
            caseSubject: this.caseSubject,
            orderNumber: this.orderNumber,
            purchaseLocation: this.purchaseLocation,
            customerPostalCode: this.customerPostalCode,
            firstName: this.form.firstName,
            lastName: this.form.lastName,
            contactEmail: this.form.contactEmail,
            description: itemizedDescription || descriptionParts.join('\n'),
            impactedItems: this.showImpactedItemsField
                ? (this.useItemizedReturnItems
                    ? (this.form.selectAllItems ? 'All' : null)
                    : this.normalizedImpactedItemsValue)
                : null,
            preferredOutcome: this.showPreferredOutcomeField
                ? (this.useItemizedReturnItems
                    ? (this.form.selectAllItems ? this.form.preferredOutcome : null)
                    : this.form.preferredOutcome)
                : null,
            recipientInformation: this.showRecipientInformationField ? this.form.recipientInformation : null,
            withinBusinessHours: this.withinBusinessHours,
            messagingSessionId: this.messagingSessionId
        };
    }

    resetFormState() {
        this.form = {
            firstName: this.prefillFirstName || '',
            lastName: this.prefillLastName || '',
            contactEmail: this.prefillContactEmail || '',
            description: this.prefillDescription || '',
            impactedItems: this.initialImpactedItems(),
            preferredOutcome: this.prefillPreferredOutcome || this.firstOptionValue(this.preferredOutcomeOptions) || '',
            recipientInformation: this.prefillRecipientInformation || '',
            selectAllItems: this.useItemizedReturnItems
        };
        this.returnItemEntries = this.initializeReturnItemEntries();
    }

    initialImpactedItems() {
        if (Array.isArray(this.prefillImpactedItems)) {
            return this.prefillImpactedItems;
        }
        if (typeof this.prefillImpactedItems === 'string' && this.prefillImpactedItems.trim()) {
            return this.prefillImpactedItems.split(/\s*;\s*/);
        }
        const firstValue = this.firstOptionValue(this.impactedItemOptions);
        return firstValue ? [firstValue] : [];
    }

    firstOptionValue(options) {
        if (!Array.isArray(options) || options.length === 0) {
            return '';
        }
        const first = options[0];
        return first && first.value ? first.value : '';
    }

    get impactedItemOptionsNormalized() {
        return this.normalizeOptions(this.impactedItemOptions, this.form.impactedItems);
    }

    get preferredOutcomeOptionsNormalized() {
        return this.normalizeOptions(this.preferredOutcomeOptions, this.form.preferredOutcome);
    }

    normalizeOptions(options, selectedValue) {
        if (!Array.isArray(options)) {
            return [];
        }
        const selectedValues = Array.isArray(selectedValue)
            ? selectedValue
            : (selectedValue ? [selectedValue] : []);
        return options.map((option) => {
            const value = option && option.value ? option.value : '';
            const label = option && option.label ? option.label : value;
            return {
                label,
                value,
                selected: selectedValues.includes(value)
            };
        });
    }

    get normalizedImpactedItemsValue() {
        if (Array.isArray(this.form.impactedItems)) {
            return this.form.impactedItems.join('; ');
        }
        return this.form.impactedItems || null;
    }

    initializeReturnItemEntries() {
        if (!this.useItemizedReturnItems || !Array.isArray(this.itemizedReturnItemOptions)) {
            return [];
        }
        const defaultOutcome = this.firstOptionValue(this.preferredOutcomeOptions) || '';
        return this.itemizedReturnItemOptions
            .filter((option) => option && option.value)
            .map((option) => ({
                key: option.value,
                value: option.value,
                label: option.label || option.value,
                selected: false,
                reason: '',
                outcome: defaultOutcome,
                outcomeOptions: this.normalizeOptions(this.preferredOutcomeOptions, defaultOutcome)
            }));
    }

    get selectedReturnItems() {
        return this.returnItemEntries.filter((entry) => entry.selected);
    }

    get showSharedReturnFields() {
        return this.useItemizedReturnItems && this.form.selectAllItems;
    }

    get showItemizedReturnFields() {
        return this.useItemizedReturnItems && !this.form.selectAllItems;
    }

    get showItemizedReturnSection() {
        return this.useItemizedReturnItems && this.showImpactedItemsField;
    }

    get showStandardImpactedItemsField() {
        return this.showImpactedItemsField && !this.showItemizedReturnSection;
    }

    get showDescriptionControl() {
        return this.showDescriptionField && (!this.showItemizedReturnSection || this.showSharedReturnFields);
    }

    get showPreferredOutcomeControl() {
        return this.showPreferredOutcomeField && (!this.showItemizedReturnSection || this.showSharedReturnFields);
    }

    buildItemizedReturnDescription() {
        const lines = ['Impacted Items'];
        this.selectedReturnItems.forEach((entry) => {
            lines.push('- ' + entry.label + ' ; ' + entry.reason.trim() + ' ; ' + entry.outcome);
        });
        return lines.join('\n');
    }

    resolveErrorMessage(error) {
        if (error && typeof error.message === 'string' && error.message.trim()) {
            return error.message.trim();
        }
        if (error && error.body) {
            const bodyMessage = Array.isArray(error.body)
                ? error.body.map((item) => item && item.message).filter(Boolean).join(' ')
                : error.body.message;
            if (bodyMessage) {
                return bodyMessage;
            }
        }
        return 'The case could not be created right now.';
    }
}

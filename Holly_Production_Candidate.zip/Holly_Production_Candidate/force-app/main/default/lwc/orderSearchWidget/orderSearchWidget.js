/**
*==============================================================================
* @File Name : orderSearchWidget.js
* @Description : Renders order, return, and cancellation responses inside the chat window.
* @Author : Prasad Yericherla
* @Created On : April 14, 2026
* @Last Modified By :  Prasad Yericherla
* @Last Modified On : April 27, 2026
* @Modification Log : 
*==============================================================================
**/
import { LightningElement, api } from 'lwc';
import { safeHttps } from 'c/hollyUi';

export default class OrderSearchWidget extends LightningElement {
static PAGE_SIZE = 5;

@api summaryMessage = '';
@api responsePayload = '';
@api value;

parsedPayload;
requestContext = 'search';
selectedOrderNumber;
visibleOrderCount = OrderSearchWidget.PAGE_SIZE;
responseActionTaken = '';
responseNeedsCaseOption = false;
responseShouldCreateCase = false;
responseCaseSubject = '';
responseCaseReason = '';
responseQueueName = '';
responseWithinBusinessHours = null;
responseSummaryMessage = '';
responseMessagingSessionId = '';

connectedCallback() {
this.parsePayload();
}

renderedCallback() {
const stateKey = JSON.stringify(this.value || {}) + '|' + (this.responsePayload || '');
if (this._lastStateKey !== stateKey) {
this.parsePayload();
}
}

parsePayload() {
const rawValue = Array.isArray(this.value) ? this.value[0] : this.value;
const sourceValue = rawValue && typeof rawValue === 'object' ? rawValue : {};
const typedValue =
sourceValue.renderedResponse && typeof sourceValue.renderedResponse === 'object'
? sourceValue.renderedResponse
: sourceValue;
const incomingPayload =
typedValue.responsePayload !== undefined
? typedValue.responsePayload
: this.responsePayload;
const explicitRequestType = typedValue && typedValue.requestType
? String(typedValue.requestType).toLowerCase()
: '';

this._lastStateKey = JSON.stringify(this.value || {}) + '|' + (this.responsePayload || '');
this.parsedPayload = null;
this.selectedOrderNumber = null;
this.visibleOrderCount = OrderSearchWidget.PAGE_SIZE;
this.responseActionTaken = typedValue && typedValue.actionTaken ? typedValue.actionTaken : '';
this.responseNeedsCaseOption = typedValue && typedValue.needsCaseOption === true;
this.responseShouldCreateCase = typedValue && typedValue.shouldCreateCase === true;
this.responseCaseSubject = typedValue && typedValue.caseSubject ? typedValue.caseSubject : '';
this.responseCaseReason = typedValue && typedValue.caseReason ? typedValue.caseReason : '';
this.responseQueueName = typedValue && typedValue.queueName ? typedValue.queueName : '';
this.responseWithinBusinessHours = typedValue ? typedValue.withinBusinessHours : null;
this.responseSummaryMessage = typedValue && typedValue.summaryMessage ? typedValue.summaryMessage : '';
this.responseMessagingSessionId = typedValue && typedValue.messagingSessionId ? typedValue.messagingSessionId : '';
this.requestContext = explicitRequestType === 'return' || explicitRequestType === 'cancel' || explicitRequestType === 'missingpoints'
? explicitRequestType
: 'search';
	
	if (!incomingPayload) {
	return;
	}
	
	try {
	const parsed = typeof incomingPayload === 'object' ? incomingPayload : JSON.parse(incomingPayload);
	const orders = (parsed.orders || []).map((order) => this.decorateOrder(order));
	const order = parsed.order ? this.decorateOrder(parsed.order) : null;
	this.parsedPayload = { ...parsed, orders, order };

if (parsed.view === 'orderDetail' && order && order.orderNumber) {
this.selectedOrderNumber = order.orderNumber;
}
} catch (error) {
this.parsedPayload = {
view: 'error',
errorMessage: 'The order response could not be rendered.'
};
	}
	}

	decorateOrder(order) {
const displayStatus = this.resolveCollapsedStatus(order);
const pickupStatusClass = this.statusClass(this.normalizeMeaningfulText(order.bopisStatus) || 'Status unavailable');
const shipments = (order.shipments || []).map((shipment, index) => ({
...shipment,
trackingUrl: safeHttps(shipment.trackingUrl),
...this.decorateShipmentStatus(order, shipment),
key: `${order.orderNumber || 'order'}-${index + 1}`,
items: (shipment.items || []).map((item, itemIndex) => ({
...item,
key: `${order.orderNumber || 'order'}-${index + 1}-${itemIndex + 1}`
}))
}));
const pickupItems = (order.pickupItems || []).map((item, itemIndex) => ({
...item,
key: item.key || `${order.orderNumber || 'order'}-pickup-${itemIndex + 1}`
}));
const pickupStore = this.firstPickupStore(pickupItems);
const canCancel = order.canCancel === true
|| (this.requestContext === 'cancel' && order.canCancel !== false);
const canReturn = order.canReturn === true
|| (this.requestContext === 'return' && order.canReturn !== false);

return {
...order,
key: order.orderNumber,
shipments,
pickupItems,
pickupStore,
hasShipments: shipments.length > 0,
hasPickupItems: pickupItems.length > 0,
hasPickupStore: !!pickupStore,
hasNoFulfillmentDetails: shipments.length === 0 && pickupItems.length === 0,
displayStatus,
displayStatusText: displayStatus,
statusClass: this.statusClass(displayStatus),
pickupStatusClass,
buttonClass: this.selectedOrderNumber === order.orderNumber
? 'order-button order-button--selected'
: 'order-button',
isSelected: this.selectedOrderNumber === order.orderNumber,
cancelDisabled: !canCancel,
returnDisabled: !canReturn,
returnButtonClass: canReturn ? 'action-button action-button--return' : 'action-button action-button--disabled',
cancelButtonClass: canCancel ? 'action-button action-button--cancel' : 'action-button action-button--disabled'
};
}

decorateShipmentStatus(order, shipment) {
const status = this.resolveExpandedShipmentStatus(order, shipment);
return {
status,
statusClass: this.statusClass(status || 'Status unavailable')
};
}

resolveCollapsedStatus(order) {
return this.firstMeaningful(
order.listStatus,
order.orderStatus,
order.status,
 order.order_status,
 this.deriveDisplayStatusFromShipments(order),
 order.bopisStatus
) || 'Status unavailable';
}

resolveExpandedShipmentStatus(order, shipment) {
return this.firstMeaningful(
shipment && shipment.status,
 shipment && shipment.displayStatusText,
 shipment && shipment.statusText,
order.orderStatus,
order.status,
 order.order_status,
 this.deriveDisplayStatusFromShipments(order),
 order.bopisStatus
);
}

deriveDisplayStatusFromShipments(order) {
const shipments = Array.isArray(order && order.shipments) ? order.shipments : [];
if (!shipments.length) {
return null;
}

const statuses = shipments
.map((shipment) => this.normalizeMeaningfulText(shipment && (shipment.status || shipment.displayStatusText || shipment.statusText)))
.filter(Boolean)
.map((status) => status.toLowerCase());

if (!statuses.length) {
return null;
}
if (statuses.every((status) => status === 'cancelled' || status === 'canceled')) {
return 'Cancelled';
}
if (statuses.every((status) => status === 'delivered')) {
return 'Delivered';
}
if (statuses.every((status) => status === 'shipped' || status === 'delivered')) {
return statuses.includes('shipped') && statuses.includes('delivered')
? 'Partially Delivered'
: 'Shipped';
}
if (statuses.some((status) => status === 'shipped' || status === 'delivered')) {
return 'Partially Shipped';
}
return statuses[0];
}

firstMeaningful(...values) {
for (const value of values) {
const normalized = this.normalizeMeaningfulText(value);
if (normalized) {
return normalized;
}
}
return null;
}

normalizeMeaningfulText(value) {
if (value === null || value === undefined) {
return null;
}
const trimmed = String(value).trim();
if (!trimmed) {
return null;
}
const lowered = trimmed.toLowerCase();
if (lowered === 'not available' || lowered === 'n/a' || lowered === 'null' || lowered === 'none') {
return null;
}
return trimmed;
}

firstPickupStore(pickupItems) {
const storeItem = (pickupItems || []).find((item) => item.storeInfo || item.storeAddress || item.storePhone);
if (!storeItem) {
return null;
}
return {
storeInfo: storeItem.storeInfo,
storeAddress: storeItem.storeAddress,
storePhone: storeItem.storePhone
};
}

statusClass(status) {
const normalized = (status || '').toLowerCase();
if (normalized === 'shipped' || normalized === 'delivered' || normalized === 'fulfilled') {
return 'pill pill-success';
}
if (normalized === 'released') {
return 'pill pill-info';
}
if (normalized === 'picked up' || normalized === 'ready for pickup') {
return 'pill pill-success';
}
if (normalized === 'open' || normalized === 'allocated') {
return 'pill pill-info';
}
if (normalized === 'processing' || normalized === 'backordered' || normalized === 'partially fulfilled') {
return 'pill pill-warning';
}
if (normalized === 'in process' || normalized === 'partially shipped' || normalized === 'partially delivered' || normalized === 'some items ready for pick up') {
return 'pill pill-warning';
}
if (normalized === 'cancelled' || normalized === 'canceled') {
return 'pill pill-error';
}
if (normalized === 'not available' || normalized === 'status unavailable') {
return 'pill pill-neutral';
}
return 'pill';
}

get isOrderList() {
return this.parsedPayload && this.parsedPayload.view === 'orderList';
}

get isOrderDetail() {
return this.parsedPayload && this.parsedPayload.view === 'orderDetail';
}

get isErrorView() {
return this.parsedPayload && this.parsedPayload.view === 'error';
}

get orderCards() {
if (!this.parsedPayload) {
return [];
}
if (this.isOrderList) {
return this.parsedPayload.orders || [];
}
if (this.isOrderDetail && this.parsedPayload.order) {
return [this.parsedPayload.order];
}
return [];
}

get hasOrders() {
return this.orderCards.length > 0;
}

get hasPayload() {
return this.hasOrders;
}

get showOrderList() {
return this.isOrderList && this.hasOrders;
}

get showSingleOrderDetail() {
return this.isOrderDetail && !!(this.parsedPayload && this.parsedPayload.order);
}

get displayedOrders() {
return this.orderCards.slice(0, this.visibleOrderCount).map((order) => ({
...order,
isSelected: this.selectedOrderNumber === order.orderNumber,
showHeaderStatus: this.selectedOrderNumber !== order.orderNumber,
buttonClass: this.selectedOrderNumber === order.orderNumber
? 'order-button order-button--selected'
: 'order-button'
}));
}

get canShowMoreOrders() {
return this.orderCards.length > OrderSearchWidget.PAGE_SIZE;
}

get showMoreLabel() {
const totalCount = this.orderCards.length;
if (this.visibleOrderCount < totalCount) {
const nextCount = Math.min(this.visibleOrderCount + OrderSearchWidget.PAGE_SIZE, totalCount);
return 'Show more orders (' + nextCount + ' of ' + totalCount + ')';
}
return 'Show fewer orders (' + OrderSearchWidget.PAGE_SIZE + ' of ' + totalCount + ')';
}

get detailOrder() {
if (this.isOrderDetail) {
return this.parsedPayload.order;
}
return (this.parsedPayload.orders || []).find(
(order) => order.orderNumber === this.selectedOrderNumber
);
}

get isEmailOrPhoneSearch() {
if (!this.parsedPayload) {
return false;
}
const searchType = (this.parsedPayload.searchType || '').toLowerCase();
return searchType === 'email' || searchType === 'phone';
}

get isMultiOrderSearchFlow() {
return this.isOrderList && this.isEmailOrPhoneSearch && this.orderCards.length > 1;
}

get showOrderCaseForm() {
// Case creation stays in the authenticated agent action/state-machine path.
return false;
}

get showReturnAction() {
return this.requestContext === 'return';
}

get showCancelAction() {
return this.requestContext === 'cancel';
}

get isMissingPointsFlow() {
return this.requestContext === 'missingpoints';
}

get showSingleOrderPrompt() {
return this.isOrderDetail
&& !!this.detailOrder
&& !this.showOrderCaseForm
&& !this.isMultiOrderSearchFlow
&& !this.showReturnItemLimitMessage
&& (this.isMissingPointsFlow || this.isCancelledHeaderStatus);
}

get showSelectedOrderPrompt() {
return this.isMultiOrderSearchFlow
&& !!this.selectedOrderNumber
&& !this.showOrderCaseForm
&& !this.showReturnItemLimitMessage
&& false;
}

get actionNoticeMessage() {
if (this.isMissingPointsFlow) {
return this.missingPointsMessageForAction(this.responseActionTaken, true);
}
return this.isCancelFlow
? 'Please provide First name, Last name, email, impacted items, and outcome below to initiate the cancellation process.'
: 'Please provide First name, Last name, email, impacted items, and outcome below to initiate the return process.';
}

get showMultiOrderPrompt() {
return this.isMultiOrderSearchFlow
&& !this.selectedOrderNumber
&& (this.showReturnAction || this.showCancelAction || this.isMissingPointsFlow);
}

get multiOrderPromptMessage() {
if (this.isMissingPointsFlow) {
return 'Please enter the order number from the list below so we can look up the missing points associated with that order.';
}
return this.requestContext === 'cancel'
? 'Please enter the order number from the list below to start the cancellation process.'
: 'Please enter the order number from the list below to start the return process.';
}

get singleOrderPromptMessage() {
if (this.isCancelledHeaderStatus) {
return this.requestContext === 'cancel'
    ? 'This order is already cancelled and cannot be cancelled again.'
    : 'This order is already cancelled and cannot be returned.';
}
if (this.isMissingPointsFlow) {
return this.missingPointsMessageForAction(this.responseActionTaken, false);
}
return '';
}

missingPointsMessageForAction(actionTaken, forCaseForm) {
switch (actionTaken) {
case 'missing_points_order_cancelled':
    return 'The order you entered has been canceled, so no points will be deposited. Please let me know if there is anything else I can help you with.';
case 'missing_points_bopis_wait':
    return 'I found the Hallmark.com in-store pickup order. Crown Rewards points are usually deposited 2-3 days after the purchase is charged.';
case 'missing_points_cancelled_items':
    return 'Points will not be awarded for items that have been cancelled.';
case 'missing_points_wait_72_hours':
    return 'I found the Hallmark.com order, and all items have shipped. Please allow at least 72 hours after shipment for Crown Rewards points to be deposited to the account.';
case 'missing_points_fully_shipped_live_chat_case':
    return forCaseForm
        ? 'I found the Hallmark.com order and all items have shipped. Please collect the consumer first name, last name, and email so this can continue to live chat and case creation.'
        : 'I found the Hallmark.com order and all items have shipped. Please provide the consumer first name, last name, and email so I can continue with live chat and case creation.';
case 'missing_points_fully_shipped_case':
    return forCaseForm
        ? 'I found the Hallmark.com order and all items have shipped. Please collect the consumer first name, last name, and email so a case can be created for missing Crown Rewards points.'
        : 'I found the Hallmark.com order and all items have shipped. Please provide the consumer first name, last name, and email so I can create a case for missing Crown Rewards points.';
case 'missing_points_wait_for_shipment':
    return 'I found the Hallmark.com order, but all items must be shipped before Crown Rewards points can be deposited.';
default:
    return 'I found the Hallmark.com order. I will guide you through the next step for the missing Crown Rewards points.';
}
}

get isCancelFlow() {
return this.requestContext === 'cancel';
}

get orderCaseTitle() {
if (this.isMissingPointsFlow) {
return 'Create Missing Points Case';
}
return this.isCancelFlow ? 'Create Cancellation Case' : 'Create Return Case';
}

get orderCaseBroadGrouping() {
    if (this.isMissingPointsFlow) {
        return 'Crown Rewards';
    }
    return this.isCancelFlow ? 'Cancel' : 'Return';
}

get orderCaseComponentKey() {
    if (this.isMissingPointsFlow) {
        return this.responseWithinBusinessHours === true
            ? 'MISSING_POINTS_HALLMARK_ONLINE_IN_BUSINESS_HOURS'
            : 'MISSING_POINTS_HALLMARK_ONLINE_OFF_BUSINESS_HOURS';
    }
    if (!this.isCancelFlow) {
        return 'RETURN_CASE';
    }
    return '';
}

get orderCaseSubmitLabel() {
return 'Submit';
}

get orderCaseDescriptionLabel() {
return this.isCancelFlow ? 'Cancellation Reason' : 'Return Reason';
}

get orderCaseInstructions() {
return this.actionNoticeMessage;
}

get isCancelledHeaderStatus() {
return !!(this.detailOrder
    && this.detailOrder.displayStatusText
    && String(this.detailOrder.displayStatusText).trim().toLowerCase() === 'cancelled');
}

get impactedItemOptions() {
const options = [{ label: 'All', value: 'All' }];
if (!this.detailOrder) {
return options;
}
const seen = new Set();
const isCancelledStatus = (status) => {
    const normalized = status ? String(status).trim().toLowerCase() : '';
    return normalized === 'cancelled' || normalized === 'canceled';
};
const isCancelledShipment = (shipment) => isCancelledStatus(
    shipment && (
        shipment.status
        || shipment.displayStatusText
        || shipment.orderStatus
        || shipment.statusText
    )
);
const pushItem = (description) => {
    const value = description ? String(description).trim() : '';
    if (!value || seen.has(value)) {
        return;
    }
    seen.add(value);
    options.push({ label: value, value });
};
((this.detailOrder.shipments || [])).forEach((shipment) => {
    if (isCancelledShipment(shipment)) {
        return;
    }
    (shipment.items || []).forEach((item) => pushItem(item.description));
});
if (!isCancelledStatus(this.detailOrder.bopisStatus)) {
    (this.detailOrder.pickupItems || []).forEach((item) => pushItem(item.description));
}
return options;
}

get itemizedReturnItemOptions() {
if (!this.detailOrder) {
return [];
}
const options = [];
const pushItem = (item, fallbackKey) => {
    const description = item && item.description ? String(item.description).trim() : '';
    if (!description) {
        return;
    }
    options.push({
        label: description,
        value: item && item.key ? item.key : fallbackKey
    });
};
const isCancelledStatus = (status) => {
    const normalized = status ? String(status).trim().toLowerCase() : '';
    return normalized === 'cancelled' || normalized === 'canceled';
};
((this.detailOrder.shipments || [])).forEach((shipment, shipmentIndex) => {
    const shipmentStatus = shipment && (
        shipment.status
        || shipment.displayStatusText
        || shipment.orderStatus
        || shipment.statusText
    );
    if (isCancelledStatus(shipmentStatus)) {
        return;
    }
    (shipment.items || []).forEach((item, itemIndex) => {
        pushItem(item, `shipment-${shipmentIndex + 1}-item-${itemIndex + 1}`);
    });
});
if (!isCancelledStatus(this.detailOrder.bopisStatus)) {
    (this.detailOrder.pickupItems || []).forEach((item, itemIndex) => {
        pushItem(item, `pickup-item-${itemIndex + 1}`);
    });
}
return options;
}

get eligibleReturnItemCount() {
return this.itemizedReturnItemOptions.length;
}

get useItemizedReturnItems() {
return this.showReturnAction && !this.isMissingPointsFlow;
}

get showReturnItemLimitMessage() {
return this.useItemizedReturnItems && this.eligibleReturnItemCount > 5;
}

get returnItemLimitMessage() {
return 'This order has more than 5 returnable items. Please contact a Live Agent or come back during business hours for return assistance.';
}

get outcomeOptions() {
return [
    { label: 'Refund', value: 'Refund' },
    { label: 'Exchange', value: 'Exchange' },
    { label: 'Replacement', value: 'Replacement' },
    { label: 'Store Credit', value: 'Store Credit' }
];
}

get orderCaseReason() {
return this.responseCaseReason || 'Account Assistance';
}

get orderCaseSubject() {
if (this.responseCaseSubject) {
return this.responseCaseSubject;
}
if (!this.detailOrder || !this.detailOrder.orderNumber) {
return this.isCancelFlow
? 'Consumer interacted with virtual assistant for order cancellation support.'
: 'Consumer interacted with virtual assistant for order return support.';
}
return this.isCancelFlow
? 'Consumer interacted with virtual assistant for cancellation request for order ' + this.detailOrder.orderNumber + '.'
: 'Consumer interacted with virtual assistant for return request for order ' + this.detailOrder.orderNumber + '.';
}

get orderCaseSubmitMode() {
return this.isMissingPointsFlow ? 'shared' : 'order';
}

get showOrderDescriptionField() {
return !this.isMissingPointsFlow;
}

get showOrderImpactedItemsField() {
return !this.isMissingPointsFlow;
}

get showOrderPreferredOutcomeField() {
return !this.isMissingPointsFlow;
}

get emptyStateMessage() {
return this.parsedPayload
? this.parsedPayload.errorMessage || this.summaryMessage || 'No orders are available right now.'
: '';
}

handleSelectOrder(event) {
const orderNumber = event.currentTarget.dataset.orderNumber;
this.selectedOrderNumber = this.selectedOrderNumber === orderNumber ? null : orderNumber;
}

handleShowMore() {
if (this.visibleOrderCount >= this.orderCards.length) {
this.visibleOrderCount = OrderSearchWidget.PAGE_SIZE;
return;
}
this.visibleOrderCount = Math.min(
this.visibleOrderCount + OrderSearchWidget.PAGE_SIZE,
this.orderCards.length
);
}

get rawValue() {
return Array.isArray(this.value) ? this.value[0] : this.value;
}

}

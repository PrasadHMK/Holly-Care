export function unwrapResponse(value) {
    let source = typeof value === 'string' ? JSON.parse(value) : value;
    if (Array.isArray(source)) source = source[0];
    if (source?.renderedResponse != null) source = source.renderedResponse;
    if (typeof source === 'string') source = JSON.parse(source);
    if (source == null) return {};
    if (typeof source !== 'object' || Array.isArray(source)) throw new Error('Invalid typed response');
    return source;
}
export function parseEnvelope(value, fallback) {
    const typed = unwrapResponse(value);
    const raw = typed.responsePayload ?? fallback;
    if (!raw) return null;
    const payload = typeof raw === 'string' ? JSON.parse(raw) : raw;
    if (!payload || typeof payload !== 'object' || Array.isArray(payload)) throw new Error('Invalid response');
    return payload;
}
export function safeHttps(value, hosts = []) {
    try {
        const url = new URL(value);
        if (url.protocol !== 'https:' || url.username || url.password) return '';
        if (hosts.length && !hosts.some(host => url.hostname === host || url.hostname.endsWith('.' + host))) return '';
        return url.href;
    } catch { return ''; }
}
export async function sendMessage(configuration, text) {
    if (typeof configuration?.util?.sendTextMessage !== 'function') throw new Error('Chat unavailable');
    await configuration.util.sendTextMessage(text);
}

import { LightningElement, api } from 'lwc';
import { unwrapResponse } from 'c/hollyUi';
export default class HallmarkPlusWidget extends LightningElement {
 @api value;
 get response(){ try { return unwrapResponse(this.value); } catch { return {}; } }
 get found(){return this.response.membershipFound===true;}
 get source(){return this.response.membershipSource||'Not available';}
 get renewal(){return this.response.autoRenewEnabled===true?'On':this.response.autoRenewEnabled===false?'Off':'Not available';}
 get nextPayment(){return this.response.nextPaymentDate||'Not available';}
 get endDate(){return this.response.membershipEndDate||'Not available';}
 get message(){return this.response.summaryMessage||'Membership details are not available. Please continue in the chat.';}
}
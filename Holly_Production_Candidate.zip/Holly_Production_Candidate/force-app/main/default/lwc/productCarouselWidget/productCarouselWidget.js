/**
*==============================================================================
* @File Name : productCarouselWidget.js
* @Description : Renders Holly product results inside the Agentforce chat.
*                - Carousel of product cards (image, title, offer, price)
*                - Per-card menu: Ask follow up, Find similar, Go to product page
*                - Compare mode: tick 2 to 3 cards, then Compare
*                - Compare table and single product detail views
*                - Suggested reply chips
*
*                The chat surface owns the input box, so every action is sent
*                back as plain text. See sendToAgent() for the two channels.
*==============================================================================
**/
import { LightningElement, api } from 'lwc';
import { parseEnvelope, safeHttps, unwrapResponse } from 'c/hollyUi';

const DEFAULT_MAX_COMPARE = 3;

export default class ProductCarouselWidget extends LightningElement {
    get typedResponse() { try { return unwrapResponse(this.value); } catch { return {}; } }
    get introMessage() { return this.hasError ? '' : this.typedResponse.summaryMessage || this.summaryMessage || ''; }
    get followUpMessage() { return this.hasError ? '' : this.typedResponse.followUpQuestion || ''; }
    @api summaryMessage = '';
    @api responsePayload = '';
    @api value;
    @api configuration;
    sendError = '';
    sending = false;

    parsedPayload;
    selectedSkus = [];
    selectionMode = false;
    openMenuSku = null;
    failedImageSkus = [];
    _lastStateKey;

    connectedCallback() {
        this.parsePayload();
    }

    renderedCallback() {
        const stateKey = JSON.stringify(this.value || {}) + '|' + (this.responsePayload || '');
        if (this._lastStateKey !== stateKey) {
            this.parsePayload();
        }
    }

    // ------------------------------------------------------------------
    // Payload
    // ------------------------------------------------------------------
    parsePayload() {
        const rawValue = Array.isArray(this.value) ? this.value[0] : this.value;
        const sourceValue = rawValue && typeof rawValue === 'object' ? rawValue : {};
        const typedValue =
            sourceValue.renderedResponse && typeof sourceValue.renderedResponse === 'object'
                ? sourceValue.renderedResponse
                : sourceValue;
        const incoming =
            typedValue.responsePayload !== undefined ? typedValue.responsePayload : this.responsePayload;

        this._lastStateKey = JSON.stringify(this.value || {}) + '|' + (this.responsePayload || '');
        this.parsedPayload = null;
        this.selectedSkus = [];
        this.selectionMode = false;
        this.openMenuSku = null;
        this.failedImageSkus = [];

        if (!incoming) {
            return;
        }
        try {
            const payload = parseEnvelope(this.value, this.responsePayload);
            if (!['productCarousel', 'productCompare', 'productDetail'].includes(payload.view) || !Array.isArray(payload.products)) throw new Error('Invalid response');
            const seen = new Set();
            payload.products = payload.products.filter(p => p && typeof p.sku === 'string' && !seen.has(p.sku) && seen.add(p.sku)).map(p => ({...p, imageUrl: safeHttps(p.imageUrl, ['hallmark.com']), productUrl: safeHttps(p.productUrl, ['hallmark.com'])}));
            if (payload.rows != null && (!Array.isArray(payload.rows) || payload.rows.some(row => !row || !Array.isArray(row.values)))) throw new Error('Invalid comparison');
            if (payload.suggestedReplies != null && (!Array.isArray(payload.suggestedReplies) || payload.suggestedReplies.some(reply => !reply || typeof reply.label !== 'string'))) throw new Error('Invalid replies');
            this.parsedPayload = payload;
        } catch (error) {
            this.parsedPayload = { view: 'error' };
        }
    }

    get hasPayload() {
        return !!this.parsedPayload && this.parsedPayload.view !== 'error';
    }

    get hasError() {
        return !!this.parsedPayload && this.parsedPayload.view === 'error';
    }

    get maxCompare() {
        return Math.max(2, Math.min(DEFAULT_MAX_COMPARE, Number(this.parsedPayload?.maxCompare) || DEFAULT_MAX_COMPARE));
    }

    get isCarousel() {
        return this.hasPayload && this.parsedPayload.view === 'productCarousel';
    }

    get isDetail() {
        return this.hasPayload && this.parsedPayload.view === 'productDetail';
    }

    get isCompare() {
        return this.hasPayload && this.parsedPayload.view === 'productCompare';
    }

    get showCards() {
        return this.isCarousel || this.isDetail;
    }


    // ------------------------------------------------------------------
    // Cards
    // ------------------------------------------------------------------
    get rawProducts() {
        return (this.parsedPayload && this.parsedPayload.products) || [];
    }

    get products() {
        const atLimit = this.selectedSkus.length >= this.maxCompare;
        return this.rawProducts.map((product) => {
            const isSelected = this.selectedSkus.includes(product.sku);
            const menuOpen = this.openMenuSku === product.sku;
            const showImage = !!product.imageUrl && !this.failedImageSkus.includes(product.sku);
            return {
                ...product,
                key: product.sku,
                showImage,
                initials: this.initialsFor(product.name),
                hasPromo: !!product.promoText,
                isSelected,
                menuOpen,
                menuExpanded: menuOpen ? 'true' : 'false',
                showCheckbox: this.selectionMode,
                checkboxDisabled: atLimit && !isSelected,
                checkboxLabel: 'Select ' + product.name + ' to compare',
                menuLabel: 'More options for ' + product.name,
                hasRating: product.rating !== null && product.rating !== undefined,
                ratingText: product.rating
                    ? product.rating + ' (' + (product.reviewCount || 0) + ')'
                    : '',
                showDescription: this.isDetail && !!product.shortDescription,
                cardClass: 'card' + (isSelected ? ' card--selected' : '')
            };
        });
    }

    initialsFor(name) {
        return (name || '')
            .split(' ')
            .filter((part) => part.length > 2)
            .slice(0, 2)
            .map((part) => part.charAt(0).toUpperCase())
            .join('');
    }

    // ------------------------------------------------------------------
    // Selection / compare bar
    // ------------------------------------------------------------------
    get showSelectBar() {
        return this.isCarousel && this.selectionMode;
    }

    get selectBarLabel() {
        return 'Select products ' + this.selectedSkus.length + '/' + this.maxCompare;
    }

    get compareDisabled() {
        return this.sending || this.selectedSkus.length < 2;
    }

    // ------------------------------------------------------------------
    // Suggested replies
    // ------------------------------------------------------------------
    get suggestedReplies() {
        const replies = (this.parsedPayload && this.parsedPayload.suggestedReplies) || [];
        return replies.map((reply, index) => ({
            ...reply,
            key: 'reply-' + index
        }));
    }

    get hasSuggestedReplies() {
        return this.suggestedReplies.length > 0 && !this.selectionMode;
    }

    // ------------------------------------------------------------------
    // Compare table
    // ------------------------------------------------------------------
    get compareColumns() {
        return this.rawProducts.map((product) => ({
            ...product,
            key: 'col-' + product.sku,
            showImage: !!product.imageUrl && !this.failedImageSkus.includes(product.sku),
            initials: this.initialsFor(product.name)
        }));
    }

    get compareRows() {
        const rows = (this.parsedPayload && this.parsedPayload.rows) || [];
        return rows.map((row) => ({
            key: 'row-' + row.label,
            label: row.label,
            cells: (row.values || []).map((value, index) => ({
                key: 'cell-' + row.label + '-' + index,
                value
            }))
        }));
    }

    // ------------------------------------------------------------------
    // Handlers
    // ------------------------------------------------------------------
    handleImageError(event) {
        const sku = event.target.dataset.sku;
        if (sku && !this.failedImageSkus.includes(sku)) {
            this.failedImageSkus = [...this.failedImageSkus, sku];
        }
    }

    handleToggleMenu(event) {
        const sku = event.currentTarget.dataset.sku;
        this.openMenuSku = this.openMenuSku === sku ? null : sku;
    }

    handleAskFollowUp(event) {
        const product = this.productFor(event.currentTarget.dataset.sku);
        this.openMenuSku = null;
        if (product) {
            this.sendToAgent('Tell me more about ' + product.name + ' (item ' + product.sku + ')');
        }
    }

    handleFindSimilar(event) {
        const product = this.productFor(event.currentTarget.dataset.sku);
        this.openMenuSku = null;
        if (product) {
            this.sendToAgent('Show me products similar to ' + product.name + ' (item ' + product.sku + ')');
        }
    }

    handleMenuLinkClick() {
        this.openMenuSku = null;
    }

    handleSelect(event) {
        const sku = event.target.dataset.sku;
        if (event.target.checked) {
            if (!this.selectedSkus.includes(sku) && this.selectedSkus.length < this.maxCompare) {
                this.selectedSkus = [...this.selectedSkus, sku];
            }
        } else {
            this.selectedSkus = this.selectedSkus.filter((item) => item !== sku);
        }
    }

    handleCancelSelection() {
        this.selectionMode = false;
        this.selectedSkus = [];
    }

    async handleCompare() {
        if (this.selectedSkus.length < 2) {
            return;
        }
        const chosen = this.selectedSkus.map((sku) => this.productFor(sku)).filter((p) => !!p);
        const names = chosen.map((product) => product.name).join(' and ');
        const skus = chosen.map((product) => product.sku).join(',');
        const sent = await this.sendToAgent('Compare ' + names + ' (items ' + skus + ')');
        if (sent) { this.selectionMode = false; this.selectedSkus = []; }
    }

    handleReply(event) {
        const index = Number(event.currentTarget.dataset.index);
        const reply = this.suggestedReplies[index];
        if (!reply) {
            return;
        }
        if (reply.action === 'compareMode') {
            // Local UI toggle, matches the "Compare products" chip in Holly today.
            this.selectionMode = true;
            return;
        }
        this.sendToAgent(reply.text || reply.label);
    }

    productFor(sku) {
        return this.rawProducts.find((product) => product.sku === sku);
    }

    // Enhanced Chat v2 injects the supported message API into this component.
    async sendToAgent(text) {
        if (this.sending) return false;
        this.sendError = '';
        const util = this.configuration?.util;
        if (typeof util?.sendTextMessage !== 'function') {
            this.sendError = 'Please type this in the chat: ' + text;
            return false;
        }
        this.sending = true;
        try {
            await util.sendTextMessage(text);
            return true;
        } catch (error) {
            this.sendError = 'Your message could not be sent. Please try again or type it in the chat.';
            return false;
        } finally {
            this.sending = false;
        }
    }
}

import { LightningElement, api } from 'lwc';
export default class HollyWelcome extends LightningElement {
 @api configuration;
 @api value;
 dismissed = false;
 errorMessage = '';
 imageFailed = false;
 sendingChoice = false;
 get choices() { return [
  'I need a card for someone special',
  'Help me find a birthday gift',
  "What’s popular for Halloween?",
  'Where is my order?',
  'Check my Crown Rewards points',
  'Hallmark+ membership help',
  'Ask a question about returns or shipping'
 ]; }
 get choiceDisabled() { return this.sendingChoice; }
 async selectChoice(event) {
  const text=event.currentTarget.dataset.choice;
  if(this.choiceDisabled || !this.choices.includes(text))return;
  this.sendingChoice=true;this.errorMessage='';
  try {
   if(typeof this.configuration?.util?.sendTextMessage !== 'function')throw new Error('Unavailable');
   await this.configuration.util.sendTextMessage(text);

  } catch { this.errorMessage='Your selection could not be sent. Try again or type it in the chat.'; }
  finally { this.sendingChoice=false; }
 }

 get showBanner() { return true; }
 get showImage() { return !this.imageFailed; }
 get imageUrl() { return 'https://www.hallmark.com/dw/image/v2/AALB_PRD/on/demandware.static/-/Sites-hallmark-master/default/dw25cc2ffc/images/finished-goods/products/499LOV1465/Copper-Heart-on-Blue-Romantic-Love-Card_499499LOV1465_01.jpg?sw=160&sh=160&sm=fit'; }
 imageError() { this.imageFailed = true; }
}
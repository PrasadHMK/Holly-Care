import { LightningElement, api } from 'lwc';
import { dispatchMessagingEvent, MESSAGING_EVENT } from 'lightningsnapin/eventStore';
export default class HollyCareHeader extends LightningElement {
 @api configuration;
 menuOpen = false;
 ending = false;
 get menuExpanded() { return String(this.menuOpen); }
 toggleMenu() { this.menuOpen = !this.menuOpen; }
 handleKeydown(event) {
  if(event.key === 'Escape') { this.menuOpen=false;this.template.querySelector('[data-menu]')?.focus(); }
 }
 minimize() { dispatchMessagingEvent(MESSAGING_EVENT.MINIMIZE_BUTTON_CLICK, {}); }
 requestTranscript() {
  this.menuOpen=false;this.errorMessage='';
  try {
   if(!MESSAGING_EVENT.REQUEST_TRANSCRIPT)throw new Error('Unavailable');
   dispatchMessagingEvent(MESSAGING_EVENT.REQUEST_TRANSCRIPT, {});
  } catch { this.errorMessage='The transcript request could not be opened. Please try again.'; }
 }
 async endConversation() {
  if(this.ending)return;
  this.ending=true;this.menuOpen=false;this.errorMessage='';
  try {
   const auth=this.configuration?.embeddedServiceMessagingChannel?.authMode;
   if(auth === 'Auth') {
    if(typeof this.configuration?.util?.endSession !== 'function')throw new Error('Unavailable');
    await this.configuration.util.endSession();
   } else if(auth === 'UnAuth') dispatchMessagingEvent(MESSAGING_EVENT.CLOSE_CONVERSATION, {});
   else throw new Error('Unknown authentication mode');
  } catch { this.errorMessage='The chat could not be ended. Please try again.'; }
  finally { this.ending=false; }
 }
 _conversationStatus;
 _welcomeLoaded = false;
 // A presentation-only marker; never stores transcript or customer information.
 get welcomeStorageKey() {
  return 'holly.welcome.dismissed.v2:' + (typeof window !== 'undefined' ? window.location.pathname : 'default');
 }
 loadWelcomeState() {
  if(this._welcomeLoaded)return;
  this._welcomeLoaded=true;
  try { this.dismissed = window.sessionStorage.getItem(this.welcomeStorageKey) === '1'; }
  catch { /* Storage may be blocked. In-memory lifecycle still works. */ }
 }
 connectedCallback() { this.loadWelcomeState(); }
 @api get conversationStatus() { return this._conversationStatus; }
 set conversationStatus(value) {
  const previous=this._conversationStatus;
  this._conversationStatus=value;
  this.loadWelcomeState();
  if(value === 'CLOSED' || (previous === 'CLOSED' && value !== 'CLOSED') ||
     (value === 'NOT_STARTED' && previous === 'OPEN')) {
   this.resetWelcome();
  }
 }
 resetWelcome() {
  this.dismissed=false;this.imageFailed=false;this.errorMessage='';
  this.menuOpen=false;this.sendingChoice=false;
  try { window.sessionStorage.removeItem(this.welcomeStorageKey); } catch { /* Optional storage. */ }
 }
 dismissed = false;
 errorMessage = '';
 imageFailed = false;
 sendingChoice = false;
 get choices() { return [
  'I need a card for someone special',
  'Help me find a birthday gift',
  "What’s popular for Halloween?",
  'Where is my order?',
  'Check my Crown Rewards points',
  'Hallmark+ membership help',
  'Ask a question about returns or shipping'
 ]; }
 get choiceDisabled() { return this.sendingChoice || !this.isOpen; }
 async selectChoice(event) {
  const text=event.currentTarget.dataset.choice;
  if(this.choiceDisabled || !this.choices.includes(text))return;
  this.sendingChoice=true;this.errorMessage='';
  try {
   if(typeof this.configuration?.util?.sendTextMessage !== 'function')throw new Error('Unavailable');
   await this.configuration.util.sendTextMessage(text);
   this.dismissed=true;
   try { window.sessionStorage.setItem(this.welcomeStorageKey, '1'); } catch { /* Optional storage. */ }
  } catch { this.errorMessage='Your selection could not be sent. Try again or type it in the chat.'; }
  finally { this.sendingChoice=false; }
 }

 get showBanner() { return !this.dismissed && (this.conversationStatus === 'OPEN' || this.conversationStatus === 'NOT_STARTED'); }
 get showImage() { return !this.imageFailed; }
 get isOpen() { return this.conversationStatus === 'OPEN'; }
 get imageUrl() { return 'https://www.hallmark.com/dw/image/v2/AALB_PRD/on/demandware.static/-/Sites-hallmark-master/default/dw25cc2ffc/images/finished-goods/products/499LOV1465/Copper-Heart-on-Blue-Romantic-Love-Card_499499LOV1465_01.jpg?sw=160&sh=160&sm=fit'; }
 imageError() { this.imageFailed = true; }
}
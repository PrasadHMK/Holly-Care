# LWC presentation correction — September 22, 2026

Found conflicting text-only instructions in Orders, Returns, Crown Rewards and Hallmark+. Replaced successful structured-result presentation rules with renderedResponse card priority. Failure and transactional workflows remain conversational.

Removed rewardsSupportWidget suppressWidgetForTextOnlyView gate (including rewardConversion). The gate did not include memberOverview, so it does not by itself explain the reported missing overview. H+ already renders membershipFound=true regardless of responseType=text. Orders already renders order lists/details when its payload contains orders. Local type/schema/channel mapping checks pass; this is not proof of live org registration.

Removed product introduction markup and side-arrow controls/handlers. Horizontal scrolling remains keyboard focusable. Follow-up text remains. Updated Product_Catalog instructions to suppress separate introductory narration.

Deploy productCarouselWidget and rewardsSupportWidget, then update the affected presentation instructions in agent-script/Hallmark_Holly_Care_v4.yaml in the actual agent version used by the site. Preserve org-specific configuration. Save and publish using your existing release process. No Apex changes or action recreation are required by this patch. Verify Orders, Rewards and H+ in a new live conversation; if still text-only, inspect deployed renderer metadata and active agent action output mapping. Do not treat this local verification as a successful Salesforce deployment.

Validation: 13 unit checks, 22 LWC source compilation checks, all 14 typed output mappings, and actual local browser component checks passed. Browser checks explicitly assert absence of product arrows and duplicate product-message elements. Salesforce deployment/compilation and live conversation verification have not been performed.

Changed source: agent-script/Hallmark_Holly_Care_v4.yaml; force-app/main/default/lwc/productCarouselWidget/productCarouselWidget.html and .js; force-app/main/default/lwc/rewardsSupportWidget/rewardsSupportWidget.js. Tests and generated preview bundles/screenshots also refreshed.

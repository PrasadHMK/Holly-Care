# Custom header with Salesforce transcript and end-chat actions

Deploy the complete hollyCareHeader bundle (HTML, JS, CSS, metadata), not CSS alone. It is included in manifest/ui-foundation.xml. Keep existing card/renderer deployments. Select Holly Care Header (`hollyCareHeader`) in Embedded Service Deployment > Custom UI Components and publish. Update the v4 Agent Script so its welcome says “How can I help you today? You can ask about cards and gifts, orders, Crown Rewards, or Hallmark+.” The experimental Holly_Welcome subagent has been removed from that script; no welcome action manifests are required.

In Setup > Messaging Settings > your Enhanced Chat channel, enable **Let customers download their conversation transcripts**. The custom menu includes Request Chat Transcript, which dispatches MESSAGING_EVENT.REQUEST_TRANSCRIPT to Salesforce. This opens the platform's transcript handling; the component neither creates a transcript nor sends email. An unavailable event produces a visible error. The platform determines eligibility and request outcome.

End chat calls configuration.util.endSession() for Auth sessions and dispatches MESSAGING_EVENT.CLOSE_CONVERSATION for UnAuth sessions, following Salesforce's header sample. No separate custom confirmation panel is added. Minimize dispatches MINIMIZE_BUTTON_CLICK. Do not infer backend completion from the event being dispatched.

The visual header is custom, styled to match the supplied screenshot, using the supplied Hallmark chat logo at https://care.hallmark.com/resource/chat_Logo. Confirm this URL is permitted by the deployment image CSP. The title is Hallmark AI Assistant. The image has no X, and choices keep their content widths with wrapping. On short screens the welcome content must remain scrollable without covering the composer; verify in your deployed channel.

Acceptance in sandbox: verify enabled transcript request in both auth modes as applicable, platform completion/error feedback, End chat ending the correct session, minimize/reopen, reconnect, seven choices, image loading, and mobile sizing. No target-org compilation or live Salesforce feature test has been performed here. Local events are mocks.

Official references:
- https://developer.salesforce.com/docs/service/messaging-web/guide/customize-header.html
- https://developer.salesforce.com/docs/service/messaging-web/guide/customize-header-events.html
- https://help.salesforce.com/s/articleView?id=service.miaw_faq.htm&language=en_US&type=5

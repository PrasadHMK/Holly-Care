> Superseded: use CUSTOM_HEADER_SETUP.md. The custom-header approach was restored at the user’s request. This file records the unused alternative.

# Native header with welcome card

The native Salesforce header remains responsible for the Hallmark AI Assistant title, logo, menu, minimize, and end-conversation behavior. Do not select hollyCareHeader as a custom header. In Embedded Service Deployments, clear that selection and publish. Do not delete the old deployed component until its references are removed.

## Deploy in this order

From the project folder, against the intended sandbox:

```sh
sf project deploy start --manifest manifest/welcome-foundation.xml --target-org YOUR_SANDBOX --test-level RunSpecifiedTests --tests HollyWelcomeActionTest --wait 30
sf project deploy start --manifest manifest/welcome-renderer.xml --target-org YOUR_SANDBOX --wait 30
sf org assign permset --name Holly_Welcome --target-org YOUR_SANDBOX --on-behalf-of YOUR_AGENT_USERNAME
```

The foundation includes hollyWelcome, HollyWelcomeResponse, HollyWelcomeAction, its Apex test, permission set, and image CSP entry. The renderer maps HollyWelcomeResponse to hollyWelcome on Enhanced Web Chat, desktop, and mobile. Existing service-card dependencies still require the normal scoped manifests.

Update/import the modified Hallmark_Holly_Care_v4 Agent Script using your supported Builder/DX workflow. Resolve the existing username placeholders and org dependencies; compile, commit, and activate. Confirm Show_Welcome.renderedResponse is visible and mapped to c__HollyWelcomeResponse. This project follows the existing script's Apex action binding convention; target-org compilation remains required.

## Actual behavior and acceptance

On launch the native header and plain system greeting appear. Send “Hi” or “Show options”: the router invokes HollyWelcomeAction and its visible typed output renders the image and seven content-width choices in the transcript. The image has no close button. Each choice sends its text through the Enhanced Chat v2 configuration.util.sendTextMessage API, reaching existing service routes. The welcome card remains in transcript history. The normal transcript scroll handles small screens.

This does not yet implement automatic rich-card display at chat launch. A system welcome string cannot be assumed to execute an Apex action. No artificial customer utterance is sent on launch. Validate any startup-trigger approach separately against the target channel before promising launch-time parity.

Keep native purple branding, the title Hallmark AI Assistant and the configured Hallmark logo. The preview header is an illustration, not a replacement header LWC. Test all seven choices, image loading, reconnect, delivery failure, mobile transcript scrolling and native header controls in the sandbox. Local LWC compilation and browser checks do not certify Apex or Agent Script compilation.

References:
- https://developer.salesforce.com/docs/service/messaging-web/guide/custom-lightning-type-apis.html
- https://developer.salesforce.com/blogs/2026/05/use-custom-lightning-types-in-agent-script-for-rich-agent-ui

# Product messages and welcome update

Latest request supersedes the earlier removal of all product introductions. productCarouselWidget now renders summaryMessage once above carousel/comparison content, then followUpQuestion below. Agent Script instructs the agent not to add a separate introduction. Product sections have a consistent 16px gap and options an 8px gap; side arrows remain absent.

Moved the exact agent welcome into hollyCareHeader, replacing the overlapping introductory paragraph. Agent Script messages.welcome is now an empty string. Verify that the target Salesforce version accepts/suppresses the empty welcome; live org validation has not been run.

Deploy productCarouselWidget (HTML, JS, CSS) and hollyCareHeader (HTML); update Agent Script messages.welcome and Product Discovery PRESENTATION HARD RULE. No Apex changes. Local unit, metadata and browser checks passed. Generated previews refreshed.

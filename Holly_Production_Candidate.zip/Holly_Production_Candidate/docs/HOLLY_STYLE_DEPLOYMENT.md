# Approved Holly styling

Implemented: hollyCareHeader HTML/CSS (white header, retained Hallmark logo, title Hallmark AI Assistent as requested, 14px logo/title separation, purple controls, white native-action menu, welcome styling); productCarouselWidget CSS (210px cards, white image backgrounds, gray introduction/footer, neutral options and consistent spacing). Agent Script font parameter changed to Arial. Header events and product actions unchanged.

Deploy hollyCareHeader and productCarouselWidget bundles. Keep the earlier Agent Script presentation rules and empty welcome. Use Arial in deployment branding as well; an agent instruction alone does not style Salesforce UI.

Target branding values: white background #FFFFFF; primary purple #6748A0; text #30353A; visitor bubble #EEE8F5; assistant bubble #F3F3F3; font Arial. Apply only through the corresponding supported fields in the target deployment. Mockup outer width 490px, corner radius 24px and its send input are visual targets, not properties configured by these LWCs.

Salesforce owns the outer frame, composer and standard message bubbles. These components cannot apply CSS across that boundary. Deployment metadata/credentials are not present here, so the surrounding shell has not been configured or validated in Salesforce. Do not promise an exact post-deployment match from these source changes alone. Inspect a new live conversation after deployment and compare welcome, product results, comparison, transcript, end chat and mobile layout.

Official documentation: https://help.salesforce.com/s/articleView?id=service.miaw_configure_web_deployment_1.htm&language=en_US&type=5 and https://help.salesforce.com/s/articleView?id=service.ec_brand_elements_2.htm&language=en_US&type=5

Validation: 22 LWC sources compiled; local browser interaction checks passed with no browser errors. Actual local welcome screenshot inspected. This is not a Salesforce deployment test.

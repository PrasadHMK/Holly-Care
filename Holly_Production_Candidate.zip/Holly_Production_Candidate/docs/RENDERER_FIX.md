# Fix card output rendering

The v4 Agent Script incorrectly referenced Apex class types for most card outputs. Corrected each to the Custom Lightning Type name. The Apex reference belongs in the Lightning Type schema.json, not the Agent Script output rendering selection.

| Action family | Output | Custom Lightning Type | LWC |
|---|---|---|---|
| Product discovery | renderedResponse | c__ProductAgentResponse | productCarouselWidget |
| Order lookup / order cards | renderedResponse | c__OrderAgentResponse | orderSearchWidget |
| Crown Rewards | renderedResponse | c__RewardsAgentResponse | rewardsSupportWidget |
| Hallmark+ | renderedResponse | c__HallmarkPlusAgentResponse | hallmarkPlusWidget |

1. Confirm the Care site uses Enhanced Chat v2. A working custom header alone does not establish the chat version. Custom Lightning Types require v2.
2. Deploy manifest/ui-foundation.xml then manifest/ui-renderers.xml if these components and all four type bundles have not already been deployed.
3. Update the active agent with the corrected agent-script/Hallmark_Holly_Care_v4.yaml. Retain your sandbox usernames and org-specific references. Compile, commit and activate the new version.
4. In Agentforce Assets / the actual actions used by that agent, verify renderedResponse is shown in the conversation and its Output Rendering uses the matching Custom Lightning Type listed above. If a pre-existing action asset still uses default object/text rendering, update that asset or create a correctly configured action and bind it in the agent. Deploying LWC files alone does not update an existing action's output selection.
5. Hide raw responsePayload and scalar helper outputs from conversation display (is_displayable: False / Show in conversation off). The script already hides these; raw JSON and scalar values in the screenshot imply that the active action configuration differs or is falling back to default object rendering. Only renderedResponse should provide the card. Leave operational fields available to agent reasoning as needed.
6. Publish the deployment if its settings changed and start a fresh test conversation. Verify product, order, CR and H+ action traces return renderedResponse and render the corresponding card. Do not mark every output visible to force rendering.

No new Apex or LWC edits are required for this mapping correction. The earlier product Apex fix remains necessary. Local metadata checks verify type/schema/LWC alignment, not the active org's GenAiFunction output rendering or channel settings. Live rendering remains to be verified in the sandbox.

The down arrow with a number is Salesforce's scroll-to-latest/unread-message control; it is not product pagination. The joined/Just now notice is Salesforce's participant system message. No supported hide setting was confirmed for either. Header CSS cannot safely remove platform transcript UI. Custom labels can alter some text but do not establish a supported way to remove the notice and timestamp entirely.

References:
https://developer.salesforce.com/sample-apps/agent-script-recipes/action-configuration/custom-lightning-types
https://developer.salesforce.com/blogs/2026/05/use-custom-lightning-types-in-agent-script-for-rich-agent-ui
https://help.salesforce.com/s/articleView?id=service.miaw_faq.htm&language=en_US&type=5

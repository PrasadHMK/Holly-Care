# Welcome refresh correction

Previously, merely displaying the welcome stored a seen flag. This hid the welcome after launch → refresh even without user input. The header now persists dismissal only after a successfully sent welcome choice, using a new key so old seen flags no longer hide an untouched welcome. CLOSED/new-conversation resets remain.

Deploy hollyCareHeader (only its JS changed). No Apex, action or Agent Script changes are needed. Launch → refresh with no choice should retain the banner/options. Successful choice → refresh keeps them hidden. Failed send retains them. End/new conversation restores them.

This tracks header choices only: messages typed in the native Salesforce composer are not observable by this component through the current integration. It cannot guarantee automatic dismissal for typed-message-only conversations. No transcript inspection or undocumented message event is used.

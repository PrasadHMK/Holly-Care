# Release acceptance

## Passed locally

- Source metadata structure and typed output/renderer associations.
- Actual LWC JavaScript, template and stylesheet compilation.
- Selection/send failure, malformed payload, outbound URL, response binding and header transport tests.
- Desktop/mobile actual-component rendering and two-product comparison interaction.

## Required in the target org before production

- Confirm target org supports API 67.0 and Enhanced Chat v2 custom Lightning Types and header customization.
- Resolve the dedicated agent user, flows, Knowledge/prompt templates, business hours, custom fields/metadata, connector credentials and service permissions.
- Compile Apex and Agent Script; run relevant backend tests and satisfy Salesforce coverage requirements. Validate metadata deployment and retain deployment/test reports.
- Verify customer identity and record ownership for order and rewards lookups. Review inherited Apex security and object/field permissions. Email/phone input alone is not proof of ownership.
- Test live order tracking, rewards balance/conversion, Hallmark+ membership, returns, missing points, case creation, business-hours transfer, after-hours handling and survey end-to-end.
- Confirm visible typed responses appear once, with no duplicate text/table or internal state exposed.
- Test product image failures, menu actions, two-/three-item comparison, failed send/retry, keyboard focus, narrow-screen behavior, expired/reconnected sessions and agent-to-human transfer.
- Check header welcome banner, minimize, end confirmation, authenticated endSession and guest conversation close in the actual deployment. Verify native chat features such as transcript and transfer display remain acceptable with the custom header; this header does not implement every native menu feature.
- Supply and implement a live catalog provider before enabling production shopping. Confirm production cannot use the dummy provider. Validate real price, availability and image/product URL mapping.
- Confirm website CSP, Salesforce CSP, channel routing, publication and domain configuration. Add PDP context only after verified session-variable mapping; no automatic PDP binding is included.
- Record business-owner acceptance and rollback rehearsal. Switch the site to the new deployment via the existing release process. Keep old deployment/source available.

No production-readiness claim should be made until these gates pass.

# Changes compared with Holly_Project_v2.zip

Baseline: original ZIP in Downloads. This inventory compares file contents, not the contents of a deployed Salesforce org.

Three existing Apex .cls files changed. The native-header follow-up additionally adds HollyWelcomeResponse.cls, HollyWelcomeAction.cls, and HollyWelcomeActionTest.cls. New .cls-meta.xml files are deployment descriptors for existing classes.

## Modified files

- `force-app/main/default/classes/Agentforce_Action_InitiateReturn.cls-meta.xml`
- `force-app/main/default/classes/Agentforce_Action_ProductDiscovery.cls`
- `force-app/main/default/classes/Agentforce_Action_ProductDiscovery.cls-meta.xml`
- `force-app/main/default/classes/Agentforce_Action_ProductDiscovery_Test.cls`
- `force-app/main/default/classes/Agentforce_Action_ProductDiscovery_Test.cls-meta.xml`
- `force-app/main/default/classes/Agentforce_InitiateReturn_Test.cls-meta.xml`
- `force-app/main/default/classes/Agentforce_ProductCatalog_Criteria.cls-meta.xml`
- `force-app/main/default/classes/Agentforce_ProductCatalog_DemoMock.cls`
- `force-app/main/default/classes/Agentforce_ProductCatalog_DemoMock.cls-meta.xml`
- `force-app/main/default/classes/Agentforce_ProductCatalog_Item.cls-meta.xml`
- `force-app/main/default/classes/Agentforce_ProductCatalog_Provider.cls-meta.xml`
- `force-app/main/default/classes/ProductAgentActionResult.cls-meta.xml`
- `force-app/main/default/classes/ProductAgentResponse.cls-meta.xml`
- `force-app/main/default/lightningTypes/ProductAgentResponse/enhancedWebChat/renderer.json`
- `force-app/main/default/lightningTypes/ProductAgentResponse/lightningDesktopGenAi/renderer.json`
- `force-app/main/default/lightningTypes/ProductAgentResponse/schema.json`
- `force-app/main/default/lwc/agentforceCaseCreateForm/agentforceCaseCreateForm.css`
- `force-app/main/default/lwc/orderSearchWidget/orderSearchWidget.css`
- `force-app/main/default/lwc/orderSearchWidget/orderSearchWidget.html`
- `force-app/main/default/lwc/orderSearchWidget/orderSearchWidget.js`
- `force-app/main/default/lwc/orderSearchWidget/orderSearchWidget.js-meta.xml`
- `force-app/main/default/lwc/productCarouselWidget/productCarouselWidget.html`
- `force-app/main/default/lwc/productCarouselWidget/productCarouselWidget.js`
- `force-app/main/default/lwc/productCarouselWidget/productCarouselWidget.js-meta.xml`
- `force-app/main/default/lwc/rewardsSupportWidget/rewardsSupportWidget.css`
- `force-app/main/default/lwc/rewardsSupportWidget/rewardsSupportWidget.html`
- `force-app/main/default/lwc/rewardsSupportWidget/rewardsSupportWidget.js`
- `force-app/main/default/lwc/rewardsSupportWidget/rewardsSupportWidget.js-meta.xml`
- `manifest/package.xml`
- `sfdx-project.json`

## New files

- `.gitignore`
- `README.md`
- `agent-script/Hallmark_Holly_Care_v4.yaml`
- `component-preview/components.js`
- `component-preview/index.html`
- `component-preview/main.js`
- `component-preview/welcome-entry.js`
- `component-preview/welcome-text.json`
- `component-preview/welcome.html`
- `component-preview/welcome.js`
- `docs/RELEASE_CHECKLIST.md`
- `docs/VALIDATION.md`
- `docs/actual-lwc-desktop.png`
- `docs/actual-lwc-mobile.png`
- `docs/welcome-experience.png`
- `force-app/main/default/classes/Agentforce_API_Connector.cls-meta.xml`
- `force-app/main/default/classes/Agentforce_API_Connector_Test.cls-meta.xml`
- `force-app/main/default/classes/Agentforce_Action_Accountupdate.cls-meta.xml`
- `force-app/main/default/classes/Agentforce_Action_Accountupdate_Test.cls-meta.xml`
- `force-app/main/default/classes/Agentforce_Action_CreateCase.cls-meta.xml`
- `force-app/main/default/classes/Agentforce_Action_CreateCase_Test.cls-meta.xml`
- `force-app/main/default/classes/Agentforce_Action_CreateCrownRewardsCase.cls-meta.xml`
- `force-app/main/default/classes/Agentforce_Action_CreateCrownRewardsCase_Test.cls-meta.xml`
- `force-app/main/default/classes/Agentforce_Action_CreateHallmarkPlusCase.cls-meta.xml`
- `force-app/main/default/classes/Agentforce_Action_CreateHallmarkPlusCase_Test.cls-meta.xml`
- `force-app/main/default/classes/Agentforce_Action_CreateOrderManageCase.cls-meta.xml`
- `force-app/main/default/classes/Agentforce_Action_CreateOrderManageCase_Test.cls-meta.xml`
- `force-app/main/default/classes/Agentforce_Action_CustomerSearch_Helper.cls-meta.xml`
- `force-app/main/default/classes/Agentforce_Action_CustomerSearch_Helper_Test.cls-meta.xml`
- `force-app/main/default/classes/Agentforce_Action_FindOrderByOrderNo.cls-meta.xml`
- `force-app/main/default/classes/Agentforce_Action_FindOrderByOrderNo_Test.cls-meta.xml`
- `force-app/main/default/classes/Agentforce_Action_FindOrdersByEmail.cls-meta.xml`
- `force-app/main/default/classes/Agentforce_Action_FindOrdersByEmail_Test.cls-meta.xml`
- `force-app/main/default/classes/Agentforce_Action_FindOrdersByPhone.cls-meta.xml`
- `force-app/main/default/classes/Agentforce_Action_FindOrdersByPhone_Test.cls-meta.xml`
- `force-app/main/default/classes/Agentforce_Action_HallmarkPlusSupp_Test.cls-meta.xml`
- `force-app/main/default/classes/Agentforce_Action_HallmarkPlusSupport.cls-meta.xml`
- `force-app/main/default/classes/Agentforce_Action_HallmarkPlusSupport_Test.cls-meta.xml`
- `force-app/main/default/classes/Agentforce_Action_HandleHallmarkFailure.cls-meta.xml`
- `force-app/main/default/classes/Agentforce_Action_HandleHallmarkPlusLookupFailure.cls-meta.xml`
- `force-app/main/default/classes/Agentforce_Action_HandleHallmarkPlusLookupFailure_Test.cls-meta.xml`
- `force-app/main/default/classes/Agentforce_Action_HandleLookupFailure.cls-meta.xml`
- `force-app/main/default/classes/Agentforce_Action_HandleLookupFailure_Test.cls-meta.xml`
- `force-app/main/default/classes/Agentforce_Action_HandleRewardsFailure.cls-meta.xml`
- `force-app/main/default/classes/Agentforce_Action_HandleRewardsFailure_Test.cls-meta.xml`
- `force-app/main/default/classes/Agentforce_Action_MissingPointsFlow.cls-meta.xml`
- `force-app/main/default/classes/Agentforce_Action_MissingPointsFlow_Test.cls-meta.xml`
- `force-app/main/default/classes/Agentforce_Action_OrderByOrderNo_Test.cls-meta.xml`
- `force-app/main/default/classes/Agentforce_Action_OrderSearch_Helper.cls-meta.xml`
- `force-app/main/default/classes/Agentforce_Action_OrderSearch_Helper_Test.cls-meta.xml`
- `force-app/main/default/classes/Agentforce_Action_Rewardconvert.cls-meta.xml`
- `force-app/main/default/classes/Agentforce_Action_Rewardconvert_Test.cls-meta.xml`
- `force-app/main/default/classes/Agentforce_Action_RewardsSupport.cls-meta.xml`
- `force-app/main/default/classes/Agentforce_Action_RewardsSupport_Test.cls-meta.xml`
- `force-app/main/default/classes/Agentforce_CEMS_Connector.cls-meta.xml`
- `force-app/main/default/classes/Agentforce_CEMS_Connector_Test.cls-meta.xml`
- `force-app/main/default/classes/Agentforce_CEMS_CustomerData_Wrapper.cls-meta.xml`
- `force-app/main/default/classes/Agentforce_CEMS_CustomerData_Wrapper_Test.cls-meta.xml`
- `force-app/main/default/classes/Agentforce_CaseComponentMapping.cls-meta.xml`
- `force-app/main/default/classes/Agentforce_ConsumerExistsResult_Test.cls-meta.xml`
- `force-app/main/default/classes/Agentforce_ConsumerExists_Result.cls-meta.xml`
- `force-app/main/default/classes/Agentforce_HallmarkPlus_DemoMock.cls-meta.xml`
- `force-app/main/default/classes/Agentforce_HallmarkPlus_DemoMock_Test.cls-meta.xml`
- `force-app/main/default/classes/Agentforce_HandleHallmarkFailure_Test.cls-meta.xml`
- `force-app/main/default/classes/Agentforce_OrderStatusTranslationConfig.cls-meta.xml`
- `force-app/main/default/classes/Agentforce_TestHttpMock.cls-meta.xml`
- `force-app/main/default/classes/Agentforce_Util.cls-meta.xml`
- `force-app/main/default/classes/CheckBusinessHours.cls-meta.xml`
- `force-app/main/default/classes/HallmarkPlusAgentActionResult.cls-meta.xml`
- `force-app/main/default/classes/HallmarkPlusAgentResponse.cls-meta.xml`
- `force-app/main/default/classes/MissingPointsAgentActionResult.cls-meta.xml`
- `force-app/main/default/classes/OrderAgentActionResult.cls-meta.xml`
- `force-app/main/default/classes/OrderAgentResponse.cls-meta.xml`
- `force-app/main/default/classes/RewardsAgentActionResult.cls-meta.xml`
- `force-app/main/default/classes/RewardsAgentResponse.cls-meta.xml`
- `force-app/main/default/customPermissions/Holly_Demo_Catalog.customPermission-meta.xml`
- `force-app/main/default/lightningTypes/HallmarkPlusAgentResponse/enhancedWebChat/renderer.json`
- `force-app/main/default/lightningTypes/HallmarkPlusAgentResponse/lightningDesktopGenAi/renderer.json`
- `force-app/main/default/lightningTypes/HallmarkPlusAgentResponse/lightningMobileGenAi/renderer.json`
- `force-app/main/default/lightningTypes/HallmarkPlusAgentResponse/schema.json`
- `force-app/main/default/lightningTypes/OrderAgentResponse/enhancedWebChat/renderer.json`
- `force-app/main/default/lightningTypes/OrderAgentResponse/lightningDesktopGenAi/renderer.json`
- `force-app/main/default/lightningTypes/OrderAgentResponse/lightningMobileGenAi/renderer.json`
- `force-app/main/default/lightningTypes/OrderAgentResponse/schema.json`
- `force-app/main/default/lightningTypes/ProductAgentResponse/lightningMobileGenAi/renderer.json`
- `force-app/main/default/lightningTypes/RewardsAgentResponse/enhancedWebChat/renderer.json`
- `force-app/main/default/lightningTypes/RewardsAgentResponse/lightningDesktopGenAi/renderer.json`
- `force-app/main/default/lightningTypes/RewardsAgentResponse/lightningMobileGenAi/renderer.json`
- `force-app/main/default/lightningTypes/RewardsAgentResponse/schema.json`
- `force-app/main/default/lwc/hallmarkPlusWidget/hallmarkPlusWidget.css`
- `force-app/main/default/lwc/hallmarkPlusWidget/hallmarkPlusWidget.html`
- `force-app/main/default/lwc/hallmarkPlusWidget/hallmarkPlusWidget.js`
- `force-app/main/default/lwc/hallmarkPlusWidget/hallmarkPlusWidget.js-meta.xml`
- `force-app/main/default/lwc/hollyCareHeader/hollyCareHeader.css`
- `force-app/main/default/lwc/hollyCareHeader/hollyCareHeader.html`
- `force-app/main/default/lwc/hollyCareHeader/hollyCareHeader.js`
- `force-app/main/default/lwc/hollyCareHeader/hollyCareHeader.js-meta.xml`
- `force-app/main/default/lwc/hollyUi/hollyUi.js`
- `force-app/main/default/lwc/hollyUi/hollyUi.js-meta.xml`
- `force-app/main/default/permissionsets/Holly_Demo_Catalog.permissionset-meta.xml`
- `force-app/main/default/permissionsets/Holly_Product_Prototype.permissionset-meta.xml`
- `manifest/sandbox-catalog.xml`
- `manifest/ui-foundation.xml`
- `manifest/ui-renderers.xml`
- `package.json`
- `pnpm-lock.yaml`
- `pnpm-workspace.yaml`
- `scripts/browser-check.cjs`
- `scripts/build-preview.mjs`
- `scripts/check-metadata.py`
- `scripts/compile-lwc.mjs`
- `tests/ui.test.mjs`


## Native-header follow-up

Added hollyWelcome LWC, HollyWelcomeResponse Lightning Type, HollyWelcomeAction and response/test Apex classes, Holly_Welcome permission set, welcome-foundation.xml and welcome-renderer.xml manifests, and NATIVE_HEADER_SETUP.md. Updated Agent Script greeting route and system welcome, preview entry points, tests, metadata checks, README, full manifest, and UI foundation manifest. The retired hollyCareHeader is no longer in the scoped deployment. Automatic rich welcome at launch remains unimplemented.

## Current custom-header restoration

Restored hollyCareHeader as lightningSnapin__MessagingHeader, with launch-time choices and screenshot-style menu. Added Salesforce REQUEST_TRANSCRIPT event integration and Auth/UnAuth end-chat handling. Updated v4 greeting/router, ui-foundation manifest, preview source and bundles, tests, README, and CUSTOM_HEADER_SETUP.md. Body-welcome action files remain unused reference code; their manifests are not required for this approach.

## Sandbox lifecycle follow-up

Updated hollyCareHeader.js (status resets and same-tab welcome marker), hollyCareHeader.css (32px logo), Holly_Product_Prototype.permissionset-meta.xml (sandbox catalog custom permission), v4 Agent Script (general greeting), preview bundles, tests and setup docs. Added scripts/check-product-demo.apex and docs/SANDBOX_FIXES.md. No Apex implementation changed in this follow-up. Native message-avatar removal and live product action diagnosis remain pending.

## Confirmed product runtime fix

Changed Agentforce_Action_ProductDiscovery.cls and its test to replace unsupported Organization SOQL with platform domain parsing. Updated scripts/check-product-demo.apex and SANDBOX_FIXES.md; added manifest/product-runtime-fix.xml. Permission and sandbox-only restrictions remain.

## Card rendering correction

Updated v4 Agent Script card-output complex_data_type_name references from Apex class references to c__ Custom Lightning Type names. Corrected check-metadata.py to test that contract and explicitly inspect the v4 script. Added RENDERER_FIX.md. No Apex or LWC changes in this correction.

## Holly-style carousel and membership response compatibility

Changed productCarouselWidget HTML/JS/CSS, hollyUi.js, rewardsSupportWidget.js, hallmarkPlusWidget.js, v4 product presentation instructions, tests and generated previews. Added CARD_POLISH.md. No Apex changes. Rewards/H+ live diagnosis is pending action outputs.

## Response audit and product narration

Added RESPONSE_AUDIT.md; checked all 14 visible renderedResponse mappings, four Apex wrappers and renderer bundles. Rewards now accepts memberOverview and membersOverview and responseType fallback. Product displays typed summaryMessage/followUpQuestion above/below cards; removed catalog notice. Updated script, tests, previews and metadata checks. No Apex changes this turn.

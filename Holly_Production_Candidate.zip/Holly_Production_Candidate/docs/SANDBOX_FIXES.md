# Sandbox follow-up: welcome lifecycle and products

## Files to deploy

Deploy the complete hollyCareHeader bundle (JS lifecycle changes and CSS 32px logo), plus the updated Holly_Product_Prototype permission set. Update the v4 Agent Script system greeting to the new general question so resumed chats do not refer to missing options. Publish the Embedded Service deployment and agent version as applicable.

The header now resets welcome state when Salesforce reports CLOSED and starts a new conversation. A sessionStorage presentation marker prevents the launch banner from returning on a same-tab refresh, including after typed input; no customer information is stored. Storage is scoped to the chat iframe path. If storage is blocked, same-tab refresh suppression cannot persist. A new conversation started elsewhere while this tab is closed, or a runtime that never reports CLOSED/NOT_STARTED between conversations, requires target-runtime validation; this is not a server conversation-ID tracking system. The title and menu always remain visible.

## Products: no card vs broken image

The screenshot shows a product action failure before a product card is returned. It does not show a broken-image placeholder. A failed action, missing permission, missing action registration, or an unmapped output must be diagnosed before CSP/image loading.

The updated Holly_Product_Prototype permission set includes both Apex access and the Holly_Demo_Catalog custom permission. Assign it to the actual agent runtime user, not just the administrator. The existing standalone Holly_Demo_Catalog permission set remains supported. The provider still requires Organization.IsSandbox=true; it intentionally refuses sample products in production.

Deploy manifest/sandbox-catalog.xml and the ProductAgentResponse renderer through manifest/ui-renderers.xml if not already deployed. Confirm Product_Catalog.renderedResponse is visible and maps to c__ProductAgentResponse. Run scripts/check-product-demo.apex in the runtime user's context where supported, or inspect the action trace while chatting as the agent. Running as an administrator proves only that administrator's access. Expected: sandbox=true, demo permission=true, productsFound=true, nonempty products and imageUrl in renderedResponse.responsePayload. If unsuccessful, collect the action error and Salesforce debug log rather than disabling the sandbox guard.

If the action succeeds but the card doesn't render, verify Enhanced Chat v2, the active agent action's typed output and ProductAgentResponse renderer deployment. If the card renders but images don't load, check image requests and CSP in the browser; https://www.hallmark.com must be allowed for img-src. The banner image loading is not proof the product action ran.

## Small icon beside messages

That icon is the Salesforce message avatar, outside hollyCareHeader and the product LWC. No supported header CSS change can remove it from the separate message component. Deployment branding supports avatar images; a supported hide-avatar setting was not confirmed. This item remains pending inspection of the target deployment. No cross-component DOM/CSS hack was added.

Local checks cover new-conversation reset, same-tab refresh suppression, storage failures, choice sending, header actions and card rendering. Salesforce Apex execution and live channel behavior remain unverified without sandbox access.

## Confirmed product failure from supplied log

The product action fails at the Organization query: `System.QueryException: sObject type 'Organization' is not supported.` The executing username in this log differs from the earlier supplied username; use the log's USER_INFO identity when verifying assignments.

The patch replaces the Organization SOQL query with `System.DomainParser.parse(URL.getOrgDomainUrl()).getSandboxName()` and requires a nonblank sandbox name. The custom permission guard remains. Deploy manifest/product-runtime-fix.xml and run Agentforce_Action_ProductDiscovery_Test, then retry the same card search in the Care site. Apex tests have been added but require execution in Salesforce; local validation does not execute Apex.

Official reference: https://help.salesforce.com/s/articleView?id=release-notes.rn_apex_domain_classes.htm&release=236&type=5

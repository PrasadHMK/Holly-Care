> Latest sandbox follow-up: see [SANDBOX_FIXES.md](docs/SANDBOX_FIXES.md) for 32px logo, welcome reset/refresh handling, product permissions and the pending native-avatar request.

> **Current approach: custom header restored.** Use `hollyCareHeader` in the Embedded Service Deployment. Its welcome banner and seven choices appear on launch. The menu calls Salesforce's documented REQUEST_TRANSCRIPT event and end-chat API/events; no custom transcript service is used. Follow [CUSTOM_HEADER_SETUP.md](docs/CUSTOM_HEADER_SETUP.md). This supersedes the prior native-header/action-card approach, whose optional source files remain for reference and are not used by the current Agent Script or scoped UI manifests.

# Holly Care — production release candidate

This project implements the real Salesforce LWC presentation layer for the Care-site agent. It is **not approved for production release yet**: Apex/Agent Script compilation, org access, live service verification and deployed Enhanced Chat v2 acceptance are still required. No org or site has been changed.

## What is implemented

| Experience | Salesforce implementation |
|---|---|
| Purple chat header and welcome image | `hollyCareHeader` provides the Hallmark AI Assistant title, menu, welcome image and seven launch-time choices. |
| Minimize and end conversation | Custom buttons delegate to Salesforce's messaging events and verified-session API. |
| Product carousel, images, selection and compare | Existing `productCarouselWidget`, hardened for malformed payloads, safe Hallmark URLs, comparison bounds and failed sends. |
| Order status and tracking | Existing `orderSearchWidget`, now bound through a visible typed output and Lightning Type. |
| Crown Rewards card | Existing `rewardsSupportWidget`, now bound through a visible typed output and Lightning Type. |
| Hallmark+ card | New `hallmarkPlusWidget`, rendering the existing typed membership response. |
| Agent routing | `agent-script/Hallmark_Holly_Care_v4.yaml`; 12 formerly hidden service outputs enabled. |

The active UI uses four service Lightning Types and the custom header. The image has no dismiss button. Welcome choices hide after successful selection to make room for the transcript.

**Welcome preview:** open `component-preview/welcome.html`; options appear immediately. Transcript and end-chat events are simulated locally.

**Review the real components:** open `component-preview/index.html`. This loads the compiled LWC source used in the package, with sample payloads. Header events and message transport are local test doubles; no Salesforce connection, customer lookup, or backend mutation occurs. Dormant Salesforce base-input modules are stubbed in this review harness. This is a component review, not a replacement messaging client.

## Deliberate boundaries

- The original request specified a dummy catalog. It remains available only in a sandbox with `Holly_Demo_Catalog` permission. Production refuses sample results and returns the action's friendly unavailable message. A live catalog API/provider contract is still needed to release live shopping functionality. Do not remove this guard to make sample data appear live.
- Receipt uploads and browser-side case creation in the inherited order/CR widgets are not exposed by the external renderer. These requests continue through the existing agent case workflow. The old `agentforceCaseCreateForm` source remains in the inherited application but is not a dependency of the UI manifests. Do not grant its Apex endpoint to guest users as a shortcut.
- The existing order/CEMS/Hallmark+ integrations, verification model, case actions, Knowledge, routing flows and custom fields are inherited. They have not been certified here for authorization, data ownership, CRUD/FLS, idempotency or production operation. Their original missing metadata dependencies still apply.
- This does not ship a complete SFCC cartridge. Install the deployment-generated Salesforce embed code in the Care/SFCC site's approved integration point. Org IDs, site URLs, identity tokens, channel assignment and CSP settings must come from the target org.

## Deploy in the target sandbox

Use an org where the original service backend already exists. Keep the existing Holly deployment available for rollback.

1. Replace both `REPLACE_WITH_SANDBOX_AGENT_USERNAME` values in the v4 script with the intended agent user. Confirm that user is authorized only for the required service actions.
2. Authenticate Salesforce CLI to the target sandbox. Run a validation/dry run of the foundation before applying it:

   ```sh
   sf project deploy start --manifest manifest/ui-foundation.xml --target-org YOUR_SANDBOX --dry-run --test-level RunLocalTests --wait 30
   sf project deploy start --manifest manifest/ui-foundation.xml --target-org YOUR_SANDBOX --test-level RunLocalTests --wait 30
   sf project deploy start --manifest manifest/ui-renderers.xml --target-org YOUR_SANDBOX --wait 30
   ```

   `ui-foundation.xml` deploys the four response classes, six LWC bundles and image CSP entry. It assumes the base backend response contracts match this source. Compare them against the target org before deployment.
3. For the explicitly requested sample shopping demonstration, deploy `manifest/sandbox-catalog.xml`, then assign `Holly_Demo_Catalog` and required product Apex access to the sandbox agent user. Run `Agentforce_Action_ProductDiscovery_Test`. This permission alone never enables samples in production.
4. Create the separate `Hallmark_Holly_Care_v4` Agentforce service agent using the target org's supported Agent Builder/Agentforce DX script workflow. This `.yaml` file contains Agent Script DSL, not ordinary YAML. Compile the script and resolve org-specific Flow/prompt references. Verify every `renderedResponse` output maps to its custom Lightning Type and is visible. Raw `responsePayload` stays hidden.
5. Create/update a sandbox **Enhanced Chat v2** deployment. Select `hollyCareHeader` as the custom header and enable transcript downloads in Messaging Settings. Publish the deployment. Confirm the target channel/version supports the selected header customization; do not assume CLT installation configures the header automatically.
6. Embed the generated deployment snippet on the sandbox Care site. Test with the actual agent and verified/unverified sessions as appropriate. Do not activate against the production website until the release checklist passes.

`manifest/package.xml` enumerates the full application source, including inherited service classes; prefer the scoped manifests above. It must not be used as a blind overwrite of existing production service code.

## Local validation

```sh
pnpm install --frozen-lockfile --ignore-scripts
pnpm check:lwc
pnpm test
python3 scripts/check-metadata.py
pnpm build:preview
```

Browser smoke tests require Playwright and Chrome; run `node scripts/browser-check.cjs` with Playwright on the module path. See `docs/VALIDATION.md` for results and `docs/RELEASE_CHECKLIST.md` for the remaining gates.

## Official references used

- [Custom Lightning Types and supported channels](https://developer.salesforce.com/docs/platform/lightning-types/guide/lightning-types-core.html)
- [Enhanced Chat v2 component message API](https://developer.salesforce.com/docs/service/messaging-web/guide/custom-lightning-type-apis.html)
- [Custom messaging header](https://developer.salesforce.com/docs/service/messaging-web/guide/customize-header.html)
- [Header events](https://developer.salesforce.com/docs/service/messaging-web/guide/customize-header-events.html)

Salesforce API 67.0 remains the project baseline. Local compilation uses the pinned open-source LWC compiler; Salesforce deployment compilation remains authoritative.

